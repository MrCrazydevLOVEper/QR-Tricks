$(document).ready(function() {

    var ReportDetailsJSON,ReportDetailsJSON1, area_master_id, mode;
    $.when(getreportdetails()).done(function() {
        dispDetailslist(ReportDetailsJSON);
    });

    function getreportdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/yallamoneyreport',
            type: 'POST',
            success: function(data) 
            {
                ReportDetailsJSON = $.parseJSON(data);
            },
            error: function() 
            {
                console.log("Error");
            }
        });
    }


    function dispDetailslist(JSON) 
    {
        var i =1;
        $('#yalla_cpurchase_report').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: 'Yalla Money All User Report',
                    text: "Export as Excel",
                     exportOptions: {
                        message: "Yalla Money Report",
                        columns: [ 0,1, 2, 3]
                    },
                },            
            ],
            "aoColumns": [

                    {
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.username==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.username;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.user_unique_id==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.user_unique_id;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.yalla_money==null) 
                        {
                            return '0';
                        }
                        else
                        {
                            return data.yalla_money;   
                        }                        
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                            return '<a id="' + meta.row + '" class="btn viewdetailss" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to see details"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;  view details</a>&nbsp;&nbsp;';
                        }
                },  
               
                 
            ]
        });
    }

    function refreshDetails() {
        $.when(getreportdetails()).done(function() {
            var table = $('#yalla_cpurchase_report').DataTable();
            table.destroy();
            dispDetailslist(ReportDetailsJSON);
        });
    }


    $(document).on('click','.viewdetailss',function(){
        
        var r_index = $(this).attr('id');
        var user_unique_id = ReportDetailsJSON[r_index].user_unique_id; 
        var user_yalla_money = ReportDetailsJSON[r_index].yalla_money; 
        var username = ReportDetailsJSON[r_index].username;   

        if (user_yalla_money==null) 
        {
            user_yalla_money = 0;
        }
        else
        {   
            user_yalla_money = user_yalla_money;  
        } 

            return $.ajax({
            url: base_URL+'ThirdAxisCon/getuseryallamoneyreport',
            type:'POST',
            data: {"user_unique_id":user_unique_id},
            success:function(data){
                $('#productmodel').modal('show');
                ReportDetailsJSON1 = $.parseJSON(data); 
                 dispDetailslist1(ReportDetailsJSON1);

                $('.customerinfo').html('');
                $('.customerinfo').append("<h4 class='text-uppercase'>"+ username+"</h4>  <p>"+user_unique_id+", <br> <span class='text text-danger'> current yalla money : "+ user_yalla_money +"</span>");



            },      
            error: function() {
                console.log("Error");   
            }
        }) ;
    });

 
       
 

    function dispDetailslist1(JSON) 
    {
        var i =1;
        $('#yalla_cpurchase_report1').dataTable({
            destroy: true,
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: 'Yalla Money Report',
                    text: "Export as Excel",
                     exportOptions: {
                        message: "Yalla Money user Report",
                        columns: [ 0, 1, 2, 3, 4 ]
                    },
                },            
            ],
            "aoColumns": [

                    {
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.orderno==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.orderno ;   
                        }                        
                    }
                }, 

                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.yalla_money_amount==null) 
                        {
                            return '';
                        }
                        else
                        {   
                            return '<span class="text text-danger">'+data.yalla_money_amount+'</span>';  
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.orderbag_total==null) 
                        {
                            return '';
                        }
                        else
                        {   
                            return '<span class="text text-success">'+data.orderbag_total+'</span>';  
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.order_place_date==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.order_place_date;   
                        }                        
                    }
                },  
               
                 
            ]
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});