$(document).ready(function() {

    var MinusinventorydetailsJSON, banner_id, mode,OfferproductDetailJSON,MinusinventorydetailsJSON;

    $.when(getinventorydetails()).done(function(){
            dispgingdetails(MinusinventorydetailsJSON);                
    });


    function getinventorydetails()
    {

        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getminusinventory',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                MinusinventorydetailsJSON = $.parseJSON(data);
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    $(document).on('click', "#updatestockcustom_btn", function() 
    {
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/updatestockcustom',
            type: 'POST',
            success: function(data) {
                var js = $.parseJSON(data);
                var status = js.result;
                var message = js.msg;

                if (status == "success") 
                {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: '' + message + '',
                        type: 'green',
                        buttons: {
                            Ok: function() {
                                location.reload();
                            },
                        }
                    });
                } else if (status == "fail") {

                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: '' + message + '',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                }

            },
            error: function() {
                console.log("Error");
            }
        });
    });




    function dispgingdetails(JSON) {
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.prod_type=="Requestproduct") 
                        {
                            return ''+data.prod_detais+' <span style="color:red"> Requested Product</span>';
                        }
                        else
                        {
                            return ''+data.prod_code+' - '+data.prod_detais+'';
                        }
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                       return '<span style="color:red"> - '+data.prod_stock_qty+'</span>';                           
                    }
                }, 
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.order_placed_datentime+'';
                    }
                },       
            ]
        });
    }


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });


});