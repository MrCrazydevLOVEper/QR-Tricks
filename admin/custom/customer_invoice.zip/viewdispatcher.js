$(document).ready(function() {

    var DeliverypersonsdetailsJSON, delivery_persons_id, mode;
    $.when(getdeliverypersonsdetails()).done(function() {
        dispDeliverypersonsdetails(DeliverypersonsdetailsJSON);
    });


    function getdeliverypersonsdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getdispatcherdetails',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                DeliverypersonsdetailsJSON = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }

    function dispDeliverypersonsdetails(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": "YBD_name"
                },
                {
                    "mDataProp": "YBD_mobile_no"
                },
                {
                    "mDataProp": "YBD_email"
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.avaliable_status == 1)
                            return '<a id="' + meta.row + '" class="btn Btnavaliablehidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  Available</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnavaliableRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Not Available</a>&nbsp;&nbsp;';

                    }
                },{
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  Active</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Deactive</a>&nbsp;&nbsp;';

                    }
                }, {
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },
            ]
        });
    }

    $('#New_Category').click(function() {
        mode = "new";
        $('#largeModal').modal('show');
    });

    $(document).on('click', '.BtnEdit', function() {
        mode = "update";
        var r_index = $(this).attr('id');
        delivery_persons_id = DeliverypersonsdetailsJSON[r_index].delivery_persons_id;
        $('#largeModal').modal('show');
        $('#YBD_name').val(DeliverypersonsdetailsJSON[r_index].YBD_name);
        $('#YBD_mobile_no').val(DeliverypersonsdetailsJSON[r_index].YBD_mobile_no);
        $('#YBD_email').val(DeliverypersonsdetailsJSON[r_index].YBD_email);
        $('#total_package').val(DeliverypersonsdetailsJSON[r_index].total_package);
        $('#YBD_username').val(DeliverypersonsdetailsJSON[r_index].YBD_username);
        $('#YBD_password').val(DeliverypersonsdetailsJSON[r_index].YBD_password);
    });

    $(document).on('click', '.BtntodaysorderEdit', function() {
        var r_index = $(this).attr('id');
        $('#todaysorderModal').modal('show');
        delivery_persons_id = DeliverypersonsdetailsJSON[r_index].delivery_persons_id;
        $('#total_package_acpt').val(DeliverypersonsdetailsJSON[r_index].total_package);
        var assigned_order_count = DeliverypersonsdetailsJSON[r_index].total_package - DeliverypersonsdetailsJSON[r_index].remaning_package;

        // if (assigned_order_count==0) 
        // {
        //     assigned_order_count = DeliverypersonsdetailsJSON[r_index].total_package;
        // }
        $('#assigned_order_count').val(assigned_order_count);
        $('#todays_amount').val(DeliverypersonsdetailsJSON[r_index].todays_amount);
        $('#cash_price').val(DeliverypersonsdetailsJSON[r_index].cash_price);
        $('#card_price').val(DeliverypersonsdetailsJSON[r_index].card_price);
        $('#pending_amount').val(DeliverypersonsdetailsJSON[r_index].pending_amount);
    });


    $(document).on('click', '.Btntviewcurrentlocation', function() {
        var r_index = $(this).attr('id');

        $('#locationModal').modal('show');
        initMap(DeliverypersonsdetailsJSON[r_index].YBD_lat,DeliverypersonsdetailsJSON[r_index].YBD_long,DeliverypersonsdetailsJSON[r_index].YBD_name);
    });
      function initMap(YBD_lat,YBD_long,YBD_name) {
        const chicago = new google.maps.LatLng(YBD_lat, YBD_long);
        const map = new google.maps.Map(document.getElementById("map"), {
          center: chicago,
          zoom: 10,
        });
        const geocoder = new google.maps.Geocoder();
        const infowindow = new google.maps.InfoWindow();
        geocodeLatLng(geocoder, map, infowindow, chicago, YBD_name);
      }

      function geocodeLatLng(geocoder, map, infowindow, chicago, YBD_name) {

        geocoder.geocode({ location: chicago }, (results, status) => {
          if (status === "OK") {
            if (results[0]) {
              map.setZoom(16);
              const marker = new google.maps.Marker({
                position: chicago,
                map: map,
              });
              infowindow.setContent(
                    createInfoWindowContent(results[0].formatted_address, chicago, YBD_name)
                );
              infowindow.open(map, marker);
            } else {
              window.alert("No results found");
            }
          } else {
            window.alert("Geocoder failed due to: LatLng not updated");
          }
        });
      }

      function createInfoWindowContent(formatted_address, chicago, YBD_name) {
        return [
          "User Name: "+ YBD_name,
          "LatLng: " + chicago,
          "Address : " + formatted_address
        ].join("<br>");
      }





    $(document).on('click', '.BtnDelete', function() {
        mode = "delete";
        var r_index = $(this).attr('id');
        delivery_persons_id = DeliverypersonsdetailsJSON[r_index].delivery_persons_id;
        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Delete this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                    request = $.ajax({
                        type: "POST",
                        url: base_URL + 'ThirdAxisCon/Deletedeliverypersonslist',
                        data: {
                            "delivery_persons_id": delivery_persons_id
                        },
                    });
                    request.done(function(response) {
                        var js = $.parseJSON(response);
                        var status = js.result
                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Deleted Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                            refreshDetails();
                        } else {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Are you Sure Do you want to Delete this Data',
                                type: 'blue',
                                buttons: {
                                    No: function() {},
                                }
                            });
                        }

                    });
                },
                No: function() {},
            }
        });

    });

    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        delivery_persons_id = DeliverypersonsdetailsJSON[r_index].delivery_persons_id;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	Restoredeliverypersonslist(delivery_persons_id,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        delivery_persons_id = DeliverypersonsdetailsJSON[r_index].delivery_persons_id;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	Restoredeliverypersonslist(delivery_persons_id,flag);
                },
                No: function() {},
            }
        });

    });


    function Restoredeliverypersonslist(delivery_persons_id,flag)
    {
    	var delivery_persons_id = delivery_persons_id;
    	var flag = flag;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/Restoredeliverypersonslist',
            data: {
                "delivery_persons_id": delivery_persons_id,"flag":flag
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


    $('#deliveryperson_Button').click(function() {
        $('.error').hide();
        //console.log($('#url').val()); 
        if ($('#YBD_name').val() == "") {
            $('.YBD_name').html("* Please Fill Name");
            $('.YBD_name').show();
        }  
        if ($('#total_package').val() == "") {
            $('.total_package').html("* Please Fill No.of packages can accept");
            $('.total_package').show();
        }  
        if ($('#YBD_username').val() == "") {
            $('.YBD_username').html("* Please Fill User Name");
            $('.YBD_username').show();
        }  
        if ($('#YBD_password').val() == "") {
            $('.YBD_password').html("* Please Fill Password");
            $('.YBD_password').show();
        } 
        else 
        {
            if (mode == "new") {
                savedeliverypersonlist();
            } else {
                updatedeliverypersonlist();
            }

        }
    });

    function savedeliverypersonlist() {
        var form = $('#deliveryperson_Form')[0];
        var data = new FormData(form);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/insertdeliverypersonslist',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            console.log(status);
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Inserted Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }
        });
    }

    function refreshDetails() {
        $.when(getdeliverypersonsdetails()).done(function() {
            var table = $('#Main_Category').DataTable();
            table.destroy();
            dispDeliverypersonsdetails(DeliverypersonsdetailsJSON);
        });
    }

    function updatedeliverypersonlist() {
        var form = $('#deliveryperson_Form')[0];
        var data = new FormData(form);
        data.append("delivery_persons_id", delivery_persons_id);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/updatedeliverypersonslist',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } else {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }		
        });
    }

    $('#largeModal').on('show.bs.modal', function() {
        $(".no").hide();
        $('#hide').attr('checked', false);
        $('#show').attr('checked', false);
        $(this).find('form').trigger('reset');
    });



    $(document).on('click', '.Btnavaliablehidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        delivery_persons_id = DeliverypersonsdetailsJSON[r_index].delivery_persons_id;
        var avaliable_status = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to update as User Not Available',
            type: 'blue',
            buttons: {
                Yes: function() {
                    Restoreavaliable_status(delivery_persons_id,avaliable_status);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnavaliableRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        delivery_persons_id = DeliverypersonsdetailsJSON[r_index].delivery_persons_id;
        var avaliable_status = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to update as User Available',
            type: 'blue',
            buttons: {
                Yes: function() {
                    Restoreavaliable_status(delivery_persons_id,avaliable_status);
                },
                No: function() {},
            }
        });

    });


    function Restoreavaliable_status(delivery_persons_id,avaliable_status)
    {
        var delivery_persons_id = delivery_persons_id;
        var flag = flag;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/Restoreavaliable_status',
            data: {
                "delivery_persons_id": delivery_persons_id,"avaliable_status":avaliable_status
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


















    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});