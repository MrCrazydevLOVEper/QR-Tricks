$(document).ready(function() {

	var promocodeJSOM,promocode_id,mode;
	$.when(getpromocodedetails()).done(function(){
			dispPromocodeDetails(promocodeJSOM);	
	});
	
	function getpromocodedetails()
	{
		return $.ajax({
			url: base_URL+'ThirdAxisCon/getpromocodedetails',
			type:'POST',
			success:function(data){
				//console.log(data);
				promocodeJSOM = $.parseJSON(data);
				
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;
	}

	
	function dispPromocodeDetails(JSON)
	{
		//$('#success_alert').show(1000);
		//console.log(dataJSON);
			var i = 1;
		$('#Sub_Category').dataTable( {
			"aaSorting":[],
			"aaData": JSON,
			responsive: true,
			"aoColumns": [
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return i++;					
					}
				},
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.promocode_name+' ';
					}
				},					
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.promo_code+'';
					}
				},				
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.promocode_from+' ';
					}
				},			
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.promocode_to+'';
					}
				},
				{ "mDataProp": "promocode_instaces" },
				{ 
					"mDataProp": function ( data, type, full, meta) 
					{
						if (data.promocode_discount_type=='P') 
						{
							return ''+ data.promocode_discount_value+' %';	
						}
						else if (data.promocode_discount_type=='A') 
						{
							return ''+ data.promocode_discount_value+' AED';	
						}						
					}
				},
				{ "mDataProp": "promocode_max_discount" },
				{
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  Active</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Deactive</a>&nbsp;&nbsp;';;

                    }
                },
				{
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },				
			]  				
		});
	}
	
	$('#New_Category').click(function(){
		mode="new";
		$('#largeModal').modal('show');
	});
	
	$(document).on('click','.BtnEdit',function(){
		mode="update";
		var r_index = $(this).attr('id');
		promocode_id = promocodeJSOM[r_index].promocode_id;
		$('#largeModal').modal('show');
		$('#promocode_name').val(promocodeJSOM[r_index].promocode_name);
		$('#promo_code').val(promocodeJSOM[r_index].promo_code);
		$('.promocode_from').val(promocodeJSOM[r_index].promocode_from);		
		$('.promocode_to').val(promocodeJSOM[r_index].promocode_to);
		$('#promocode_instaces').val(promocodeJSOM[r_index].promocode_instaces);
		$('#promocode_discount_type').val(promocodeJSOM[r_index].promocode_discount_type);
		$('#promocode_discount_value').val(promocodeJSOM[r_index].promocode_discount_value);
		$('#promocode_max_discount').val(promocodeJSOM[r_index].promocode_max_discount);		

	});
		
	
	$(document).on('click','.BtnDelete',function(){
		mode="delete";
		var r_index = $(this).attr('id');
		promocode_id = promocodeJSOM[r_index].promocode_id;	
		   $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Are you Sure Do you want to Delete this Promo Code',
                type: 'blue',
					buttons: {
						Yes: function() {					
								request = $.ajax({
										type: "POST",
										url: base_URL+'ThirdAxisCon/Deletepromocode',
										data: {"promocode_id":promocode_id},
								});	
								request.done(function (response){
									var js = $.parseJSON(response);
									var status = js.result
									if (status == "success") {
										$.confirm({
											icon: 'icon-close',
											title: 'Info',
											content: 'Deleted Succesfully',
											type: 'green',
												buttons: {
													Ok: function() {},
												}
										});
										refreshDetails();
									}
									else
									{
										$.confirm({
											icon: 'icon-close',
											title: 'Info',
											content: 'Are you Sure Do you want to Delete this Data',
											type: 'blue',
												buttons: {
													No: function() {},
												}
										});
									}
							
								});	
						},
						No: function() {},
					}
            });
		
		
	

	});
	


    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
		promocode_id = promocodeJSOM[r_index].promocode_id;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Promo Code',
            type: 'blue',
            buttons: {
                Yes: function() {
                	Restorepromocode(promocode_id,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
		promocode_id = promocodeJSOM[r_index].promocode_id;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Promo Code',
            type: 'blue',
            buttons: {
                Yes: function() {
                	Restorepromocode(promocode_id,flag);
                },
                No: function() {},
            }
        });

    });


    function Restorepromocode(promocode_id,flag)
    {
    	var promocode_id = promocode_id;
    	var flag = flag;    	

        request = $.ajax({
                type: "POST",
                url: base_URL+'ThirdAxisCon/Restorepromocode',
                data: {"promocode_id":promocode_id,"flag":flag},
        }); 
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


	
	$('#Promocode_Button').click(function(){
		$('.error').hide();

		if($('#promocode_name').val()=="")
		{
			$('.promocode_name').html("* Promo Code Name Cannot be empty");
			$('.promocode_name').show();
		}
		else if($('#promo_code').val()=="")
		{
			$('.promo_code').html("* Promo Code  Cannot be empty");
			$('.promo_code').show();
		}
		else if($('.promocode_from').val()=="")
		{
			$('.promocode_from_error').html("* Promo Code From Date Cannot be empty");
			$('.promocode_from_error').show();
		}
		else if($('.promocode_to').val()=="")
		{
			$('.promocode_to_error').html("* Promo Code To Date Cannot be empty");
			$('.promocode_to_error').show();
		}	
		else if($('#promocode_instaces').val()=="")
		{
			$('.promocode_instaces').html("* Promo Code No of instaces Cannot be empty");
			$('.promocode_instaces').show();
		}	
		else if($('#promocode_discount_type').val()=="")
		{
			$('.promocode_discount_type').html("* Promo Code discount type Cannot be empty");
			$('.promocode_discount_type').show();
		}	
		else if($('#promocode_discount_value').val()=="")
		{
			$('.promocode_discount_value').html("* Promo Code discount value Cannot be empty");
			$('.promocode_discount_value').show();
		}	
		else if($('#promocode_max_discount').val()=="")
		{
			$('.promocode_max_discount').html("* Promo Code discount Max Allowed Cannot be empty");
			$('.promocode_max_discount').show();
		}		
		else
		{
			
			if(mode=="new")
			{
				savepromocode();
			}
			else
			{
				updatepromocode();
			}			
			
		}		
	});
	
	$('#largeModal').on('show.bs.modal', function () {
	    $(this).find('form').trigger('reset');
	});	
	
	function savepromocode()
	{		
		var promo_code = $('#promo_code').val();
		var form = $('#Sub_Category_Form')[0];
		var data = new FormData(form);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/insertblanketpromocode',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			//console.log(js);
			var status = js.result
			if (status == "success") {
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Inserted Sucessfully',
					type: 'green',
						buttons: {
							Ok: function() {},
						}
				});
				$('#largeModal').modal('hide');
				refreshDetails();
			}
			else if (status == "error")
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Code is '+promo_code+' is already added. ',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}		
		});		
	}

	
	function updatepromocode()
	{
		var promo_code = $('#promo_code').val();
		var form = $('#Sub_Category_Form')[0];
		var data = new FormData(form);
		data.append("promocode_id",promocode_id);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/updateblanketpromocode',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			var status = js.result
			if (status == "success") {
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Updated Sucessfully',
					type: 'green',
						buttons: {
							Ok: function() {},
						}
				});
				$('#largeModal').modal('hide');
				refreshDetails();
			}
			else if (status == "error")
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Code is '+promo_code+' is already added. ',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}		
		});			
	}

	function refreshDetails()
	{
		$.when(getpromocodedetails()).done(function(){
			var table = $('#Sub_Category').DataTable();
			table.destroy();	
			dispPromocodeDetails(promocodeJSOM);				
		});		
	}



  $(document)
  .ajaxStart(function () {
    $(".loading").show();
  })
  .ajaxStop(function () {
    $(".loading").hide();
  });

});
