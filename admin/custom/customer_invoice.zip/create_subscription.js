$(document).ready(function() {

    var SubscriptionDetails, user_unique_id, mode, weeklyactivate;
    var biweklyselected=[];
    var monthlyselected=[];
    $.when(getsubscribeduserlist()).done(function() {
        dispsubscriptiondetails(SubscriptionDetails);
    });

    function getsubscribeduserlist() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getsubscribeduserlist',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                SubscriptionDetails = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    function dispsubscriptiondetails(JSON) {
        var i =1;
        $('#table_view_details').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [
					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": "user_name"
                }, {
                    "mDataProp": "user_unique_id"
                }, {
                    "mDataProp": function(data, type, full, meta) {
                        return '<a id="' + meta.row + '" class="btn viewproductss" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;  view</a>&nbsp;&nbsp;';
                    }
                }
            ]
        });
    }


    function refreshDetails() {
        $.when(getsubscribeduserlist()).done(function() {
            var table = $('#table_view_details').DataTable();
            table.destroy();
            dispsubscriptiondetails(SubscriptionDetails);
        });
    }

    $('#New_Category').click(function() {
        mode = "new";
        $('#largeModal').modal({
              backdrop: 'static',
             keyboard: false 
        });
    });

    $(document).on('change', "#user_unique_id", function() 
    {
        var user_unique_id= $('#user_unique_id').val();
        return $.ajax({
            url: base_URL+'ThirdAxisCon/getsubscribedproducts',
            type:'POST',
            data: {
                "user_unique_id":user_unique_id
            },
            success:function(data){
                var js = $.parseJSON(data);
                var weekly_subscribed_products = js.weekly_subscribed_products;
                var biweekly_subscribed_products = js.biweekly_subscribed_products;
                var monthly_subscribed_products = js.monthly_subscribed_products;

                $('.nav-tabs a[href="#home-b2"]').tab('show');

                $('.sun_prod').html('');
                $('.mon_prod').html('');
                $('.tue_prod').html('');
                $('.wed_prod').html('');
                $('.thu_prod').html('');
                $('.fri_prod').html('');
                $('.sat_prod').html('');

                if (weekly_subscribed_products.length>0) 
                {
                    for (var i = 0; i < weekly_subscribed_products.length; i++) 
                    {
                        if (weekly_subscribed_products[i].Sun.length>0) 
                        {
                            for (var j = 0; j < weekly_subscribed_products[i].Sun.length; j++) 
                            {
                                $('.sun_prod').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-5" class="weekly_prod_name">'+
                                            '<b>'+weekly_subscribed_products[i].Sun[j].prod_name+'</b>'+
                                        '</div>'+
                                       ' <div class="col-sm-2" class="weekly_prod_weight">'+
                                           'Unit : '+weekly_subscribed_products[i].Sun[j].prod_quantity+'  '+weekly_subscribed_products[i].Sun[j].unit_id+'<br>'+
                                           'Day : '+weekly_subscribed_products[i].Sun[j].subscribe_date+''+
                                        '</div>'+
                                        '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Sun[j].subscribed_products_id+'","add","'+weekly_subscribed_products[i].Sun[j].prod_code+'","'+weekly_subscribed_products[i].Sun[j].subscribe_quantity+'");\'>+</span> '+
                                            '<input style="margin-right: 0px;" readonly id="view_weeklyquantity" class="form-control cust_subscribe_input" type="text" name="view_weeklyquantity" value="'+weekly_subscribed_products[i].Sun[j].subscribe_quantity+'">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Sun[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Sun[j].prod_code+'","'+weekly_subscribed_products[i].Sun[j].subscribe_quantity+'");\'>-</span>'+
                                        '</div>'+
                                        '<div class="col-sm-2" class="weekly_prod_remove">'+
                                            '<span class="removeproducts" onclick=\'remove_subscribed_products("'+weekly_subscribed_products[i].Sun[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Sun[j].prod_code+'","'+weekly_subscribed_products[i].Sun[j].subscribe_quantity+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div></div></div>');
                            }
                        }
                        else
                        {
                            $('.sun_prod').append('No Record founded');
                        }
                        if (weekly_subscribed_products[i].Mon.length>0) 
                        {
                            for (var j = 0; j < weekly_subscribed_products[i].Mon.length; j++) 
                            {
                                $('.mon_prod').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-5" class="weekly_prod_name">'+
                                            '<b>'+weekly_subscribed_products[i].Mon[j].prod_name+'</b>'+
                                        '</div>'+
                                       ' <div class="col-sm-2" class="weekly_prod_weight">'+
                                           'Unit : '+weekly_subscribed_products[i].Mon[j].prod_quantity+'  '+weekly_subscribed_products[i].Mon[j].unit_id+'<br>'+
                                           'Day : '+weekly_subscribed_products[i].Mon[j].subscribe_date+''+
                                        '</div>'+
                                        '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Mon[j].subscribed_products_id+'","add","'+weekly_subscribed_products[i].Mon[j].prod_code+'","'+weekly_subscribed_products[i].Mon[j].subscribe_quantity+'");\'>+</span> '+
                                            '<input style="margin-right: 0px;" readonly id="view_weeklyquantity" class="form-control cust_subscribe_input" type="text" name="view_weeklyquantity" value="'+weekly_subscribed_products[i].Mon[j].subscribe_quantity+'">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Mon[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Mon[j].prod_code+'","'+weekly_subscribed_products[i].Mon[j].subscribe_quantity+'");\'>-</span>'+
                                        '</div>'+
                                        '<div class="col-sm-2" class="weekly_prod_remove">'+
                                            '<span class="removeproducts" onclick=\'remove_subscribed_products("'+weekly_subscribed_products[i].Mon[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Mon[j].prod_code+'","'+weekly_subscribed_products[i].Mon[j].subscribe_quantity+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div></div></div>');
                            }
                        }
                        else
                        {
                            $('.mon_prod').append('No Record founded');
                        }
                        if (weekly_subscribed_products[i].Tue.length>0) 
                        {
                            for (var j = 0; j < weekly_subscribed_products[i].Tue.length; j++) 
                            {
                                $('.tue_prod').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-5" class="weekly_prod_name">'+
                                            '<b>'+weekly_subscribed_products[i].Tue[j].prod_name+'</b>'+
                                        '</div>'+
                                       ' <div class="col-sm-2" class="weekly_prod_weight">'+
                                           'Unit : '+weekly_subscribed_products[i].Tue[j].prod_quantity+'  '+weekly_subscribed_products[i].Tue[j].unit_id+'<br>'+
                                           'Day : '+weekly_subscribed_products[i].Tue[j].subscribe_date+''+
                                        '</div>'+
                                        '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Tue[j].subscribed_products_id+'","add","'+weekly_subscribed_products[i].Tue[j].prod_code+'","'+weekly_subscribed_products[i].Tue[j].subscribe_quantity+'");\'>+</span> '+
                                            '<input style="margin-right: 0px;" readonly id="view_weeklyquantity" class="form-control cust_subscribe_input" type="text" name="view_weeklyquantity" value="'+weekly_subscribed_products[i].Tue[j].subscribe_quantity+'">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Tue[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Tue[j].prod_code+'","'+weekly_subscribed_products[i].Tue[j].subscribe_quantity+'");\'>-</span>'+
                                        '</div>'+
                                        '<div class="col-sm-2" class="weekly_prod_remove">'+
                                            '<span class="removeproducts" onclick=\'remove_subscribed_products("'+weekly_subscribed_products[i].Tue[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Tue[j].prod_code+'","'+weekly_subscribed_products[i].Tue[j].subscribe_quantity+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div></div></div>');
                            }
                        }
                        else
                        {
                            $('.tue_prod').append('No Record founded');
                        }
                        if (weekly_subscribed_products[i].Wed.length>0) 
                        {
                            for (var j = 0; j < weekly_subscribed_products[i].Wed.length; j++) 
                            {
                                $('.wed_prod').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-5" class="weekly_prod_name">'+
                                            '<b>'+weekly_subscribed_products[i].Wed[j].prod_name+'</b>'+
                                        '</div>'+
                                       ' <div class="col-sm-2" class="weekly_prod_weight">'+
                                           'Unit : '+weekly_subscribed_products[i].Wed[j].prod_quantity+'  '+weekly_subscribed_products[i].Wed[j].unit_id+'<br>'+
                                           'Day : '+weekly_subscribed_products[i].Wed[j].subscribe_date+''+
                                        '</div>'+
                                        '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Wed[j].subscribed_products_id+'","add","'+weekly_subscribed_products[i].Wed[j].prod_code+'","'+weekly_subscribed_products[i].Wed[j].subscribe_quantity+'");\'>+</span> '+
                                            '<input style="margin-right: 0px;" readonly id="view_weeklyquantity" class="form-control cust_subscribe_input" type="text" name="view_weeklyquantity" value="'+weekly_subscribed_products[i].Wed[j].subscribe_quantity+'">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Wed[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Wed[j].prod_code+'","'+weekly_subscribed_products[i].Wed[j].subscribe_quantity+'");\'>-</span>'+
                                        '</div>'+
                                        '<div class="col-sm-2" class="weekly_prod_remove">'+
                                            '<span class="removeproducts" onclick=\'remove_subscribed_products("'+weekly_subscribed_products[i].Wed[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Wed[j].prod_code+'","'+weekly_subscribed_products[i].Wed[j].subscribe_quantity+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div></div></div>');
                            }
                        }
                        else
                        {
                            $('.wed_prod').append('No Record founded');
                        }
                        if (weekly_subscribed_products[i].Thu.length>0) 
                        {
                            for (var j = 0; j < weekly_subscribed_products[i].Thu.length; j++) 
                            {
                                $('.thu_prod').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-5" class="weekly_prod_name">'+
                                            '<b>'+weekly_subscribed_products[i].Thu[j].prod_name+'</b>'+
                                        '</div>'+
                                       ' <div class="col-sm-2" class="weekly_prod_weight">'+
                                           'Unit : '+weekly_subscribed_products[i].Thu[j].prod_quantity+'  '+weekly_subscribed_products[i].Thu[j].unit_id+'<br>'+
                                           'Day : '+weekly_subscribed_products[i].Thu[j].subscribe_date+''+
                                        '</div>'+
                                        '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Thu[j].subscribed_products_id+'","add","'+weekly_subscribed_products[i].Thu[j].prod_code+'","'+weekly_subscribed_products[i].Thu[j].subscribe_quantity+'");\'>+</span> '+
                                            '<input style="margin-right: 0px;" readonly id="view_weeklyquantity" class="form-control cust_subscribe_input" type="text" name="view_weeklyquantity" value="'+weekly_subscribed_products[i].Thu[j].subscribe_quantity+'">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Thu[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Thu[j].prod_code+'","'+weekly_subscribed_products[i].Thu[j].subscribe_quantity+'");\'>-</span>'+
                                        '</div>'+
                                        '<div class="col-sm-2" class="weekly_prod_remove">'+
                                            '<span class="removeproducts" onclick=\'remove_subscribed_products("'+weekly_subscribed_products[i].Thu[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Thu[j].prod_code+'","'+weekly_subscribed_products[i].Thu[j].subscribe_quantity+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div></div></div>');
                            }
                        }
                        else
                        {
                            $('.thu_prod').append('No Record founded');
                        }
                        if (weekly_subscribed_products[i].Fri.length>0) 
                        {
                            for (var j = 0; j < weekly_subscribed_products[i].Fri.length; j++) 
                            {
                                $('.fri_prod').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-5" class="weekly_prod_name">'+
                                            '<b>'+weekly_subscribed_products[i].Fri[j].prod_name+'</b>'+
                                        '</div>'+
                                       ' <div class="col-sm-2" class="weekly_prod_weight">'+
                                           'Unit : '+weekly_subscribed_products[i].Fri[j].prod_quantity+'  '+weekly_subscribed_products[i].Fri[j].unit_id+'<br>'+
                                           'Day : '+weekly_subscribed_products[i].Fri[j].subscribe_date+''+
                                        '</div>'+
                                        '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Fri[j].subscribed_products_id+'","add","'+weekly_subscribed_products[i].Fri[j].prod_code+'","'+weekly_subscribed_products[i].Fri[j].subscribe_quantity+'");\'>+</span> '+
                                            '<input style="margin-right: 0px;" readonly id="view_weeklyquantity" class="form-control cust_subscribe_input" type="text" name="view_weeklyquantity" value="'+weekly_subscribed_products[i].Fri[j].subscribe_quantity+'">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Fri[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Fri[j].prod_code+'","'+weekly_subscribed_products[i].Fri[j].subscribe_quantity+'");\'>-</span>'+
                                        '</div>'+
                                        '<div class="col-sm-2" class="weekly_prod_remove">'+
                                            '<span class="removeproducts" onclick=\'remove_subscribed_products("'+weekly_subscribed_products[i].Fri[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Fri[j].prod_code+'","'+weekly_subscribed_products[i].Fri[j].subscribe_quantity+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div></div></div>');
                            }
                        }
                        else
                        {
                            $('.fri_prod').append('No Record founded');
                        }
                        if (weekly_subscribed_products[i].Sat.length>0) 
                        {
                            for (var j = 0; j < weekly_subscribed_products[i].Sat.length; j++) 
                            {
                                $('.sat_prod').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-5" class="weekly_prod_name">'+
                                            '<b>'+weekly_subscribed_products[i].Sat[j].prod_name+'</b>'+
                                        '</div>'+
                                       ' <div class="col-sm-2" class="weekly_prod_weight">'+
                                           'Unit : '+weekly_subscribed_products[i].Sat[j].prod_quantity+'  '+weekly_subscribed_products[i].Sat[j].unit_id+'<br>'+
                                           'Day : '+weekly_subscribed_products[i].Sat[j].subscribe_date+''+
                                        '</div>'+
                                        '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Sat[j].subscribed_products_id+'","add","'+weekly_subscribed_products[i].Sat[j].prod_code+'","'+weekly_subscribed_products[i].Sat[j].subscribe_quantity+'");\'>+</span> '+
                                            '<input style="margin-right: 0px;" readonly id="view_weeklyquantity" class="form-control cust_subscribe_input" type="text" name="view_weeklyquantity" value="'+weekly_subscribed_products[i].Sat[j].subscribe_quantity+'">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+weekly_subscribed_products[i].Sat[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Sat[j].prod_code+'","'+weekly_subscribed_products[i].Sat[j].subscribe_quantity+'");\'>-</span>'+
                                        '</div>'+
                                        '<div class="col-sm-2" class="weekly_prod_remove">'+
                                            '<span class="removeproducts" onclick=\'remove_subscribed_products("'+weekly_subscribed_products[i].Sat[j].subscribed_products_id+'","minus","'+weekly_subscribed_products[i].Sat[j].prod_code+'","'+weekly_subscribed_products[i].Sat[j].subscribe_quantity+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div></div></div>');
                            }
                        }
                        else
                        {
                            $('.sat_prod').append('No Record founded');
                        }
                    }
                }
                else
                {
                    $('.weekly_prod').append('No Record found');
                }


                $('.bi-weekly_prod').html('');

                if (biweekly_subscribed_products.length>0) 
                {
                    for (var j = 0; j < biweekly_subscribed_products.length; j++) 
                    {
                        $('.bi-weekly_prod').append('<div class="col-sm-12 bi-weekly_prod_class_name"> <div class="row"><div class="col-sm-5" class="bi-weekly_prod_name">'+
                                            '<b>'+biweekly_subscribed_products[j].prod_name+'</b>'+
                                        '</div>'+
                                       ' <div class="col-sm-2" class="bi-weekly_prod_weight">'+
                                           'Unit : '+biweekly_subscribed_products[j].prod_quantity+'  '+biweekly_subscribed_products[j].unit_id+'<br>'+
                                           'Day : '+biweekly_subscribed_products[j].subscribe_date+''+
                                        '</div>'+
                                        '<div class="col-sm-3" class="bi-weekly_prod_quantity">'+
                                            '<span class="pluseminusbtn form-control"   onclick=\'update_subscribed_prod_quantity("'+biweekly_subscribed_products[j].subscribed_products_id+'","add","'+biweekly_subscribed_products[j].prod_code+'","'+biweekly_subscribed_products[j].subscribe_quantity+'");\'>+</span> '+
                                            '<input style="margin-right: 0px;" readonly id="view_biweeklyquantity" class="form-control cust_subscribe_input" type="text" name="view_biweeklyquantity" value="'+biweekly_subscribed_products[j].subscribe_quantity+'">'+
                                            '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+biweekly_subscribed_products[j].subscribed_products_id+'","minus","'+biweekly_subscribed_products[j].prod_code+'","'+biweekly_subscribed_products[j].subscribe_quantity+'");\'>-</span>'+
                                        '</div>'+
                                        '<div class="col-sm-2" class="bi-weekly_prod_remove">'+
                                            '<span class="removeproducts" onclick=\'remove_subscribed_products("'+biweekly_subscribed_products[j].subscribed_products_id+'","minus","'+biweekly_subscribed_products[j].prod_code+'","'+biweekly_subscribed_products[j].subscribe_quantity+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div></div></div>');
                    }
                }
                else
                {
                    $('.bi-weekly_prod').append('No Record found');
                }


                $('.monthly_prod').html('');

                if (monthly_subscribed_products.length>0) 
                {
                    for (var k = 0; k < monthly_subscribed_products.length; k++) 
                    {
                        $('.monthly_prod').append('<div class="col-sm-12 monthly_prod_class_name"> <div class="row"><div class="col-sm-5" class="monthly_prod_name">'+
                                   '<b>'+monthly_subscribed_products[k].prod_name+'</b>'+
                                '</div>'+
                                '<div class="col-sm-2" class="monthly_prod_weight">'+
                                           'Unit : '+monthly_subscribed_products[k].prod_quantity+'  '+monthly_subscribed_products[k].unit_id+'<br>'+
                                           'Day : '+monthly_subscribed_products[k].subscribe_date+''+
                                '</div>'+
                                '<div class="col-sm-3" class="monthly_prod_quantity">'+
                                        '<span class="pluseminusbtn form-control" onclick=\'update_subscribed_prod_quantity("'+monthly_subscribed_products[k].subscribed_products_id+'","add","'+monthly_subscribed_products[k].prod_code+'","'+monthly_subscribed_products[k].subscribe_quantity+'");\'>+</span> '+
                                        '<input style="margin-right: 0px;" readonly id="view_monthly" class="form-control cust_subscribe_input" type="text" name="view_monthly" value="'+monthly_subscribed_products[k].subscribe_quantity+'">'+
                                        '<span class="pluseminusbtn form-control"  onclick=\'update_subscribed_prod_quantity("'+monthly_subscribed_products[k].subscribed_products_id+'","minus","'+monthly_subscribed_products[k].prod_code+'","'+monthly_subscribed_products[k].subscribe_quantity+'");\'>-</span>'+
                                '</div>'+
                                '<div class="col-sm-2" class="monthly_prod_remove">'+
                                    '<span class="removeproducts" onclick=\'remove_subscribed_products("'+monthly_subscribed_products[k].subscribed_products_id+'","minus","'+monthly_subscribed_products[k].prod_code+'","'+monthly_subscribed_products[k].subscribe_quantity+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                '</div></div></div> ');
                    }
                }
                else
                {
                    $('.monthly_prod').append('No Record found');
                }
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;
    });




    weeklysubscriptionquantity = function(type,value,name,id,classname)
    {
        if (value=="add") 
        {
            if (type=="weekly_quantity") 
            {
                document.getElementById(classname).classList.add("weekselected_flg");
                var quantity = $('#'+name+''+id+'').val();
                var total_qty = parseInt(quantity)+1;
                $('#'+name+''+id+'').val(total_qty);
                if (total_qty==0) 
                {
                    document.getElementById(classname).classList.remove("weekselected_flg");    
                    weeklyactivate=false;
                }
                else
                {
                    weeklyactivate=true;
                }
            }
            else if (type=="biweekly_quantity" || type=="monthly_quantity")
            {
                var quantity = $('#'+name+'').val();
                var total_qty = parseInt(quantity)+1;
                $('#'+name+'').val(total_qty);

            }
        }
        if (value=="minus") 
        {
            if (type=="weekly_quantity") 
            {
                var quantity = $('#'+name+''+id+'').val();
                weeklyactivate=false;
                document.getElementById(classname).classList.remove("weekselected_flg");
                if (quantity>0) 
                {
                    weeklyactivate=true;
                    var total_qty = parseInt(quantity)-1;
                    $('#'+name+''+id+'').val(total_qty);
                    if (total_qty==0) 
                    {
                        document.getElementById(classname).classList.remove("weekselected_flg");
                    }
                    else
                    {
                        document.getElementById(classname).classList.add("weekselected_flg");
                    }
                }
            }
            else if (type=="biweekly_quantity" || type=="monthly_quantity")
            {
                var quantity = $('#'+name+'').val();
                if (quantity>0) 
                {
                    var total_qty = parseInt(quantity)-1;
                    $('#'+name+'').val(total_qty);
                }
            }
        }
    }

    biweklyselectedfunction = function()
    {
        const biweklyselected = [];
        var chks = document.getElementsByClassName('visually-hidden-lable-biweekly');

        // var results = [];
        for (var i = 0; i < chks.length; i++) {
            if (chks[i].checked) {
                // console.log(chks[i].parentElement.firstChild.nextElementSibling);
                chks[i].parentElement.firstChild.nextElementSibling.classList.add("weekselected_flg")
                biweklyselected.push(chks[i].value);
                $('#selected_biweekly_date').val(chks[i].value);
            }
            else {
                chks[i].parentElement.firstChild.nextElementSibling.classList.remove("weekselected_flg")
            }
        }
    }

    monthlyselectedfunction = function()
    {
        const monthlyselected = [];
        var chks = document.getElementsByClassName('visually-hidden-lable-monthly');
        // var results = [];
        for (var i = 0; i < chks.length; i++) {
            if (chks[i].checked) {
                // console.log(chks[i].parentElement.firstChild.nextElementSibling);
                chks[i].parentElement.firstChild.nextElementSibling.classList.add("weekselected_flg")
                monthlyselected.push(chks[i].value);
                $('#selected_monthly_date').val(chks[i].value);
            }
            else {
                chks[i].parentElement.firstChild.nextElementSibling.classList.remove("weekselected_flg")
            }
        }
    }


    update_subscribed_prod_quantity = function(id,type,prod_code,value)
    {
        if (type=="add") 
        {
            var quantity = parseInt(value)+1;
        }
        else if (type=="minus") 
        {
            var quantity = parseInt(value)-1;
        }

        var user_unique_id = $('#user_unique_id').val();
        return $.ajax({
            url: base_URL+'ThirdAxisCon/updatesubscriptionquantity',
            type:'POST',
            data: {
                "subscribed_products_id":id,"quantity":quantity,"prod_code":prod_code,"user_unique_id":user_unique_id
            },
            success:function(data){
                var js = $.parseJSON(data);
                var status = js.status;
                if (status=='success') 
                {
                    var chks = document.getElementsByClassName('cust_sub_lable');
                    for (var i = 0; i < chks.length; i++) 
                    {
                        chks[i].classList.remove("weekselected_flg");
                    }
                    var chks = document.getElementsByClassName('display_biweekly_popup_content');
                    for (var i = 0; i < chks.length; i++) 
                    {
                        chks[i].classList.remove("weekselected_flg");
                    }
                    var chks = document.getElementsByClassName('display_monthly_popup_content');
                    for (var i = 0; i < chks.length; i++) 
                    {
                        chks[i].classList.remove("weekselected_flg");
                    }
                     var $select = $('#product_code').selectize();
                     var control = $select[0].selectize;
                     control.clear();

                    $('#subscription_form')[0].reset();
                    $('#selected_biweekly_date').val('');
                    $('#selected_monthly_date').val('');
                    $('#user_unique_id').val(user_unique_id);
                    $( "#user_unique_id" ).trigger( "change" );
                }
                else
                {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Sorry unnabale to add the product',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                }
   
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;
    }

    remove_subscribed_products = function(id,type,prod_code,value)
    {

        $.confirm({
            title: 'info',
            content: 'Are you sure you want to remove this product',
            type: 'blue',
            buttons: {
                ok: function() {
                    removefunction(id,type,prod_code,value);
                },
                cancel: function() {

                }
            }
        });
    }

    function removefunction(id,type,prod_code,value)
    {
        if (type=="add") 
        {
            var quantity = parseInt(value)+1;
        }
        else if (type=="minus") 
        {
            var quantity = parseInt(value)-1;
        }

        var user_unique_id = $('#user_unique_id').val();
        return $.ajax({
            url: base_URL+'ThirdAxisCon/removesubscriptionprod',
            type:'POST',
            data: {
                "subscribed_products_id":id,"quantity":quantity,"prod_code":prod_code,"user_unique_id":user_unique_id
            },
            success:function(data){
                var js = $.parseJSON(data);
                var status = js.status;
                if (status=='success') 
                {
                    var chks = document.getElementsByClassName('cust_sub_lable');
                    for (var i = 0; i < chks.length; i++) 
                    {
                        chks[i].classList.remove("weekselected_flg");
                    }
                    var chks = document.getElementsByClassName('display_biweekly_popup_content');
                    for (var i = 0; i < chks.length; i++) 
                    {
                        chks[i].classList.remove("weekselected_flg");
                    }
                    var chks = document.getElementsByClassName('display_monthly_popup_content');
                    for (var i = 0; i < chks.length; i++) 
                    {
                        chks[i].classList.remove("weekselected_flg");
                    }
                     var $select = $('#product_code').selectize();
                     var control = $select[0].selectize;
                     control.clear();

                    $('#subscription_form')[0].reset();
                    $('#selected_biweekly_date').val('');
                    $('#selected_monthly_date').val('');
                    $('#user_unique_id').val(user_unique_id);
                    $( "#user_unique_id" ).trigger( "change" );
                }
                else
                {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Sorry unnabale to add the product',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                }
   
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;
    }




    $(document).on('click', '#btnsubmitsubscriptionform', function() 
    {
        $('.error').hide();

        if ($('#user_unique_id').val()=='') 
        {
            $('.nav-tabs a[href="#Weekly"]').tab('show');
            $('.error_show_text').html('* Select the Customer list *');
            $('.error_show_text').show();
        }
        else if ($('#product_code').val()=='') 
        {
            $('.nav-tabs a[href="#Weekly"]').tab('show');
            $('.error_show_text').html('* Select the Product Name *');
            $('.error_show_text').show();
        }
        else if ($('#selected_biweekly_date').val()=='' && $('#biweeklyquantity').val()!=0) 
        {
            $('.nav-tabs a[href="#Bi-weekly"]').tab('show');
            $('.error_show_text').html('* Select the bi-weekly quantity to proceed next *');
            $('.error_show_text').show();
        }
        else if ($('#selected_biweekly_date').val()!='' && $('#biweeklyquantity').val()==0) 
        {
            $('.nav-tabs a[href="#Bi-weekly"]').tab('show');
            $('.error_show_text').html('* Select the bi-weekly date to proceed next *');
            $('.error_show_text').show();
        }
        else if ($('#selected_monthly_date').val()=='' && $('#monthlyquantity').val()!=0) 
        {
            $('.nav-tabs a[href="#Monthly"]').tab('show');
            $('.error_show_text').html('* Select the monthly quantity to proceed next *');
            $('.error_show_text').show();
        }
        else if ($('#selected_monthly_date').val()!='' && $('#monthlyquantity').val()==0) 
        {
            $('.nav-tabs a[href="#Monthly"]').tab('show');
            $('.error_show_text').html('* Select the monthly date to proceed next *');
            $('.error_show_text').show();
        }
        else if (weeklyactivate!=true && $('#selected_biweekly_date').val()=='' && $('#biweeklyquantity').val()==0 &&
            $('#selected_monthly_date').val()=='' && $('#monthlyquantity').val()==0) 
        {
            $('.nav-tabs a[href="#Weekly"]').tab('show');
            $('.error_show_text').html('* Select any date to continue next *');
            $('.error_show_text').show();
        }
        else
        {
            var user_unique_id = $('#user_unique_id').val();
            var form = $('#subscription_form')[0];
            var data = new FormData(form);
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/updatesubscriptioncustomers',
                method: "POST",
                data: data,
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    var js = $.parseJSON(data);
                    var status = js.status;
                    if (status=='success') 
                    {
                        var chks = document.getElementsByClassName('cust_sub_lable');
                        for (var i = 0; i < chks.length; i++) 
                        {
                            chks[i].classList.remove("weekselected_flg");
                        }
                        var chks = document.getElementsByClassName('display_biweekly_popup_content');
                        for (var i = 0; i < chks.length; i++) 
                        {
                            chks[i].classList.remove("weekselected_flg");
                        }
                        var chks = document.getElementsByClassName('display_monthly_popup_content');
                        for (var i = 0; i < chks.length; i++) 
                        {
                            chks[i].classList.remove("weekselected_flg");
                        }
                         var $select = $('#product_code').selectize();
                         var control = $select[0].selectize;
                         control.clear();

                        $('#subscription_form')[0].reset();
                        $('#selected_biweekly_date').val('');
                        $('#selected_monthly_date').val('');
                        $('#user_unique_id').val(user_unique_id);
                        $( "#user_unique_id" ).trigger( "change" );
                    }
                    else
                    {
                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Sorry unnabale to add the product',
                            type: 'red',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                    }
                },
                error: function() {
                    console.log("Error");
                }
            }); 
        }       
    });


    $(document).on('click', '#closesubscriptionmodelview', function() 
    {
        $('#largeviewModal').modal('hide');
    });

    $(document).on('click', '#closepurchasemodel', function() 
    {
        var user_unique_id = $('#user_unique_id').val();
        if (user_unique_id!='' && user_unique_id!=null) 
        {
            $.confirm({
                title: 'info',
                content: 'Are you sure you want to discard this update',
                type: 'blue',
                buttons: {
                    ok: function() {
                        request = $.ajax({
                            type: "POST",
                            url: base_URL + 'ThirdAxisCon/discardsubscriptionfynl',
                            data: {
                                "user_unique_id": user_unique_id
                            },
                            success: function(data) {
                                var js = $.parseJSON(data);
                                var status = js.status;
                                if (status=='success') 
                                {
                                    $('#largeModal').modal('hide');
                                    refreshDetails()
                                }
                                else
                                {
                                    $.confirm({
                                        icon: 'icon-close',
                                        title: 'Info',
                                        content: 'Sorry unnabale to add the product',
                                        type: 'red',
                                        buttons: {
                                            Ok: function() {},
                                        }
                                    });
                                }
                            },
                            error: function() {
                                console.log("Error");
                            }
                        });
                    },
                    cancel: function() {

                    }
                }
            });
        }
        else
        {
            $('#largeModal').modal('hide');
        }
    });

    $(document).on('click', '#updatesubscriptionfynl', function() 
    {
        $('.error').hide();
        var user_unique_id = $('#user_unique_id').val();
        if (user_unique_id!='' && user_unique_id!=null) 
        {
            $.confirm({
                title: 'info',
                content: 'Are you sure you want to update this data',
                type: 'blue',
                buttons: {
                    ok: function() {
                        request = $.ajax({
                            type: "POST",
                            url: base_URL + 'ThirdAxisCon/updatesubscriptionfynl',
                            data: {
                                "user_unique_id": user_unique_id
                            },
                            success: function(data) {
                                var js = $.parseJSON(data);
                                var status = js.status;
                                if (status=='success') 
                                {
                                    $.confirm({
                                        icon: 'icon-close',
                                        title: 'Info',
                                        content: 'Subscription Created Sucessfully',
                                        type: 'green',
                                        buttons: {
                                            Ok: function() {},
                                        }
                                    });
                                    $('#largeModal').modal('hide');
                                    refreshDetails()
                                }
                                else
                                {
                                    $.confirm({
                                        icon: 'icon-close',
                                        title: 'Info',
                                        content: 'Sorry unnabale to add the product',
                                        type: 'red',
                                        buttons: {
                                            Ok: function() {},
                                        }
                                    });
                                }
                            },
                            error: function() {
                                console.log("Error");
                            }
                        });
                    },
                    cancel: function() {

                    }
                }
            });
        }
        else
        {
            $('.nav-tabs a[href="#Weekly"]').tab('show');
            $('.error_show_text').html('* Add or remove any products to continue *');
            $('.error_show_text').show();
        }

    });



    $(document).on('click', '.viewproductss', function() {
        var r_index = $(this).attr('id');
        user_unique_id = SubscriptionDetails[r_index].user_unique_id;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/getsubscribedproducts',
            data: {
                "user_unique_id": user_unique_id
            },
        });
        request.done(function(response) {
            $('#largeviewModal').modal({
                  backdrop: 'static',
                 keyboard: false 
            });
            var js = $.parseJSON(response);
            var weekly_subscribed_products = js.weekly_subscribed_products;
            var biweekly_subscribed_products = js.biweekly_subscribed_products;
            var monthly_subscribed_products = js.monthly_subscribed_products;

            $('.nav-tabs a[href="#home-b2-view"]').tab('show');

            $('.sun_prod-view').html('');
            $('.mon_prod-view').html('');
            $('.tue_prod-view').html('');
            $('.wed_prod-view').html('');
            $('.thu_prod-view').html('');
            $('.fri_prod-view').html('');
            $('.sat_prod-view').html('');

            if (weekly_subscribed_products.length>0) 
            {
                for (var i = 0; i < weekly_subscribed_products.length; i++) 
                {
                    if (weekly_subscribed_products[i].Sun.length>0) 
                    {
                        for (var j = 0; j < weekly_subscribed_products[i].Sun.length; j++) 
                        {
                            $('.sun_prod-view').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-6" class="weekly_prod_name">'+
                                        '<b>'+weekly_subscribed_products[i].Sun[j].prod_name+'</b>'+
                                    '</div>'+
                                   ' <div class="col-sm-3" class="weekly_prod_weight">'+
                                       'Unit : '+weekly_subscribed_products[i].Sun[j].prod_quantity+'  '+weekly_subscribed_products[i].Sun[j].unit_id+'<br>'+
                                       'Day : '+weekly_subscribed_products[i].Sun[j].subscribe_date+''+
                                    '</div>'+
                                    '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                        'Quantity :'+weekly_subscribed_products[i].Sun[j].subscribe_quantity+''+
                                    '</div></div></div>');
                        }
                    }
                    else
                    {
                        $('.sun_prod-view').append('No Record founded');
                    }
                    if (weekly_subscribed_products[i].Mon.length>0) 
                    {
                        for (var j = 0; j < weekly_subscribed_products[i].Mon.length; j++) 
                        {
                            $('.mon_prod-view').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-6" class="weekly_prod_name">'+
                                        '<b>'+weekly_subscribed_products[i].Mon[j].prod_name+'</b>'+
                                    '</div>'+
                                   ' <div class="col-sm-3" class="weekly_prod_weight">'+
                                       'Unit : '+weekly_subscribed_products[i].Mon[j].prod_quantity+'  '+weekly_subscribed_products[i].Mon[j].unit_id+'<br>'+
                                       'Day : '+weekly_subscribed_products[i].Mon[j].subscribe_date+''+
                                    '</div>'+
                                    '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                        'Quantity :'+weekly_subscribed_products[i].Mon[j].subscribe_quantity+''+
                                    '</div></div></div>');
                        }
                    }
                    else
                    {
                        $('.mon_prod-view').append('No Record founded');
                    }
                    if (weekly_subscribed_products[i].Tue.length>0) 
                    {
                        for (var j = 0; j < weekly_subscribed_products[i].Tue.length; j++) 
                        {
                            $('.tue_prod-view').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-6" class="weekly_prod_name">'+
                                        '<b>'+weekly_subscribed_products[i].Tue[j].prod_name+'</b>'+
                                    '</div>'+
                                   ' <div class="col-sm-3" class="weekly_prod_weight">'+
                                       'Unit : '+weekly_subscribed_products[i].Tue[j].prod_quantity+'  '+weekly_subscribed_products[i].Tue[j].unit_id+'<br>'+
                                       'Day : '+weekly_subscribed_products[i].Tue[j].subscribe_date+''+
                                    '</div>'+
                                    '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                            'Quantity :'+weekly_subscribed_products[i].Tue[j].subscribe_quantity+''+
                                    '</div></div></div>');
                        }
                    }
                    else
                    {
                        $('.tue_prod-view').append('No Record founded');
                    }
                    if (weekly_subscribed_products[i].Wed.length>0) 
                    {
                        for (var j = 0; j < weekly_subscribed_products[i].Wed.length; j++) 
                        {
                            $('.wed_prod-view').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-3" class="weekly_prod_name">'+
                                        '<b>'+weekly_subscribed_products[i].Wed[j].prod_name+'</b>'+
                                    '</div>'+
                                   ' <div class="col-sm-3" class="weekly_prod_weight">'+
                                       'Unit : '+weekly_subscribed_products[i].Wed[j].prod_quantity+'  '+weekly_subscribed_products[i].Wed[j].unit_id+'<br>'+
                                       'Day : '+weekly_subscribed_products[i].Wed[j].subscribe_date+''+
                                    '</div>'+
                                    '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                        'Quantity :'+weekly_subscribed_products[i].Wed[j].subscribe_quantity+''+
                                    '</div></div></div>');
                        }
                    }
                    else
                    {
                        $('.wed_prod-view').append('No Record founded');
                    }
                    if (weekly_subscribed_products[i].Thu.length>0) 
                    {
                        for (var j = 0; j < weekly_subscribed_products[i].Thu.length; j++) 
                        {
                            $('.thu_prod-view').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-6" class="weekly_prod_name">'+
                                        '<b>'+weekly_subscribed_products[i].Thu[j].prod_name+'</b>'+
                                    '</div>'+
                                   ' <div class="col-sm-3" class="weekly_prod_weight">'+
                                       'Unit : '+weekly_subscribed_products[i].Thu[j].prod_quantity+'  '+weekly_subscribed_products[i].Thu[j].unit_id+'<br>'+
                                       'Day : '+weekly_subscribed_products[i].Thu[j].subscribe_date+''+
                                    '</div>'+
                                    '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                        'Quantity :'+weekly_subscribed_products[i].Thu[j].subscribe_quantity+''+
                                    '</div></div></div>');
                        }
                    }
                    else
                    {
                        $('.thu_prod-view').append('No Record founded');
                    }
                    if (weekly_subscribed_products[i].Fri.length>0) 
                    {
                        for (var j = 0; j < weekly_subscribed_products[i].Fri.length; j++) 
                        {
                            $('.fri_prod-view').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-6" class="weekly_prod_name">'+
                                        '<b>'+weekly_subscribed_products[i].Fri[j].prod_name+'</b>'+
                                    '</div>'+
                                   ' <div class="col-sm-3" class="weekly_prod_weight">'+
                                       'Unit : '+weekly_subscribed_products[i].Fri[j].prod_quantity+'  '+weekly_subscribed_products[i].Fri[j].unit_id+'<br>'+
                                       'Day : '+weekly_subscribed_products[i].Fri[j].subscribe_date+''+
                                    '</div>'+
                                    '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                        'Quantity :'+weekly_subscribed_products[i].Fri[j].subscribe_quantity+''+
                                    '</div></div></div>');
                        }
                    }
                    else
                    {
                        $('.fri_prod-view').append('No Record founded');
                    }
                    if (weekly_subscribed_products[i].Sat.length>0) 
                    {
                        for (var j = 0; j < weekly_subscribed_products[i].Sat.length; j++) 
                        {
                            $('.sat_prod-view').append('<div class="col-sm-12 weekly_prod_class_name"><div class="row"><div class="col-sm-6" class="weekly_prod_name">'+
                                        '<b>'+weekly_subscribed_products[i].Sat[j].prod_name+'</b>'+
                                    '</div>'+
                                   ' <div class="col-sm-3" class="weekly_prod_weight">'+
                                       'Unit : '+weekly_subscribed_products[i].Sat[j].prod_quantity+'  '+weekly_subscribed_products[i].Sat[j].unit_id+'<br>'+
                                       'Day : '+weekly_subscribed_products[i].Sat[j].subscribe_date+''+
                                    '</div>'+
                                    '<div class="col-sm-3" class="weekly_prod_quantity">'+
                                        'Quantity :'+weekly_subscribed_products[i].Sat[j].subscribe_quantity+''+
                                    '</div></div></div>');
                        }
                    }
                    else
                    {
                        $('.sat_prod-view').append('No Record founded');
                    }
                }
            }
            else
            {
                $('.weekly_prod-view').append('No Record found');
            }


            $('.bi-weekly_prod-view').html('');

            if (biweekly_subscribed_products.length>0) 
            {
                for (var j = 0; j < biweekly_subscribed_products.length; j++) 
                {
                    $('.bi-weekly_prod-view').append('<div class="col-sm-12 bi-weekly_prod_class_name"> <div class="row"><div class="col-sm-6" class="bi-weekly_prod_name">'+
                                        '<b>'+biweekly_subscribed_products[j].prod_name+'</b>'+
                                    '</div>'+
                                   ' <div class="col-sm-3" class="bi-weekly_prod_weight">'+
                                       'Unit : '+biweekly_subscribed_products[j].prod_quantity+'  '+biweekly_subscribed_products[j].unit_id+'<br>'+
                                       'Day : '+biweekly_subscribed_products[j].subscribe_date+''+
                                    '</div>'+
                                    '<div class="col-sm-3" class="bi-weekly_prod_quantity">'+
                                        'Quantity :'+biweekly_subscribed_products[j].subscribe_quantity+''+
                                    '</div></div></div>');
                }
            }
            else
            {
                $('.bi-weekly_prod-view').append('No Record found');
            }


            $('.monthly_prod-view').html('');

            if (monthly_subscribed_products.length>0) 
            {
                for (var k = 0; k < monthly_subscribed_products.length; k++) 
                {
                    $('.monthly_prod-view').append('<div class="col-sm-12 monthly_prod_class_name"> <div class="row"><div class="col-sm-6" class="monthly_prod_name">'+
                               '<b>'+monthly_subscribed_products[k].prod_name+'</b>'+
                            '</div>'+
                            '<div class="col-sm-3" class="monthly_prod_weight">'+
                                       'Unit : '+monthly_subscribed_products[k].prod_quantity+'  '+monthly_subscribed_products[k].unit_id+'<br>'+
                                       'Day : '+monthly_subscribed_products[k].subscribe_date+''+
                            '</div>'+
                            '<div class="col-sm-3" class="bi-weekly_prod_quantity">'+
                                'Quantity :'+monthly_subscribed_products[k].subscribe_quantity+''+
                            '</div></div></div> ');
                }
            }
            else
            {
                $('.monthly_prod-view').append('No Record found');
            }

        });
        
    });

    $('#largeModal').on('show.bs.modal', function() {
        var chks = document.getElementsByClassName('cust_sub_lable');
        for (var i = 0; i < chks.length; i++) 
        {
            chks[i].classList.remove("weekselected_flg");
        }
        var chks = document.getElementsByClassName('display_biweekly_popup_content');
        for (var i = 0; i < chks.length; i++) 
        {
            chks[i].classList.remove("weekselected_flg");
        }
        var chks = document.getElementsByClassName('display_monthly_popup_content');
        for (var i = 0; i < chks.length; i++) 
        {
            chks[i].classList.remove("weekselected_flg");
        }
         var $select = $('#product_code').selectize();
         var control = $select[0].selectize;
         control.clear();

         var $select = $('#user_unique_id').selectize();
         var control = $select[0].selectize;
         control.clear();

        $('#subscription_form')[0].reset();
    });


    $(document).on('keypress blur', '.numbersOnly', function() {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    });




    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});