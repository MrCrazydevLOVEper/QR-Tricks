$(document).ready(function() {

    var OfferDetailJSON, banner_id, mode,OfferproductDetailJSON,OfferDetailJSON;

    var date = new Date();
    date.setDate(date.getDate() - 1);
    var dateString = new Date(date.getTime() - (date.getTimezoneOffset() * 60000 )).toISOString().split("T")[0];
    $('#basic-datepicker').val(dateString);

    var currentdate = new Date();
    var currentdateString = new Date(currentdate.getTime() - (currentdate.getTimezoneOffset() * 60000 )).toISOString().split("T")[0];
    $('#basic-datepicker2').val(currentdateString);


    $.when(getdatewise_order()).done(function(){
            dispOfferDetails(OfferDetailJSON);                
    });


    function getdatewise_order()
    {
        // var from_date = $('#basic-datepicker').val();
        var todate = $('#basic-datepicker2').val();
        // var from_time = $('#from_time').val();
        // var to_time = $('#to_time').val();

        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getdatewise_order',
            type: 'POST',
            data: {
                // "from_date": from_date,
                "todate": todate,
                // "from_time": from_time,
                // "to_time": to_time
            },
            success: function(data) {
                //console.log(data);
                OfferDetailJSON = $.parseJSON(data);

                var table = $('#Main_Category').DataTable();
                table.destroy();

                // dispOfferDetails(OfferDetailJSON);
                $('.displaytable').show();
                
            $('.disptbl').show();

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }




    $('#Product_Button').click(function() 
    {
        // var from_date = $('#basic-datepicker').val();
        var todate = $('#basic-datepicker2').val();
        // var from_time = $('#from_time').val();
        // var to_time = $('#to_time').val();

        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getdatewise_order',
            type: 'POST',
            data: {
                // "from_date": from_date,
                "todate": todate,
                // "from_time": from_time,
                // "to_time": to_time
            },
            success: function(data) {
                //console.log(data);
                OfferDetailJSON = $.parseJSON(data);

                var table = $('#Main_Category').DataTable();
                table.destroy();

                dispOfferDetails(OfferDetailJSON);
                $('.displaytable').show();
                
            $('.disptbl').show();

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });

    });




    function dispOfferDetails(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var from_date = $('#basic-datepicker').val();
        var todate = $('#basic-datepicker2').val();
        var from_time = $('#from_time').val();
        var to_time = $('#to_time').val();

        var currentdate = new Date();
        var currentdateString = new Date(currentdate.getTime() - (currentdate.getTimezoneOffset() * 60000 )).toISOString().split("T")[0];

        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: 'Pik List Report on '+currentdateString+' ',
                    text: "Excel",
                     exportOptions: {
                        message: "Pik List Report From "+from_date+" "+ from_time+"  To "+todate+" "+ to_time+"",
                        columns: [ 1, 2, 3, 4]
                    },
                },            
                {
                    extend: 'pdf',
                    messageTop: "Pik List Report From "+from_date+" "+ from_time+"  To "+todate+" "+ to_time+"",
                    title: 'Pik List Report on '+currentdateString+' ',
                     exportOptions: {
                        columns: [ 1, 2, 3, 4]
                    },
                },
                    'print'
            ],
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                // {
                //     "mDataProp": function(data, type, full, meta) 
                //     {
                //         return ''+data.salse_date+'';                            
                //     }
                // },                 
                // {
                //     "mDataProp": function(data, type, full, meta) 
                //     {
                //         return ''+data.Username+'';                            
                //     }
                // },                 
                // {
                //     "mDataProp": function(data, type, full, meta) 
                //     {
                //         return ''+data.Mobile_no+'';                            
                //     }
                // },                
                // {
                //     "mDataProp": function(data, type, full, meta) 
                //     {
                //         return ''+data.user_unique_id+'';                            
                //     }
                // }, 

                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.product_type=='AP') 
                        {
                            return data.prod_code;
                        }
                        else if (data.product_type=='NAP') 
                        {
                            return '<p style="color:red"> Requested Product</p>';
                        }
                        else if (data.product_type=='slot_prod') 
                        {
                            return data.prod_code ;
                        }                            
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {

                        if (data.product_type=='AP') 
                        {
                            return ''+data.prod_name+' ( '+data.prod_quantity+' '+data.unit_id+' )';
                        }
                        else if (data.product_type=='NAP') 
                        {
                            return ''+data.product_name+' ( '+data.prod_unit+')';
                        }
                        else if (data.product_type=='slot_prod') 
                        {
                            return ''+data.prod_name+' ( '+data.prod_quantity+' '+data.unit_id+' )  <span style="color:red">[ Slot Product ]</span>';
                        }                           
                    }
                }, 
                // {
                //     "mDataProp": function(data, type, full, meta) 
                //     {
                //         return ''+data.salse_time+'';                            
                //     }
                // },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {

                        if (data.product_type=='AP') 
                        {
                            return 'AED '+data.prod_total_price;
                        }
                        else if (data.product_type=='NAP') 
                        {
                            return 'AED '+data.req_prod_total_price;
                        }
                        else if (data.product_type=='slot_prod') 
                        {
                            return 'AED '+data.prod_total_price;
                        }                             
                    }
                }, 
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.product_type=='AP') 
                        {
                            return ''+data.prod_total_qty+' '+data.converted_unit+'';
                        }
                        else if (data.product_type=='NAP') 
                        {
                             return ''+data.quantity+'';
                        }
                        else if (data.product_type=='slot_prod') 
                        {
                             return ''+data.prod_quantity+' '+data.unit_id+'';
                        } 
                    }
                },       
            ]
        });
    }


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });


});