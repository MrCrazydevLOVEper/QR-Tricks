$(document).ready(function() {

    var ReportDetailsJSON, area_master_id, mode;
    $.when(getreportdetails()).done(function() {
        dispDetailslist(ReportDetailsJSON);
    });

    function getreportdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/monthlysubscriptionreport',
            type: 'POST',
            success: function(data) 
            {
                ReportDetailsJSON = $.parseJSON(data);
            },
            error: function() 
            {
                console.log("Error");
            }
        });
    }

    function dispDetailslist(JSON) 
    {
        var i =1;
        $('#yalla_msubscription_report').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: ' Monthly Subscription Report',
                    text: "Export as Excel",
                     exportOptions: {
                        message: " Monthly Subscription Report",
                        columns: [ 1, 2, 3, 4, 5, 6, 7]
                    },
                },            
            ],
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.user_unique_id==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.user_unique_id;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.username==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.username;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.prod_code==null) 
                        {
                            return 'Guest User';
                        }
                        else
                        {
                            return data.prod_code;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.prod_name==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return  data.prod_name;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.prod_quantity==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return  ''+data.prod_quantity+' '+data.unit_id+'';   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.subscribe_quantity==null) 
                        {
                            return ' ';   
                        }
                        else
                        {
                            return ''+data.subscribe_quantity+' ';   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.subscribe_date==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.subscribe_date;   
                        }                        
                    }
                },
            ]
        });
    }

    function refreshDetails() {
        $.when(getreportdetails()).done(function() {
            var table = $('#yalla_msubscription_report').DataTable();
            table.destroy();
            dispDetailslist(ReportDetailsJSON);
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});