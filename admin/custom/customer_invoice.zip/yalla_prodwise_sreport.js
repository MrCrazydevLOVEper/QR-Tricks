$(document).ready(function() {

    var ReportDetailsJSON, area_master_id, mode;
    $.when(getreportdetails()).done(function() {
        dispDetailslist(ReportDetailsJSON);
    });

    function getreportdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/productwisesalesreport',
            type: 'POST',
            success: function(data) 
            {
                ReportDetailsJSON = $.parseJSON(data);
            },
            error: function() 
            {
                console.log("Error");
            }
        });
    }


    function dispDetailslist(JSON) 
    {
        var i =1;
        $('#yalla_cpurchase_report').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: 'Product wise sales Report',
                    text: "Export as Excel",
                     exportOptions: {
                        message: "Product wise sales Report",
                        columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                    },
                },            
            ],
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.prod_code==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.prod_code;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.product_name==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.product_name;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.mdName==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.mdName;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.sdName==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.sdName;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.mcName==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.mcName;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.scName==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.scName;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.prod_total_qty==null) 
                        {
                            return '0';   
                        }
                        else
                        {
                            return ''+data.prod_total_qty+' '+data.converted_unit+'';       
                        }
                    }
                }, 
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.prod_total_price==null) 
                        {
                           return 'AED 0.00';    
                        }
                        else
                        { 
                            return 'AED '+data.prod_total_price_avg+ '';  
                        }
                    }
                }, 
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.prod_total_cost_price_avg==null) 
                        {
                           return 'AED 0.00';    
                        }
                        else
                        { 
                            return 'AED '+data.prod_total_cost_price_avg+ '';  
                        }
                    }
                }, 
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.margin==null) 
                        {
                           return 'AED 0.00';    
                        }
                        else
                        { 
                            return 'AED '+data.margin+ '';  
                        }
                    }
                }, 
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.net_margin==null) 
                        {
                           return '0 %';    
                        }
                        else
                        { 
                            return ''+data.net_margin+ ' %';  
                        }
                    }
                }, 
            ]
        });
    }

    function refreshDetails() {
        $.when(getreportdetails()).done(function() {
            var table = $('#yalla_cpurchase_report').DataTable();
            table.destroy();
            dispDetailslist(ReportDetailsJSON);
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});