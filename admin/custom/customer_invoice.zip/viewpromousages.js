$(document).ready(function() {

    var PromousagelistJSON, notification_id, mode;
    $.when(getpromocaodeusagelist()).done(function() {
        dispArealist(PromousagelistJSON);
    });

    function getpromocaodeusagelist() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getpromocaodeusagelist',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                PromousagelistJSON = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    function dispArealist(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [

					{

                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                     "mDataProp": function(data, type, full, meta) {
                            return data.username+" "+data.lastname;
                    }
                },
                {
                    "mDataProp": "promo_code"
                },
                {
                    "mDataProp": "promocode_instaces"
                },
                {
                    "mDataProp": "promocode_avaliable"
                },
                {
                    "mDataProp": "last_used_date"
                },
            ]
        });
    }



    function refreshDetails() {
        $.when(getpromocaodeusagelist()).done(function() {
            var table = $('#Main_Category').DataTable();
            table.destroy();
            dispArealist(PromousagelistJSON);
        });
    }


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});