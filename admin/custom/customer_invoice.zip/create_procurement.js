$(document).ready(function() {

    // ==================================================================================================================//

    // Common function

    var products_added_fynl_array = [];
    var products_aval_code = [];
    var products_req_code = [];
    var products_req_code_dtl = [];
    var yb_user_address = [];
    var Addressjson;
    var mode;

    var t = $("tbody#rows-list tr:first-child").html();

    $("#product_type").val('Avaliableproduct');
    $("#product_type").trigger("change");

    $(document).ready(toggleElements, appendproducts);

    $(document).on('keypress blur', '.numbersOnly', function() {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    });


    // ==================================================================================================================//

    // Product append function

    function appendproducts() {

        var prod_discount = 0;
        var prod_bag_sub_total = 0;
        var prod_bag_total = 0;
        if (products_added_fynl_array.length > 0) {
            $('tbody#rows-list').html('');
            for (var i = 0; i < products_added_fynl_array.length; i++) 
            {

                if (products_added_fynl_array[i]["delete_flag"] != '0') 
                {
                    $('.appendproductfooter').show();
                    $("tbody#rows-list").append("<tr>" + t + "</tr>");

                    if (products_added_fynl_array[i]["product_type"] == 'Avaliableproduct' && products_added_fynl_array[i]["delete_flag"] != '0' ) 
                    {
                        $('.order_prod_name').last().append('' + products_added_fynl_array[i].prod_name + ' ( ' + products_added_fynl_array[i].product_unit_id + '  ' + products_added_fynl_array[i].unit_id + ')');
                        $('.order_prod_vendor_name').last().append('' + products_added_fynl_array[i].vendor_name + '');
                        $('.order_prod_qty').last().append('' + products_added_fynl_array[i].product_unit_id + '');

                        $('.order_prod_wst').last().append('' + products_added_fynl_array[i].purchase_wastages + '');
                        $('.order_prod_sal').last().append('' + products_added_fynl_array[i].salable_stock + '');
                        $('.order_prod_exp').last().append('' + products_added_fynl_array[i].Exp_date + '');

                        $('.order_prod_price').last().append('' + products_added_fynl_array[i].product_price + '');
                        $('.order_prod_total').last().append('' + products_added_fynl_array[i].product_total_price + '');
                        $('.order_prod_remove').last().append('<div class="col-sm-12">' +
                            '<span class="removeproducts" onclick=\'remove_products("' + i + '");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>' +
                            '</div>');
                    } 
                    else if (products_added_fynl_array[i]["product_type"] == 'Requestproduct' && products_added_fynl_array[i]["delete_flag"] != '0' ) {
                        $('.order_prod_name').last().append('' + products_added_fynl_array[i].prod_name + ' ( ' + products_added_fynl_array[i].product_unit_id + '  ' + products_added_fynl_array[i].unit_id + ')');
                        $('.order_prod_vendor_name').last().append('' + products_added_fynl_array[i].vendor_name + '');
                        $('.order_prod_qty').last().append('' + products_added_fynl_array[i].product_unit_id + '');

                        $('.order_prod_wst').last().append('' + products_added_fynl_array[i].purchase_wastages + '');
                        $('.order_prod_sal').last().append('' + products_added_fynl_array[i].salable_stock + '');
                        $('.order_prod_exp').last().append('' + products_added_fynl_array[i].Exp_date + '');

                        $('.order_prod_price').last().append('' + products_added_fynl_array[i].product_price + '');
                        $('.order_prod_total').last().append('' + products_added_fynl_array[i].product_total_price + '');
                        $('.order_prod_remove').last().append('<div class="col-sm-12">' +
                            '<span class="removeproducts" onclick=\'remove_products("' + i + '");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>' +
                            '</div>');
                    }

                    prod_bag_sub_total += parseFloat(products_added_fynl_array[i].product_total_price);
                }
            }
        } 
        else {
            $('tbody#rows-list').html('');
            $("tbody#rows-list").append("<tr>" + t + "</tr>");
        }
        // prod_discount = prod_bag_sub_total - prod_bag_total;
        $('#order_sub_total').val(parseFloat(prod_bag_sub_total).toFixed(2));
        // $('#order_discount').val(parseFloat(prod_discount).toFixed(2));
        // $('#order_total').val(parseFloat(prod_bag_total).toFixed(2));
    }

    update_prod_details = function(selected_index, product_code) {
        var product_quantity = 0;
        var product_price = 0.00;
        if ($('#product_quantity' + selected_index + '').val() != '') {
            product_quantity = $('#product_quantity' + selected_index + '').val();
        }

        if ($('#product_price' + selected_index + '').val() != '') {
            product_price = $('#product_price' + selected_index + '').val();
        }

        var sub_total = 0;
        sub_total = product_price * product_quantity;
        sub_total = sub_total.toFixed(2);

        for (var i = 0; i < products_added_fynl_array.length; i++) {
            if ("" + i + "" == "" + selected_index + "") {
                products_added_fynl_array[i]["product_quantity"] = product_quantity;
                products_added_fynl_array[i]["product_price"] = parseFloat(product_price).toFixed(2);
                products_added_fynl_array[i]["product_total_price"] = parseFloat(sub_total).toFixed(2);
            }
        }
        appendproducts();
    }

    remove_products = function(selected_index) {
        for (var i = 0; i < products_added_fynl_array.length; i++) {
            if ("" + i + "" == "" + selected_index + "") 
            {
                products_added_fynl_array[i]["delete_flag"]="0";
                // products_added_fynl_array.splice(i, 1);
            }
        }

        for (var i = 0; i < products_req_code_dtl.length; i++) {
            if ("" + i + "" == "" + selected_index + "") {
                products_req_code_dtl.splice(i, 1);
            }
        }

        var products_added_fynl_array_re = products_added_fynl_array.filter(function() {
            return true;
        });
        var products_req_code_dtl_re = products_req_code_dtl.filter(function() {
            return true;
        });

        products_added_fynl_array = [];
        products_req_code_dtl = [];

        products_added_fynl_array = products_added_fynl_array_re;
        products_req_code_dtl = products_req_code_dtl_re;


        // console.log(products_added_fynl_array);


        appendproducts();
    }

    $(document).on('keypress keyup', '#order_discount', function() 
    {
        if ($('#order_discount').val() == '') {
            $('#order_discount').val(0.00);
        }
        var sub_total = 0;
        var order_sub_total = $('#order_sub_total').val();
        var order_discount = $('#order_discount').val();

        if (parseFloat(order_sub_total) > parseFloat(order_discount)) 
        {
            sub_total = order_sub_total - order_discount;
        }
        $('#order_total').val(sub_total.toFixed(2));
    });

    // ==================================================================================================================//

    // Product Toggel function

    function toggleElements() {
        $("#product_type").trigger("change");
    }

    $(document).on('change', "#product_type", function() {
        if ($(this).val() == "Avaliableproduct") {
            var $select = $('#product_code').selectize();
            var control = $select[0].selectize;
            control.clear();
            $('.Avaliableproductshow').show();
            $('.productdetails_show').show();
            $('.Requestproductshow').hide();
            $('#product_code').val('');
            $('#product_code_req').val('');
            $('#unit_id').val('');
            $('#product_unit_id').val('');
            $('#product_price').val('0.00');
            $('#product_total_price').val('0.00');
            $('#purchase_wastages').val('');
            $('#salable_stock').val('');
            $('#labelider').html('');
            $('#labeliderqty').html('');
            $('#vendor_name').html('');
            $('.expiry_date_dd').val('');

        } else if ($(this).val() == "Requestproduct") {
            var $select = $('#product_code').selectize();
            var control = $select[0].selectize;
            control.clear();
            $('.Requestproductshow').show();
            $('.productdetails_show').show();
            $('.Avaliableproductshow').hide();
            $('#product_code').val('');
            $('#product_code_req').val('');
            $('#unit_id').val('');
            $('#product_unit_id').val('');
            $('#product_price').val('0.00');
            $('#product_total_price').val('0.00');
            $('#purchase_wastages').val('');
            $('#salable_stock').val('');
            $('#labelider').html('');
            $('#labeliderqty').html('');
            $('#vendor_name').html('');
            $('.expiry_date_dd').val('');
        } else {
            var $select = $('#product_code').selectize();
            var control = $select[0].selectize;
            control.clear();
            $('.Requestproductshow').hide();
            $('.Avaliableproductshow').hide();
            $('.productdetails_show').hide();
            $('#product_code').val('');
            $('#product_code_req').val('');
            $('#unit_id').val('');
            $('#product_unit_id').val('');
            $('#product_total_price').val('');
            $('#product_price').val('');
            $('#purchase_wastages').val('');
            $('#salable_stock').val('');
            $('#labelider').html('');
            $('#labeliderqty').html('');
            $('#vendor_name').html('');
            $('.expiry_date_dd').val('');
        }
    });


    // ==================================================================================================================//

    // Get Product Details

    $(document).on('change', "#product_code", function() {
        var prod_code = $(this).val();

        if (prod_code != '') {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getproductssforeditid',
                type: 'POST',
                data: {
                    "prod_code": prod_code
                },
                success: function(data) {
                    var productdetailsofid = $.parseJSON(data);
                    $('#product_id').val(productdetailsofid[0]["prod_id"]);
                    $('#produ_imgurl').val(productdetailsofid[0]["produ_imgurl"]);
                    $('#prod_name').val(productdetailsofid[0]["prod_name"]);
                },
                error: function() {
                    console.log("Error");
                }
            });
        }
    });

    // ==================================================================================================================//


    // Do Total calculation 

    $(document).on('change', "#unit_id", function() {
        var value = $(this).find(':selected').attr('data-id');
        $('#labelider').html('');
        $('#labelider').append('( per  ' + value + ' )');
        $('#labeliderqty').html('');
        $('#labeliderqty').append('( in  ' + value + ' )');

    });

    $(document).on('keypress keyup', '.purchase_ed_quantity', function() {
        var row = $(this).closest('tr');
        var order_ed_quantity = Number(row.find(".purchase_ed_quantity").val());

        if (order_ed_quantity == '') {
            row.find(".purchase_ed_quantity").val(1);
            order_ed_quantity = 1;
        }

        var order_ed_price_pt = Number(row.find(".purchase_ed_price").val());
        var total = 0.00;
        total = order_ed_quantity * order_ed_price_pt;
        var fyntotal = total.toFixed(2);
        row.find(".purchase_ed_price_pt").val(fyntotal);
        do_total(row);
    });

    $(document).on('keypress keyup', '.purchase_ed_price', function() {
        var row = $(this).closest('tr');
        var purchase_ed_price = Number(row.find(".purchase_ed_price").val());

        if (purchase_ed_price == '') {
            row.find(".purchase_ed_price").val(0.00);
        }

        var purchase_ed_quantity = Number(row.find(".purchase_ed_quantity").val());
        var total = 0.00;
        total = purchase_ed_quantity * purchase_ed_price;
        var fyntotal = total.toFixed(2);
        row.find(".purchase_ed_price_pt").val(fyntotal);
        do_total(row);
    });

    $(document).on('blur', '#product_total_price', function() {
        var product_unit_id = $('#product_unit_id').val();
        var product_total_price = $('#product_total_price').val();

        var value = $('#unit_id').find(':selected').attr('data-id');

        if (product_unit_id == '' || product_unit_id == null) {
            product_unit_id = 0;
        }
        if (product_total_price == '' || product_total_price == null) {
            product_total_price = 0;
        }


        $('#product_total_price').val(parseFloat(product_total_price).toFixed(2));

        if (product_unit_id < 1) {
            $('#labelider').html('');
            $('#labelider').append('( ' + product_unit_id + ' ' + value + ' )');
            $('#product_price').val(parseFloat(product_total_price).toFixed(2));
        } else {
            var product_price = parseFloat(product_total_price) / parseFloat(product_unit_id);
            $('#labelider').html('');
            $('#labelider').append('( per  ' + value + ' )');

            $('#product_price').val(parseFloat(product_price).toFixed(2));
        }
    });

    $(document).on('blur', '#product_unit_id', function() {
        var product_unit_id = $('#product_unit_id').val();
        var product_total_price = $('#product_total_price').val();
        var value = $('#unit_id').find(':selected').attr('data-id');
        $('#product_total_price').val(parseFloat(product_total_price).toFixed(2));

        if (product_unit_id < 1) {
            $('#labelider').html('');
            $('#labelider').append('( ' + product_unit_id + ' ' + value + ' )');
            $('#product_price').val(parseFloat(product_total_price).toFixed(2));
        } else {
            var product_price = parseFloat(product_total_price) / parseFloat(product_unit_id);
            $('#labelider').html('');
            $('#labelider').append('( per  ' + value + ' )');

            $('#product_price').val(parseFloat(product_price).toFixed(2));
        }
    });

    $(document).on('blur', '#purchase_wastages', function() {
        var purchase_wastages = $('#purchase_wastages').val();
        var product_unit_id = $('#product_unit_id').val();

        if (product_unit_id == 0 || product_unit_id == undefined || product_unit_id == null) {
            product_unit_id = 0;
        }
        if (purchase_wastages == '' || purchase_wastages == null) {
            purchase_wastages = 0
        }

        if (parseFloat(purchase_wastages) > parseFloat(product_unit_id)) {
            $('.purchase_wastages').html('* Purchase Wastages cannot be greater than Quantity Purchase');
            $('.purchase_wastages').show();
            $('#purchase_wastages').val('');
        } else {
            $('.purchase_wastages').html('');
            $('.purchase_wastages').show();
            var salable_stock = parseFloat(product_unit_id) - parseFloat(purchase_wastages);

            if (salable_stock < 0) {
                salable_stock = 0;
                $('#purchase_wastages').val(parseFloat(salable_stock));
            }
            $('#salable_stock').val(parseFloat(salable_stock));
        }
    });


    $(document).on('change', "#basic-datepicker2", function() {
        var value = $(this).val();
        var viewedtimes = "first2";

        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getpurchaseproductlistbydate',
            type: 'POST',
            data: {
                "product_purchase_date": value,
                "viewedtimes": viewedtimes
            },
            success: function(data) {
                var js = $.parseJSON(data);
                var status = js.result;
                var purchase_products = js.purchase_products;
                products_added_fynl_array = [];
                if (purchase_products.length > 0) {
                    mode = "update";
                    $('.purchase_date').val(purchase_products[0]["purchase_date"]);
                    $('#bill_no').val(purchase_products[0]["bill_no"]);
                    if (purchase_products[0]["purchase_products_list"].length > 0) {
                        for (var i = 0; i < purchase_products[0]["purchase_products_list"].length; i++) 
                        {
                            if (purchase_products[0]["purchase_products_list"][i]["purchase_product_type"] == 'Requestproduct') 
                            {
                                var prod_add_array = [{
                                    "product_type": purchase_products[0]["purchase_products_list"][i]["purchase_product_type"],
                                    "product_code": purchase_products[0]["purchase_products_list"][i]["purchase_product_name"],
                                    "unit_id": purchase_products[0]["purchase_products_list"][i]["purchase_product_unit"],
                                    "product_unit_id": purchase_products[0]["purchase_products_list"][i]["purchase_product_quantity"],
                                    "product_total_price": purchase_products[0]["purchase_products_list"][i]["total_product_price"],
                                    "product_price": purchase_products[0]["purchase_products_list"][i]["purchase_product_price"],
                                    "purchase_wastages": purchase_products[0]["purchase_products_list"][i]["purchase_wastages"],
                                    "salable_stock": purchase_products[0]["purchase_products_list"][i]["salable_stock"],
                                    "prod_name": purchase_products[0]["purchase_products_list"][i]["purchase_product"],
                                    "Exp_date": purchase_products[0]["purchase_products_list"][i]["expiry_date"],
                                    "product_code_req": purchase_products[0]["purchase_products_list"][i]["purchase_product_name"],
                                    "aging_wastages": purchase_products[0]["purchase_products_list"][i]["aging_wastages"],
                                    "sold_quantity": purchase_products[0]["purchase_products_list"][i]["sold_quantity"],
                                    "vendor_name": purchase_products[0]["purchase_products_list"][i]["vendor_name"],
                                    "purchase_products_id": purchase_products[0]["purchase_products_list"][i]["purchase_products_id"],
                                    "delete_flag": purchase_products[0]["purchase_products_list"][i]["delete_flag"]
                                }];

                                products_added_fynl_array.push(prod_add_array[0]);
                                products_req_code.push(purchase_products[0]["purchase_products_list"][i]["purchase_product_name"]);
                                products_req_code_dtl.push(purchase_products[0]["purchase_products_list"][i]["purchase_product_name"]);
                            }
                            if (purchase_products[0]["purchase_products_list"][i]["purchase_product_type"] == 'Avaliableproduct') 
                            {
                                var prod_add_array = [{
                                    "product_type": purchase_products[0]["purchase_products_list"][i]["purchase_product_type"],
                                    "product_code": purchase_products[0]["purchase_products_list"][i]["purchase_product_name"],
                                    "unit_id": purchase_products[0]["purchase_products_list"][i]["purchase_product_unit"],
                                    "product_unit_id": purchase_products[0]["purchase_products_list"][i]["purchase_product_quantity"],
                                    "product_total_price": purchase_products[0]["purchase_products_list"][i]["total_product_price"],
                                    "product_price": purchase_products[0]["purchase_products_list"][i]["purchase_product_price"],
                                    "purchase_wastages": purchase_products[0]["purchase_products_list"][i]["purchase_wastages"],
                                    "salable_stock": purchase_products[0]["purchase_products_list"][i]["salable_stock"],
                                    "prod_name": purchase_products[0]["purchase_products_list"][i]["purchase_product"],
                                    "Exp_date": purchase_products[0]["purchase_products_list"][i]["expiry_date"],
                                    "aging_wastages": purchase_products[0]["purchase_products_list"][i]["aging_wastages"],
                                    "sold_quantity": purchase_products[0]["purchase_products_list"][i]["sold_quantity"],
                                    "vendor_name": purchase_products[0]["purchase_products_list"][i]["vendor_name"],
                                    "product_code_req": "",
                                    "purchase_products_id": purchase_products[0]["purchase_products_list"][i]["purchase_products_id"],
                                    "delete_flag": purchase_products[0]["purchase_products_list"][i]["delete_flag"]
                                }];

                                products_added_fynl_array.push(prod_add_array[0]);
                                products_req_code.push(purchase_products[0]["purchase_products_list"][i]["purchase_product_name"]);
                                products_req_code_dtl.push(purchase_products[0]["purchase_products_list"][i]["purchase_product_name"]);
                            }
                            toggleElements();
                            appendproducts();
                        }

                    }
                } else {
                    mode = "new";
                    $('#bill_no').val('');
                    toggleElements();
                    appendproducts();
                }
            },
            error: function() {
                console.log("Error");
            }
        });

    });


    function do_total(elem) {
        var sub_total = 0;
        // var g_discount = 0;
        $(list).find(".purchase_ed_price_pt").each(function(e) {
            sub_total += Number($(this).val());
        });
        $('.purchased_total_amt').val(sub_total.toFixed(2));
    }

    // ==================================================================================================================//

    // Product submit function

    $(document).on('click', "#addproductsbtnn", function() {
        $('.error').hide();
        if ($('#product_type').val() == '') {
            $('.product_type').html('product type cannot be empty')
            $('.product_type').show();
        } else if ($('#product_type').val() == 'Avaliableproduct' && $('#product_code').val() == '') {
            $('.product_code').html('product code cannot be empty')
            $('.product_code').show();
        } else if ($('#product_type').val() == 'Requestproduct' && $('#product_code_req').val() == '') {
            $('.product_code_req').html('product name cannot be empty')
            $('.product_code_req').show();
        } else if ($('#unit_id').val() == '' || $('#unit_id').val() == null) {
            $('.unit_id').html('unit type cannot be empty')
            $('.unit_id').show();
        } else if ($('#product_unit_id').val() == '') {
            $('.product_unit_id').html('product total quantity cannot be empty')
            $('.product_unit_id').show();
        } else if ($('#product_total_price').val() == '') {
            $('.product_total_price').html('product total price cannot be empty')
            $('.product_total_price').show();
        } else if ($('#product_price').val() == '') {
            $('.product_price').html('product price cannot be empty')
            $('.product_price').show();
        } else if ($('#purchase_wastages').val() == '') {
            $('.purchase_wastages').html('product Wastages cannot be empty')
            $('.purchase_wastages').show();
        } else if ($('#salable_stock').val() == '') {
            $('.salable_stock').html('product salable stock cannot be empty')
            $('.salable_stock').show();
        } else if ($('#vendor_name').val() == '') {
            $('.vendor_name').html('vendor name cannot be empty')
            $('.vendor_name').show();
        } else {
            if ($('#product_type').val() == 'Requestproduct') {

                var prod_add_array = [{
                    "product_type": "" + $('#product_type').val() + "",
                    "product_code": "" + $('#product_code_req').val() + "",
                    "unit_id": "" + $('#unit_id').val() + "",
                    "product_unit_id": "" + $('#product_unit_id').val() + "",
                    "product_total_price": "" + $('#product_total_price').val() + "",
                    "product_price": "" + $('#product_price').val() + "",
                    "purchase_wastages": "" + $('#purchase_wastages').val() + "",
                    "salable_stock": "" + $('#salable_stock').val() + "",
                    "aging_wastages": "0",
                    "sold_quantity": "0",
                    "prod_name": "" + $('#product_code_req').val() + "",
                    "Exp_date": "" + $('.expiry_date_dd').val() + "",
                    "product_code_req": "" + $('#product_code_req').val() + "",
                    "vendor_name": "" + $('#vendor_name').val() + "",
                    "purchase_products_id": "0",
                    "delete_flag": "1"
                }];
                var n = products_req_code_dtl.includes($('#product_code_req').val());
                if (n == true) {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Product already added',
                        type: 'blue',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                } else {
                    products_added_fynl_array.push(prod_add_array[0]);
                    products_req_code.push($('#product_code_req').val());
                    products_req_code_dtl.push($('#product_code_req').val());
                }

            }
            if ($('#product_type').val() == 'Avaliableproduct') {
                var prod_add_array = [{
                    "product_type": "" + $('#product_type').val() + "",
                    "product_code": "" + $('#product_code').val() + "",
                    "unit_id": "" + $('#unit_id').val() + "",
                    "product_unit_id": "" + $('#product_unit_id').val() + "",
                    "product_total_price": "" + $('#product_total_price').val() + "",
                    "product_price": "" + $('#product_price').val() + "",
                    "purchase_wastages": "" + $('#purchase_wastages').val() + "",
                    "salable_stock": "" + $('#salable_stock').val() + "",
                    "aging_wastages": "0",
                    "sold_quantity": "0",
                    "prod_name": "" + $('#prod_name').val() + "",
                    "Exp_date": "" + $('.expiry_date_dd').val() + "",
                    "product_code_req": "" + $('#product_code_req').val() + "",
                    "vendor_name": "" + $('#vendor_name').val() + "",
                    "purchase_products_id": "0",
                    "delete_flag": "1"
                }];

                var n = products_req_code_dtl.includes($('#product_code').val());
                if (n == true) {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Product already added',
                        type: 'blue',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                } else {
                    products_added_fynl_array.push(prod_add_array[0]);
                    products_aval_code.push($('#product_code').val());
                    products_req_code_dtl.push($('#product_code').val());
                }

            }

            toggleElements();
            appendproducts();
        }
    });

    // ==================================================================================================================//

    // Product submit function

    $(document).on('click', "#submit_fynl_order", function() {
        $('.error').hide();
        if ($('#purchase_date').val() == '') {
            $('.purchase_date').html('* Eneter the purchase date')
            $('.purchase_date').show();
        } else if (products_added_fynl_array.length == 0) {
            $('.common_error_fn').html('* Please Add the Products to submit procurement')
            $('.common_error_fn').show();
        } else {

            if (mode=="new") 
            {
                return $.ajax({
                    url: base_URL + 'ThirdAxisCon/insertproductpurchased',
                    type: 'POST',
                    data: {
                        "products_added_fynl_array": products_added_fynl_array,
                        "purchase_date": $('.purchase_date').val(),
                        "bill_no": $('#bill_no').val()
                    },
                    success: function(data) {
                        var js = $.parseJSON(data);
                        var status = js.status;
                        var message = js.msg;

                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: '' + message + '',
                                type: 'green',
                                buttons: {
                                    Ok: function() {
                                        location.reload();
                                    },
                                }
                            });
                        } else if (status == "fail") {

                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: '' + message + '',
                                type: 'red',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                        }

                    },
                    error: function() {
                        console.log("Error");
                    }
                });
            }
            else
            {
                // console.log(mode);
                // console.log(products_added_fynl_array);
                return $.ajax({
                    url: base_URL + 'ThirdAxisCon/insertproductpurchased',
                    type: 'POST',
                    data: {
                        "products_added_fynl_array": products_added_fynl_array,
                        "purchase_date": $('.purchase_date').val(),
                        "bill_no": $('#bill_no').val()
                    },
                    success: function(data) {
                        var js = $.parseJSON(data);
                        var status = js.status;
                        var message = js.msg;

                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: '' + message + '',
                                type: 'green',
                                buttons: {
                                    Ok: function() {
                                        location.reload();
                                    },
                                }
                            });
                        } else if (status == "fail") {

                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: '' + message + '',
                                type: 'red',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                        }

                    },
                    error: function() {
                        console.log("Error");
                    }
                });
            }
        }
    });



    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});