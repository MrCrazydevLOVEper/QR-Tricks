$(document).ready(function() {

    var CustomerJSON, user_id, mode;
    var mobile_no=0;
    var email=0;
    var address_id='';
    CustomerClassificationRank();
    CustomerClassificationStatus();
    $.when(getcustomerslist()).done(function() {
        dispArealist(CustomerJSON);
    });;

    // customer classification start


    function CustomerClassificationRank(){
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getCustomerRankststus',
            type: 'POST',
            success: function(data) {
                console.log(data);

            },
            error: function() {
                console.log("Error");  
            }
        });
    }
    function CustomerClassificationStatus(){
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getCustomerStatus',
            type: 'POST',
            success: function(data) {
                console.log(data);

            },
            error: function() {
                console.log("Error");  
            }
        });
    }

    // customer classification end

    function getcustomerslist() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getcustomerslist',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                CustomerJSON = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    function dispArealist(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: 'User List',
                    text: "Export as Excel",
                     exportOptions: {
                        message: "User List",
                        columns: [ 1,2,3,4]
                    },
                },            
            ],
            "aoColumns": [

                    {
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": "user_unique_id"
                },
                {
                     "mDataProp": function(data, type, full, meta) {
                            return data.username+" "+data.lastname;
                    }
                },
                {
                    "mDataProp": "email"
                },
                {
                     "mDataProp": function(data, type, full, meta) {
                            return data.mobile_no_code+" "+data.mobile_no;
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                        return '<a id="' + meta.row + '" class="btn viewaddress" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;  view</a>&nbsp;&nbsp;';

                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                        return '<a id="' + meta.row + '" class="btn add_address" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;  add </a>&nbsp;&nbsp;';

                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  Active</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Deactive</a>&nbsp;&nbsp;';

                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.referred_by==null) 
                        {
                            return '-';
                        }
                        else
                        {
                            return data.referred_by;    
                        }
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.total_referals==null) 
                        {
                            return '0';
                        }
                        else
                        {
                            return data.total_referals;    
                        }
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.yalla_credits==null) 
                        {
                            return '0';
                        }
                        else
                        {
                            return data.yalla_credits;    
                        }
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.yalla_money==null) 
                        {
                            return '0';
                        }
                        else
                        {
                            return data.yalla_money;    
                        }
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.yalla_status==null) 
                        {
                            return 'Bronze';
                        }
                        else
                        {
                            return data.yalla_status;    
                        }
                    }
                },
                {
                     "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.yalla_rank==null) 
                        {
                            return '0';
                        }
                        else
                        {
                            return data.yalla_rank;    
                        }
                    }
                },
            ]
        });
    }

    $(document).on('click', '.viewaddress', function() { 

        var r_index = $(this).attr('id');
        var user_unique_id = CustomerJSON[r_index].user_unique_id;
        
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/getcustomersaddresslist',
            data: {
                "user_unique_id": user_unique_id
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            // var status = js.result
            $('#notificationmodelmsgmodel').modal('show');
            $('#display_addes_details').html('');

            if (js.length>0) 
            {
                for (var i = 0; i < js.length; i++) 
                {
                    $('#display_addes_details').append('<div class="col-sm-12 row"> <div class="col-sm-4">'+
                                                                    '<p style="margin: 5px;">'+js[i]["username"]+' ,</p><p  style="margin: 5px;">'+js[i]["flat_no"]+', '+js[i]["building_name"]+', '+js[i]["landmark"]+'</p><p  style="margin: 5px;">'+js[i]["area"]+', '+js[i]["city"]+'.</p><br>'+
                                                                '</div>'+
                                                                '<div class="col-sm-3">'+
                                                                    '<br><br>'+
                                                                    '<p id="addresseditbtn" onclick=\'editAddress("'+js[i]["username"]+'","'+js[i]["email"]+'","'+js[i]["mobile_no"]+'","'+js[i]["flat_no"]+'","'+js[i]["building_name"]+'","'+js[i]["landmark"]+'","'+js[i]["city"]+'","'+js[i]["area"]+'","'+js[i]["address_type"]+'","'+js[i]["address_id"]+'","'+js[i]["user_unique_id"]+'");\'><i class="fa fa-edit" aria-hidden="true"></i>&nbsp;  Edit </p>'+
                                                                '</div> </div> '); 
                }
            }
            else
            {
                $('#display_addes_details').append('<p>No record founded</p>');
                // $('#addresseditbtn').append('');
            }
        });
    });


    $(document).on('click', '.Btnhidden', function() 
    {
        var r_index = $(this).attr('id');
        user_unique_id = CustomerJSON[r_index].user_unique_id;
        var flag=0;
        $.confirm({
            title: 'Delete',
            content: 'Are you sure you want to deactivate this user',
            type: 'blue',
            buttons: {
                ok: function() {
                    request = $.ajax({
                        type: "POST",
                        url: base_URL + 'ThirdAxisCon/activate_r_deactivate_customer',
                        data: {
                            "user_unique_id": user_unique_id,"flag":flag
                        },
                        success: function(data) {
                            //                            $("#image-display").load(" #image-display > *");
                            var js = $.parseJSON(data);
                            var status = js.status;
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Deleted Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                            refreshDetails();
                        },
                        error: function() {
                            console.log("Error");
                        }
                    });
                },
                cancel: function() {

                }
            }
        });
    });  

    $(document).on('click', '.BtnRestore', function() 
    {
        var r_index = $(this).attr('id');
        user_unique_id = CustomerJSON[r_index].user_unique_id;
        var flag=1;
        $.confirm({
            title: 'Delete',
            content: 'Are you sure you want to activate this user',
            type: 'blue',
            buttons: {
                ok: function() {
                    request = $.ajax({
                        type: "POST",
                        url: base_URL + 'ThirdAxisCon/activate_r_deactivate_customer',
                        data: {
                            "user_unique_id": user_unique_id,"flag":flag
                        },
                        success: function(data) {
                            //                            $("#image-display").load(" #image-display > *");
                            var js = $.parseJSON(data);
                            var status = js.status;
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Deleted Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                            refreshDetails();
                        },
                        error: function() {
                            console.log("Error");
                        }
                    });
                },
                cancel: function() {

                }
            }
        });
    });   


    function refreshDetails() {
        $.when(getcustomerslist()).done(function() {
            var table = $('#Main_Category').DataTable();
            table.destroy();
            dispArealist(CustomerJSON);
        });
    }

    $('#New_Category').click(function() {
        mode = "new";
        $('#largeModal').modal('show');
    });


    $( "#mobile_no" ).blur(function() 
    {
        var mobile_no = $('#mobile_no').val();  
        if (mobile_no!='' && mobile_no!=null) 
        {
            request = $.ajax({
                type: "POST",
                url: base_URL + 'ThirdAxisCon/checkavaliablity',
                data: {
                    "mobile_no": mobile_no,"type":"mobile"
                },
            });
            request.done(function(response) {
                var js = $.parseJSON(response);
                var status = js.status
                if (status=='success') 
                {
                    $('.mobile_no').html("Mobile no already registered");
                    $('.mobile_no').show();
                    mobile_no = 1;
                }
                else
                {
                    $('.error').hide();
                    mobile_no = 0;

                }
            });
        }      
    });

    $( "#email" ).blur(function() 
    {
        var email = $('#email').val();  
        if (email!='' && email!=null) 
        {
            request = $.ajax({
                type: "POST",
                url: base_URL + 'ThirdAxisCon/checkavaliablity',
                data: {
                    "email": email,"type":"email"
                },
            });
            request.done(function(response) {
                var js = $.parseJSON(response);
                var status = js.status
                if (status=='success') 
                {
                    $('.email').html("Email Id already registered");
                    $('.email').show();
                    email=1;
                }
                else
                {
                    $('.error').hide();
                    email=0;
                }
            });
        }      
    });


    $(document).on('click', '#createcustomer_Form_submit', function() 
    {
        $('.error').hide();
        if ($('#username').val() == "") {
            $('.username').html("* Please Fill Name");
            $('.username').show();
        }  
        else if ($('#mobile_no').val() == "") {
            $('.mobile_no').html("* Please Fill Mobile no");
            $('.mobile_no').show();
        }  
        else if ($('#email').val() == "") {
            $('.email').html("* Please Fill Email Address");
            $('.email').show();
        }  
        else if ($('#password').val() == "") {
            $('.password').html("* Please Fill Password");
            $('.password').show();
        }   
        else if (mobile_no== 1) {
            $('.mobile_no').html("Mobile no already registered");
            $('.mobile_no').show();
        }   
        else if (email==1) {
            $('.email').html("Email Id already registered");
            $('.email').show();
        } 
        else if ($('#password').val().length<6) {
            $('.password').html("Password Must have minimum 6 character");
            $('.password').show();
        } 
        else 
        {
            if (mode == "new") 
            {
                insertnewcustomer();
            } 
            else 
            {
                updatenewcustomer();
            }
        }
    });

    function insertnewcustomer() {
        var form = $('#createcustomer_Form')[0];
        var data = new FormData(form);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/insertnewcustomers',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.status;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Customer Created Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } 
            else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: ''+js.msg+'',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }
        });
    }


    $(document).on('click', '.add_address', function() 
    {
        mode = "new";
        $('#addressModal').modal('show');
        var r_index = $(this).attr('id');
        var user_unique_id = CustomerJSON[r_index].user_unique_id;
        $('#user_unique_id').val(user_unique_id);

    });

    editAddress = function(username,email,mobile_no,flat_no,building_name,landmark,city,area,address_type,address_iddd,user_unique_id) 
    {
        mode == "update";
        $('#notificationmodelmsgmodel').modal('hide');
        // $('#addressModal').modal('show');
        $('#add_username').val(username);
        $('#add_mobile_no').val(mobile_no);
        $('#add_email').val(email);
        $('#flat_no').val(flat_no);
        $('#building_name').val(building_name);
        $('#landmark').val(landmark);
        // $('#area').val(area);
        $('#city').val(city);
        $('#address_type').val(address_type);
        $('#user_unique_id').val(user_unique_id);
        $('#address_id').val(address_iddd);
        // var address_id = address_id;

        // console.log(area);
        setTimeout(function(){ 
            $('#addressModal').modal(); 
        }, 300);
        setTimeout(function(){ 
            var $select = $("#area").selectize();
            var selectize = $select[0].selectize;
            var yourDefaultIds = area; 
             yourDefaultIds = yourDefaultIds.replace(/\s+/g, '_');
            // console.log(selectize);
            selectize.setValue(yourDefaultIds);
        }, 500);
        
    }


    $(document).on('click', '#createaddress_Form_submit', function() 
    {
        $('.error').hide();
        if ($('#add_username').val() == "") {
            $('.add_username').html("* Please Fill Name");
            $('.add_username').show();
        }  
        else if ($('#add_mobile_no').val() == "") {
            $('.add_mobile_no').html("* Please Fill Mobile no");
            $('.add_mobile_no').show();
        }  
        else if ($('#add_email').val() == "") {
            $('.add_email').html("* Please Fill Email Address");
            $('.add_email').show();
        }  
        else if ($('#flat_no').val() == "") {
            $('.flat_no').html("* Please Fill Flat no");
            $('.flat_no').show();
        } 
        else if ($('#area').val() == "") {
            $('.area').html("* Please Select Area");
            $('.area').show();
        }  
        else if ($('#city').val() == "") {
            $('.city').html("* Please Fill city");
            $('.city').show();
        }  
        else if ($('#address_type').val() == "") {
            $('.address_type').html("* Please Select address type");
            $('.address_type').show();
        }  

        else 
        {
            if (mode == "new") 
            {
                insertnewaddress();
            } 
            else 
            {
                updatenewaddress();
            }
        }
    });


    function insertnewaddress() {
        var form = $('#createaddress_Form')[0];
        var data = new FormData(form);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/insertnewaddres',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.status;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Address Created Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#addressModal').modal('hide');
                refreshDetails();
            } 
            else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: ''+js.msg+'',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }
        });
    }

    function updatenewaddress() {
        var form = $('#createaddress_Form')[0];
        var data = new FormData(form);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/updatenewaddres',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.status;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Address Created Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#addressModal').modal('hide');
                refreshDetails();
            } 
            else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: ''+js.msg+'',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }
        });
    }





    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});