$(document).ready(function() {

    var searchkeywords, mode, BannerproductDetailJSON,filtered_prod;

    $.when(getbannerproductsDetails()).done(function() {
        getbrandlistdata();
    });

    function getbannerproductsDetails() 
    {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/gethotsellerproducts',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                BannerproductDetailJSON = $.parseJSON(data);
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }

    $(document).on('change', '#md_code', function() {
        var md_code = $('#md_code').val();
        $('#sd_code').val('');
        $('#sd_code').html('');
        $('#sd_code').append("<option value=''>Select the Sub Department</option>");
        $('#mc_code').val('');
        $('#mc_code').html('');
        $('#mc_code').append("<option value=''>Select the Main Category</option>");
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        if(md_code!='')
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getSubDepartment',
                type: 'POST',
                data: {
                    "md_code": md_code
                },
                success: function(data) {
                    SubDepatmentJSON = $.parseJSON(data);
                    for (var i = 0; i < SubDepatmentJSON.length; i++) {
                        $('#sd_code').append("<option value='" + SubDepatmentJSON[i].sd_code + "'>" + SubDepatmentJSON[i].sdName + " ( " + SubDepatmentJSON[i].sd_code + " )</option>");
                        //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                    }
                    getbrandlistdata();
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            getbrandlistdata();
        }
    });


    $(document).on('change', '#sd_code', function() {
        var md_code = $('#md_code').val();
        var sd_code = $('#sd_code').val();
        $('#mc_code').val('');
        $('#mc_code').html('');
        $('#mc_code').append("<option value=''>Select the Main Category</option>");
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        if(md_code!='' && sd_code!='')
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getMainCategory',
                type: 'POST',
                data: {
                    "sd_code": sd_code,
                    "md_code": md_code
                },
                success: function(data) {
                    MainCategoryJSON = $.parseJSON(data);
                   $('#mc_code').html('');
                   $('#mc_code').append("<option value=''>Select the Main Category</option>");
                    for (var i = 0; i < MainCategoryJSON.length; i++) {
                        $('#mc_code').append("<option value='" + MainCategoryJSON[i].mc_code + "'>" + MainCategoryJSON[i].mcName + " ( " + MainCategoryJSON[i].mc_code + " )</option>");
                        //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                    }
                    getbrandlistdata();
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            getbrandlistdata();
        }

    });


    $(document).on('change', '#mc_code', function() {
        var md_code = $('#md_code').val();
        var sd_code = $('#sd_code').val();
        var mc_code = $('#mc_code').val();
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        if(md_code!='' && sd_code!='' && mc_code!='')
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getSubCategory',
                type: 'POST',
                data: {
                    "sd_code": sd_code,
                    "md_code": md_code,
                    "mc_code": mc_code
                },
                success: function(data) {
                    MainCategoryJSON = $.parseJSON(data);
                   $('#sc_code').html('');
                   $('#sc_code').append("<option value=''>Select the Sub Category</option>");
                    for (var i = 0; i < MainCategoryJSON.length; i++) {
                        $('#sc_code').append("<option value='" + MainCategoryJSON[i].sc_code + "'>" + MainCategoryJSON[i].scName + " ( " + MainCategoryJSON[i].sc_code + " )</option>");
                        //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                    }
                    getbrandlistdata();
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            getbrandlistdata();
        }
    });

    $(document).on('change', '#sc_code', function() {
         getbrandlistdata();

    });

    function getbrandlistdata()
    {
        var md_code = 0;
        var sd_code = 0;
        var mc_code = 0;
        var sc_code = 0;

        if($('#md_code').val()!='')
        {
            md_code = $('#md_code').val();
        }
        if($('#sd_code').val()!='')
        {
            sd_code = $('#sd_code').val();
        }
        if($('#mc_code').val()!='')
        {
            mc_code = $('#mc_code').val();
        }
        if($('#sc_code').val()!='')
        {
            sc_code = $('#sc_code').val();
        }

        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getbrandnamelist',
            type: 'POST',
            data: {
                "sd_code": sd_code,
                "md_code": md_code,
                "mc_code": mc_code,
                "sc_code": sc_code
            },
            success: function(data) {
                BrandJson = $.parseJSON(data);
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
                for (var i = 0; i < BrandJson.length; i++) {
                    $('#brand_name').append("<option value='" + BrandJson[i].brand_name + "'>" + BrandJson[i].brand_name + "</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
                // $('#sd_code').val(subdepartmentid);
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    $('#Product_Button').click(function() 
    {
        if ($('#md_code').val()!="" || $('#sd_code').val()!="" || $('#mc_code').val()!="" || $('#sc_code').val()!="" || $('#brand_name').val()!="" ) 
        {
            var md_code =0;
            var sd_code =0;
            var mc_code =0;
            var sc_code =0;
            var brand_name =0;

            if($('#md_code').val()!='')
            {
                md_code = $('#md_code').val();
            }
            if($('#sd_code').val()!='')
            {
                sd_code = $('#sd_code').val();
            }
            if ($('#mc_code').val()!='')
            {
                mc_code = $('#mc_code').val();
            }
            if ($('#sc_code').val()!='')
            {
                sc_code = $('#sc_code').val();
            }
            if ($('#brand_name').val()!='')
            {
                brand_name = $('#brand_name').val();
            }


            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getallproductsfilter',
                type: 'POST',
                data: {
                    "md_code": md_code,
                    "sd_code": sd_code,
                    "mc_code": mc_code,
                    "sc_code":sc_code,
                    "brand_name": brand_name
                },
                success: function(data) {
                    filtered_prod = $.parseJSON(data);
                    // console.log(result);
                    // OfferDetailJSON = $.parseJSON(data);
                    dispOfferDetails(filtered_prod);

                    
                $('.disptbl').show();
                $('.disptbloffer').hide();

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Please Select and click filter',
                type: 'red',
                buttons: {
                    Ok: function() {},
                }
            });
        }
    });

    function dispOfferDetails(JSON) {

        $('#offer_table').DataTable().destroy();
        var i =1;

        var myTable  = $('#offer_table').DataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            columnDefs: [{
                orderable: false,
                targets: 0,
            }],

            order: [
                [1, 'asc'],
            ],
            "aoColumns": [

                {
                    "mDataProp": function (data, type, full, meta) 
                    {
                        return '<input type="checkbox" class="select-checkbox" value="'+data.prod_code+'" data-attr-prod_id="'+data.prod_id+'"  name="user_idkes" >';
                    },
                },

                {
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },

                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.prod_name+"";                    
                    }
                },      
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.prod_code+"";                    
                    }
                },      
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.produ_imgurl !== null)
                        //return "<a href="+data.produ_imgurl+" target='_blank'>Click to view Image</a>";
                        //return "<img src="+data.produ_imgurl+" width=100>";
                            return "<div class='pro-im'>" +
                            "<img src='" + data.produ_imgurl + "' alt='user' width=100>" +
                            "<div class='pro-img-overlay'>" +
                            "<ul class='pro-img-overlay-1'>" +
                            "<li class='el-item'>" +
                            "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href='" + data.produ_imgurl + "'>" +
                            "<i class='fa fa-eye'></i></a>" +
                            "</li>" +
                            "</ul></div></div>";
                        else
                            return '';
                    }
                }
            ]
        });
    }


    $('input[name="selectAllcheck2"]').click(function()
    {
        var table = $('#offer_table').DataTable();
        if($(this).prop("checked") == true)
        {
            table.$('td > input:checkbox').each(function () 
            {
                table.$("input[name='user_idkes']").prop('checked',true);
            }); 
            // $.each($("input[name='user_idkes']"), function(){
            //     $("input[name='user_idkes']").prop('checked',true);
            // });
        }
        else if($(this).prop("checked") == false)
        {
            table.$('td > input:checkbox').each(function () 
            {
                table.$("input[name='user_idkes']").prop('checked',false);
            }); 
        }
    });


    $(document).on('click','#buttonactivatiesde',function()
    {
        var table = $('#offer_table').DataTable();
        // var d = table.row( this ).data();

        // console.log(table);

        var searchkey = $('#searchkeywords').val();
        var prod_id = [];
        var prod_code = [];

        table.$('td > input:checkbox').each(function () {
                    // If checkbox is checked
                    if (this.checked) {
                     //Your code for example
                        prod_code.push($(this).val());
                        prod_id.push($(this).attr('data-attr-prod_id'));
                    }
            }); 

        // $.each($("input[name='user_idkes']:checked"), function()
        // {
        //     console.log($(this).val());
        //     // prod_code.push($(this).val());
        //     // prod_id.push($(this).attr('data-attr-prod_id'));
        // });        
        var emp_arr =  prod_code.join(",");
        var emp_prod_id =  prod_id.join(",");


        if(prod_id.length<=0)
        {
            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Please Select any product to add under this banner',
                type: 'red',
                buttons: {
                    Ok: function() {},
                }
            });
        }
        else
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/updatesearchkeywordss',
                type: 'POST',
                data: {
                    "prod_list":emp_arr,
                    "emp_prod_id":emp_prod_id,
                    "search_key": searchkey,
                },
                success: function(data) 
                {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Product Added successfully',
                        type: 'green',
                        buttons: {
                            Ok: function() {
                                $( "#Product_Button" ).trigger( "click" );
                            },
                        }
                    });
                    
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }

    }); 


    

    $(document).on('click', '#idrefresh', function() {
            window.location.reload();
    });


    function refreshDetails() {
        $.when(getbannerproductsDetails()).done(function() {
            var table = $('#offer_product_table').DataTable();
            table.destroy();
            dispBannerproductDetails(BannerproductDetailJSON);
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});