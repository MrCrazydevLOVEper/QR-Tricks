$(document).ready(function() {

    var ReportDetailsJSON, area_master_id, mode;
    $.when(getreportdetails()).done(function() {
        dispDetailslist(ReportDetailsJSON);
    });

    function getreportdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/CustomerDetailReport',
            type: 'POST',
            success: function(data) 
            {
                ReportDetailsJSON = $.parseJSON(data);
            },
            error: function() 
            {
                console.log("Error");
            }
        });
    }


    function dispDetailslist(JSON) 
    {
        var i =1;
        $('#yalla_cdetails_report').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: 'Customer Detail Report',
                    text: "Export as Excel",
                     exportOptions: {
                        message: "Customer Detail Report",
                        columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 ,13, 14, 15]
                    },
                },            
            ],
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": "user_unique_id"
                },
                {
                    "mDataProp": "username_last"
                },
                {
                    "mDataProp": "mobile_no"
                },
                {
                    "mDataProp": "email"
                },
                {
                    "mDataProp": "area"
                },
                {
                    "mDataProp": "order_count"
                },
                {
                    "mDataProp": "total_price"
                },
                {
                    "mDataProp": "avg_order_value"
                },
                {
                    "mDataProp": "yalla_status"
                },
                {
                    "mDataProp": "yalla_rank"
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.flat_no!=null) 
                        {
                            return ''+ data.flat_no+', '+ data.building_name+''+ data.landmark+' , '+ data.city+' ,'+ data.area+' .';    
                        }
                        else
                        {
                            return '';   
                        }
                        
                    }
                }, 
                {
                    "mDataProp": "signup_date"
                },
                {
                    "mDataProp": "total_referals"
                },
                {
                    "mDataProp": "active_subscription"
                },
                {
                    "mDataProp": "yalla_credits"
                },
            ]
        });
    }

    function refreshDetails() {
        $.when(getreportdetails()).done(function() {
            var table = $('#yalla_cdetails_report').DataTable();
            table.destroy();
            dispDetailslist(ReportDetailsJSON);
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});