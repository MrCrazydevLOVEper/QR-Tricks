$(document).ready(function() {

    var BannerImageJSON, banner_id, mode;
    var imageoneinserted='';
    var imagetwoinserted='';
    $.when(getBrandBannerDetails()).done(function() {
        dispBrandBannerDetails(BannerImageJSON);
    });

    function getBrandBannerDetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getBrandBannerDetails',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                BannerImageJSON = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    function dispBrandBannerDetails(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.mobile_imageurl !== null)
                        //return "<a href="+data.mobile_imageurl+" target='_blank'>Click to view Image</a>";
                        //return "<img src="+data.mobile_imageurl+" width=100>";
                            return "<div class='pro-im'>" +
                            "<img src=" + data.mobile_imageurl + " alt='user' width=100>" +
                            "<div class='pro-img-overlay'>" +
                            "<ul class='pro-img-overlay-1'>" +
                            "<li class='el-item'>" +
                            "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href=" + data.mobile_imageurl + ">" +
                            "<i class='mdi mdi-magnify-plus'></i></a>" +
                            "</li>" +
                            "</ul></div></div>";
                        else
                            return '';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.web_imageurl !== null)
                        //return "<a href="+data.web_imageurl+" target='_blank'>Click to view Image</a>";
                        //return "<img src="+data.web_imageurl+" width=100>";
                            return "<div class='pro-im'>" +
                            "<img src=" + data.web_imageurl + " alt='user' width=100>" +
                            "<div class='pro-img-overlay'>" +
                            "<ul class='pro-img-overlay-1'>" +
                            "<li class='el-item'>" +
                            "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href=" + data.web_imageurl + ">" +
                            "<i class='mdi mdi-magnify-plus'></i></a>" +
                            "</li>" +
                            "</ul></div></div>";
                        else
                            return '';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  visible</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Hidden</a>&nbsp;&nbsp;';;

                    }
                }, {
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },
            ]
        });
    }

    $('#New_Category').click(function() {
        mode = "new";
        $('#largeModal').modal('show');
    });

    $(document).on('click', '.BtnEdit', function() {
        mode = "update";
        var r_index = $(this).attr('id');
        banner_id = BannerImageJSON[r_index].banner_id;
        $('#largeModal').modal('show');

        if(BannerImageJSON[r_index].mobile_imageurl!='')
        {
            imageoneinserted = BannerImageJSON[r_index].mobile_imageurl;
            $('#img_namee1').show();
            $('#img_namee1').html('');
            $('#img_namee1').append('<div class="image-display" id="image-display"><div><img src=" '+ BannerImageJSON[r_index].mobile_imageurl + '" class="user-update-image" alt="user profile" width="100px" style="padding-top: 15px;cursor:pointer"></div><div style="cursor:pointer"  class="image-delete-icon image-delete" id="dispimg_namee1">Delete and add new &nbsp; &nbsp; <i class="fa fa-bitbucket image-delete" ></i></div> </div>');
            $('#mobile_imageurl').prop('disabled', true);
        }
        if(BannerImageJSON[r_index].web_imageurl!='')
        {
            imagetwoinserted = BannerImageJSON[r_index].web_imageurl;
            $('#img_namee2').show();
            $('#img_namee2').html('');
            $('#img_namee2').append('<div class="image-display" id="image-display"><div><img src=" '+ BannerImageJSON[r_index].web_imageurl + '" class="user-update-image" alt="user profile" width="100px" style="padding-top: 15px;cursor:pointer"></div><div style="cursor:pointer" class="image-delete-icon image-delete" id="dispimg_namee2"> Delete and add new &nbsp; &nbsp; <i class="fa fa-bitbucket image-delete" ></i></div> </div>');
            $('#web_imageurl').prop('disabled', true);
        }
    });


    $(document).on('click','#dispimg_namee1',function(){
        $('#img_namee1').hide();
        $('#mobile_imageurl').prop('disabled', false);
        imageoneinserted='';
    }); 

    $(document).on('click','#dispimg_namee2',function(){
        $('#img_namee2').hide();
        $('#web_imageurl').prop('disabled', false);
        imagetwoinserted='';
    }); 



    $(document).on('click', '.BtnDelete', function() {
        mode = "delete";
        var r_index = $(this).attr('id');
        banner_id = BannerImageJSON[r_index].banner_id;
        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Delete this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                    request = $.ajax({
                        type: "POST",
                        url: base_URL + 'ThirdAxisCon/deleteBrandbannerimage',
                        data: {
                            "banner_id": banner_id
                        },
                    });
                    request.done(function(response) {
                        var js = $.parseJSON(response);
                        var status = js.result
                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Deleted Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                            refreshDetails();
                        } else {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Are you Sure Do you want to Delete this Data',
                                type: 'blue',
                                buttons: {
                                    No: function() {},
                                }
                            });
                        }

                    });
                },
                No: function() {},
            }
        });

    });

    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        banner_id = BannerImageJSON[r_index].banner_id;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreMainDepartmentData(banner_id,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        banner_id = BannerImageJSON[r_index].banner_id;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreMainDepartmentData(banner_id,flag);
                },
                No: function() {},
            }
        });

    });


    function RestoreMainDepartmentData(banner_id,flag)
    {
    	var banner_id = banner_id;
    	var flag = flag;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/RestoreBrandbanerimage',
            data: {
                "banner_id": banner_id,"flag":flag
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


    $('#banner_submit').click(function() {
        $('.error').hide();
        if ($('#mobile_imageurl').val() == ""&& mode == "new") {
            $('.mobile_imageurl').html("* Please Select the image ");
            $('.mobile_imageurl').show();
        }
        else if ($('#web_imageurl').val() == "" && mode == "new") {
            $('.web_imageurl').html("* Please Select the image ");
            $('.web_imageurl').show();
        }
        else if (imageoneinserted=="" && mode == "update" && $('#mobile_imageurl').val() == "" ) {
            $('.mobile_imageurl').html("* Please Select the image ");
            $('.mobile_imageurl').show();
        }
        else if (imagetwoinserted=="" && mode == "update" && $('#web_imageurl').val() == "") {
            $('.web_imageurl').html("* Please Select the image ");
            $('.web_imageurl').show();
        }
        else {
            if (mode == "new") {
                saveBannerimage();
            } else {
                updateBannerimage();
            }

        }
    });

    function saveBannerimage() {
        var form = $('#bannerimagesform')[0];
        var data = new FormData(form);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/insertBrandbannerimages',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Inserted Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }
        });
    }

    function refreshDetails() {
        $.when(getBrandBannerDetails()).done(function() {
            var table = $('#Main_Category').DataTable();
            table.destroy();
            dispBrandBannerDetails(BannerImageJSON);
        });
    }

    function updateBannerimage() {
        var form = $('#bannerimagesform')[0];
        var data = new FormData(form);
        data.append("banner_id", banner_id);
        data.append("imageoneinserted",imageoneinserted);
        data.append("imagetwoinserted",imagetwoinserted);

        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/updateBrandbannerimage',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } else {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }		
        });
    }

    $('#largeModal').on('show.bs.modal', function() {
        $(".no").hide();
        $('#img_namee1').html('');
        $('#mobile_imageurl').prop('disabled', false);
        $('#img_namee2').html('');
        $('#web_imageurl').prop('disabled', false);



        $(this).find('form').trigger('reset');
    });


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});