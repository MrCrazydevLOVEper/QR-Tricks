$(document).ready(function() {

    var InventorydetailsJSON, banner_id, mode,OfferproductDetailJSON,InventorydetailsJSON;

    $.when(getinventorydetails()).done(function(){
            dispgingdetails(InventorydetailsJSON);                
    });


    function getinventorydetails()
    {

        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getinventorydetails',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                InventorydetailsJSON = $.parseJSON(data);
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }

    function dispgingdetails(JSON) {
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.prd_code==null) 
                        {
                            return ''+data.purchase_product_name+' (<span style="color:red"> Requested Product</span>)';
                        }
                        else
                        {
                            return ''+data.prd_code+' - '+data.prod_name+'';
                        }
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                       return ''+data.procured_quantity+'';                           
                    }
                }, 
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.purchase_wastages+'';                            
                    }
                }, 
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.aging_wastages+'';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.sold_quantity+'';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.salable_stock+'';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.avg_inv_cost+'';
                    }
                },
                // {
                //     "mDataProp": function(data, type, full, meta) 
                //     {
                //         return ''+data.day6+'';
                //     }
                // },       
            ]
        });
    }


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });


});