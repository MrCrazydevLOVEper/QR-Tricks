$(document).ready(function() {

	var referandearnJSON,refer_and_earn_id,mode;
	
	$('#Formdata_details_submit').click(function(){
		$('.error').hide();

		if($('#msg_title').val()=="")
		{
			$('.msg_title').html("* Enter the Title");
			$('.msg_title').show();
		}
		else if($('#msg_content').val()=="")
		{
			$('.msg_content').html("* Enter the Content");
			$('.msg_content').show();
		}			
		else
		{
			sendnewnotifications();			
		}		
	});

	
	function sendnewnotifications()
	{		
		var form = $('#Formdata_details')[0];
		var data = new FormData(form);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/sendnewnotifications',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			var status = js.result
			if (status == "success") {
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Notification Sent Sucessfully',
					type: 'green',
						buttons: {
							Ok: function() {
									window.location.href = base_URL+"ThirdAxisCon/app_notifications";
							},
						}
				});
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}		
		});		
	}


  $(document)
  .ajaxStart(function () {
    $(".loading").show();
  })
  .ajaxStop(function () {
    $(".loading").hide();
  });

});
