$(document).ready(function() {

    var OfferDetailJSON, banner_id, mode,OfferproductDetailJSON,BrandJson;
    var imageoneinserted='';
    var imagetwoinserted='';

    var subdepartmentid = '';
    var maincategoryid = '';
    var subcategoryid = ''; 

    $('.main-department-valss').hide();
    $('.sub-department-valss').hide();
    $('.main-category-valss').hide();
    $('.sub-category-valss').hide();
    $('.brand-valss').hide();
    $('.searchapply').hide();
    $('.offer_title').show();
    $('.disptbloffer').show();

    $.when(getofferproductDetails()).done(function() {
        dispOfferproductDetails(OfferproductDetailJSON);
    });


    function getofferDetails() {

        var offer_type = $('#offer_type').val();
        var table = $('#offer_table').DataTable();
        table.destroy();

        if (offer_type=='main_dept') 
        {
            return $.ajax({
                url: base_URL + '/ThirdAxisCon/main_department',
                type: 'POST',
                success: function(data) {
                    //console.log(data);
                    OfferDetailJSON = $.parseJSON(data);
                    dispOfferDetails(OfferDetailJSON);
                    
                $('.disptbl').show();

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            OfferDetailJSON = [];
            dispOfferDetails(OfferDetailJSON);
        }
    }

    function getofferproductDetails() {

            return $.ajax({
                url: base_URL + '/ThirdAxisCon/getofferedproducts',
                type: 'POST',
                success: function(data) {
                    //console.log(data);
                    OfferproductDetailJSON = $.parseJSON(data);
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
    }


    $(document).on('change', '#offer_type', function() 
    {
        var offer_type = $('#offer_type').val();

        if (offer_type=='') 
        {
            $(".col-sm-3").css({"max-width": "22%"});
            $('.main-department-valss').hide();
            $('.sub-department-valss').hide();
            $('.main-category-valss').hide();
            $('.sub-category-valss').hide();
            $('.brand-valss').hide();
            $('.searchapply').hide();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            $('.disptbl').hide();
            $('#brand_name').val('');
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
            $('.offer_title').show();
            $('.disptbloffer').hide();

        }
        else if (offer_type=='main_dept') 
        {
            $(".col-sm-3").css({"max-width": "22%"});
            $('.main-department-valss').hide();
            $('.sub-department-valss').hide();
            $('.main-category-valss').hide();
            $('.sub-category-valss').hide();
            $('.brand-valss').show();
            $('.searchapply').show();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            $('#brand_name').val('');
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
             $('.offer_title').hide();
            $('.disptbloffer').hide();
            getofferDetails();
            getbrandlistdata();

        }
        else if (offer_type=='sub_dept') 
        {
            $(".col-sm-3").css({"max-width": "22%"});
            $('.main-department-valss').show();
            $('.sub-department-valss').hide();
            $('.main-category-valss').hide();
            $('.sub-category-valss').hide();
            $('.brand-valss').show();
            $('.searchapply').show();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            $('#brand_name').val('');
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
             $('.offer_title').hide();
            $('.disptbl').hide();
            $('.disptbloffer').hide();
        }
        else if (offer_type=='main_cat') 
        {
            $(".col-sm-3").css({"max-width": "22%"});
            $('.main-department-valss').show();
            $('.sub-department-valss').show();
            $('.main-category-valss').hide();
            $('.sub-category-valss').hide();
            $('.brand-valss').show();
            $('.searchapply').show();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            $('#brand_name').val('');
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
             $('.offer_title').hide();
            $('.disptbl').hide();
            $('.disptbloffer').hide();
        }
        else if (offer_type=='sub_cat') 
        {
            $(".col-sm-3").css({"max-width": "22%"});
            $('.main-department-valss').show();
            $('.sub-department-valss').show();
            $('.main-category-valss').show();
            $('.sub-category-valss').hide();
            $('.brand-valss').show();
            $('.searchapply').show();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            $('#brand_name').val('');
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
             $('.offer_title').hide();
            $('.disptbl').hide();
            $('.disptbloffer').hide();
        }
        else if (offer_type=='ind_products') 
        {
            $(".col-sm-3").css({"max-width": "25%"});
            $('.main-department-valss').show();
            $('.sub-department-valss').show();
            $('.main-category-valss').show();
            $('.sub-category-valss').show();
            $('.brand-valss').show();
            $('.searchapply').show();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            $('#brand_name').val('');
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
             $('.offer_title').hide();
            $('.disptbl').hide();
            $('.disptbloffer').hide();
        }
        else if (offer_type=='brand_prods') 
        {
            $(".col-sm-3").css({"max-width": "25%"});
            $('.main-department-valss').hide();
            $('.sub-department-valss').hide();
            $('.main-category-valss').hide();
            $('.sub-category-valss').hide();
            $('.brand-valss').show();
            $('.searchapply').show();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            $('#brand_name').val('');
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
             $('.offer_title').hide();
            $('.disptbl').hide();
            $('.disptbloffer').hide();
            getbrandlistdata();
        }
    });

    $(document).on('change', '#md_code', function() {
        var md_code = $('#md_code').val();
        $('#sd_code').val('');
        $('#sd_code').html('');
        $('#sd_code').append("<option value=''>Select the Sub Department</option>");
        $('#mc_code').val('');
        $('#mc_code').html('');
        $('#mc_code').append("<option value=''>Select the Main Category</option>");
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getSubDepartment',
            type: 'POST',
            data: {
                "md_code": md_code
            },
            success: function(data) {
                SubDepatmentJSON = $.parseJSON(data);


                for (var i = 0; i < SubDepatmentJSON.length; i++) {
                    $('#sd_code').append("<option value='" + SubDepatmentJSON[i].sd_code + "'>" + SubDepatmentJSON[i].sdName + " ( " + SubDepatmentJSON[i].sd_code + " )</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
                getbrandlistdata();
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    });


    $(document).on('change', '#sd_code', function() {
        var md_code = $('#md_code').val();
        var sd_code = $('#sd_code').val();
        $('#mc_code').val('');
        $('#mc_code').html('');
        $('#mc_code').append("<option value=''>Select the Main Category</option>");
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getMainCategory',
            type: 'POST',
            data: {
                "sd_code": sd_code,
                "md_code": md_code
            },
            success: function(data) {
                MainCategoryJSON = $.parseJSON(data);
               $('#mc_code').html('');
               $('#mc_code').append("<option value=''>Select the Main Category</option>");
                for (var i = 0; i < MainCategoryJSON.length; i++) {
                    $('#mc_code').append("<option value='" + MainCategoryJSON[i].mc_code + "'>" + MainCategoryJSON[i].mcName + " ( " + MainCategoryJSON[i].mc_code + " )</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
                getbrandlistdata();
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    });


    $(document).on('change', '#mc_code', function() {
        var md_code = $('#md_code').val();
        var sd_code = $('#sd_code').val();
        var mc_code = $('#mc_code').val();

        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>")
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getSubCategory',
            type: 'POST',
            data: {
                "sd_code": sd_code,
                "md_code": md_code,
                "mc_code": mc_code
            },
            success: function(data) {
                MainCategoryJSON = $.parseJSON(data);
               $('#sc_code').html('');
               $('#sc_code').append("<option value=''>Select the Sub Category</option>");
                for (var i = 0; i < MainCategoryJSON.length; i++) {
                    $('#sc_code').append("<option value='" + MainCategoryJSON[i].sc_code + "'>" + MainCategoryJSON[i].scName + " ( " + MainCategoryJSON[i].sc_code + " )</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
                getbrandlistdata();
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    });

    $(document).on('change', '#sc_code', function() {
           getbrandlistdata();

    });

    function getbrandlistdata()
    {
        var md_code = 0;
        var sd_code = 0;
        var mc_code = 0;
        var sc_code = 0;

        if($('#md_code').val()!='')
        {
            md_code = $('#md_code').val();
        }
        if($('#sd_code').val()!='')
        {
            sd_code = $('#sd_code').val();
        }
        if($('#mc_code').val()!='')
        {
            mc_code = $('#mc_code').val();
        }
        if($('#sc_code').val()!='')
        {
            sc_code = $('#sc_code').val();
        }

        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getbrandnamelist',
            type: 'POST',
            data: {
                "sd_code": sd_code,
                "md_code": md_code,
                "mc_code": mc_code,
                "sc_code": sc_code
            },
            success: function(data) {
                BrandJson = $.parseJSON(data);
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
                for (var i = 0; i < BrandJson.length; i++) {
                    $('#brand_name').append("<option value='" + BrandJson[i].brand_name + "'>" + BrandJson[i].brand_name + "</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
                // $('#sd_code').val(subdepartmentid);
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }



    $('#Product_Button').click(function() 
    {
        $('.error').hide();
        var offer_type = $('#offer_type').val();
        if (offer_type=='main_dept') 
        {
            getofferDetailsonsubmit();
        }
        else if (offer_type=='sub_dept') 
        {

            if ($('#md_code').val()=="") {
                $('.md_code').html("* Please Select the Main Department ");
                $('.md_code').show();
            }
            else
            {
                getofferDetailsonsubmit();
            }
        }
        else if (offer_type=='main_cat') 
        {

            if ($('#md_code').val()=="") {
                $('.md_code').html("* Please Select the Main Department ");
                $('.md_code').show();
            }
            if ($('#sd_code').val()=="") {
                $('.sd_code').html("* Please Select the Sub Department ");
                $('.sd_code').show();
            }
            else
            {
                getofferDetailsonsubmit();
            }
        }
        else if (offer_type=='sub_cat') 
        {

            if ($('#md_code').val()=="") {
                $('.md_code').html("* Please Select the Main Department ");
                $('.md_code').show();
            }
            if ($('#sd_code').val()=="") {
                $('.sd_code').html("* Please Select the Sub Department ");
                $('.sd_code').show();
            }
            if ($('#mc_code').val()=="") {
                $('.mc_code').html("* Please Select the Main Category ");
                $('.mc_code').show();
            }
            else
            {
                getofferDetailsonsubmit();
            }
        }
        else if (offer_type=='ind_products') 
        {
            if ($('#md_code').val()=="") {
                $('.md_code').html("* Please Select the Main Department ");
                $('.md_code').show();
            }
            if ($('#sd_code').val()=="") {
                $('.sd_code').html("* Please Select the Sub Department ");
                $('.sd_code').show();
            }
            if ($('#mc_code').val()=="") {
                $('.mc_code').html("* Please Select the Main Category ");
                $('.mc_code').show();
            }
            if ($('#sc_code').val()=="") {
                $('.sc_code').html("* Please Select the Sub Category ");
                $('.sc_code').show();
            }
            else
            {
                getofferDetailsonsubmit();
            }
        }
    });




    function getofferDetailsonsubmit() {

        var offer_type = $('#offer_type').val();
        var table = $('#offer_table').DataTable();
        table.destroy();
        var brand_name = $('#brand_name').val();

        if (offer_type=='main_dept') 
        {
            return $.ajax({
                url: base_URL + '/ThirdAxisCon/main_departmentoff',
                type: 'POST',
                data: {
                    "brand_name": brand_name
                },
                success: function(data) {
                    //console.log(data);
                    OfferDetailJSON = $.parseJSON(data);
                    dispOfferDetails(OfferDetailJSON);
                    
                $('.disptbl').show();

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        if (offer_type=='sub_dept') 
        {
            var md_code = $('#md_code').val();
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getSubDepartmentoff',
                type: 'POST',
                data: {
                    "md_code": md_code,
                    "brand_name":brand_name
                },
                success: function(data) {
                    OfferDetailJSON = $.parseJSON(data);
                    // OfferDetailJSON = $.parseJSON(data);
                    dispOfferDetails(OfferDetailJSON);
                    
                $('.disptbl').show();

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        if (offer_type=='main_cat') 
        {
            var md_code = $('#md_code').val();
            var sd_code = $('#sd_code').val();
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getMainCategoryoff',
                type: 'POST',
                data: {
                    "sd_code": sd_code,
                    "md_code": md_code,
                    "brand_name": brand_name
                },
                success: function(data) {
                    OfferDetailJSON = $.parseJSON(data);
                    // OfferDetailJSON = $.parseJSON(data);
                    dispOfferDetails(OfferDetailJSON);
                    
                $('.disptbl').show();

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        if (offer_type=='sub_cat') 
        {
            var md_code = $('#md_code').val();
            var sd_code = $('#sd_code').val();
            var mc_code = $('#mc_code').val();
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getSubCategoryoff',
                type: 'POST',
                data: {
                    "sd_code": sd_code,
                    "md_code": md_code,
                    "mc_code": mc_code,
                    "brand_name": brand_name
                },
                success: function(data) {
                    OfferDetailJSON = $.parseJSON(data);
                    // OfferDetailJSON = $.parseJSON(data);
                    dispOfferDetails(OfferDetailJSON);
                    
                $('.disptbl').show();

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        if (offer_type=='ind_products') 
        {
            var md_code = $('#md_code').val();
            var sd_code = $('#sd_code').val();
            var mc_code = $('#mc_code').val();
            var sc_code = $('#sc_code').val();
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getproductstooffer',
                type: 'POST',
                data: {
                    "sd_code": sd_code,
                    "md_code": md_code,
                    "mc_code": mc_code,
                    "sc_code":sc_code,
                    "brand_name": brand_name
                },
                success: function(data) {
                    OfferDetailJSON = $.parseJSON(data);
                    // OfferDetailJSON = $.parseJSON(data);
                    dispOfferDetails(OfferDetailJSON);
                    
                $('.disptbl').show();

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            OfferDetailJSON = [];
            dispOfferDetails(OfferDetailJSON);
        }


    }


    function dispOfferDetails(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#offer_table').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },

                    {
                    "mDataProp": function(data, type, full, meta) {

                            return data.offer_name;
                    }
                },       
                {
                    "mDataProp": function(data, type, full, meta) {
                            if(data.offer_type=='' || data.offer_type==null)
                            {
                                return '';
                            }
                            else if(data.offer_type=='P')
                            {
                                return 'Percentage';
                            }
                            else if(data.offer_type=='A')
                            {
                                return 'Money';
                            }
                            // return data.offer_type;
                    }
                },       
                {
                    "mDataProp": function(data, type, full, meta) {

                            if(data.offer_type=='' || data.offer_type==null)
                            {
                                return '';
                            }
                            else if(data.offer_type=='P')
                            {
                                return '% '+data.offer_value;
                            }
                            else if(data.offer_type=='A')
                            {
                                return 'AED '+data.offer_value;
                            }
                            // return data.offer_value;
                    }
                },

                 {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if(data.offer_flag==1)
                        {
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Deactivate</a>&nbsp;&nbsp;';
                        }   
                        else if(data.offer_flag==0)
                        {
                            return '<a id="' + meta.row + '" class="btn Btnadd" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Add</a>&nbsp;&nbsp;' ;
                        }


                    }
                },
            ]
        });
    }


    function dispOfferproductDetails(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#offer_product_table').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [

                    {
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },

                    {
                    "mDataProp": function(data, type, full, meta) {

                            return data.offer_name;
                    }
                },       
                {
                    "mDataProp": function(data, type, full, meta) {
                            if(data.offer_type=='' || data.offer_type==null)
                            {
                                return '';
                            }
                            else if(data.offer_type=='P')
                            {
                                return 'Percentage';
                            }
                            else if(data.offer_type=='A')
                            {
                                return 'Money';
                            }
                            // return data.offer_type;
                    }
                },       
                {
                    "mDataProp": function(data, type, full, meta) {

                            if(data.offer_type=='' || data.offer_type==null)
                            {
                                return '';
                            }
                            else if(data.offer_type=='P')
                            {
                                return '% '+data.offer_value;
                            }
                            else if(data.offer_type=='A')
                            {
                                return 'AED '+data.offer_value;
                            }
                            // return data.offer_value;
                    }
                }
            ]
        });
    }


    $(document).on('click', '.BtnEdit', function() {
        mode = "update";
        var r_index = $(this).attr('id');
        var offer_type = $('#offer_type').val();
        if (offer_type=='main_dept') 
        {
            banner_id = OfferDetailJSON[r_index].md_code; 
        }
        if (offer_type=='sub_dept') 
        {
            banner_id = OfferDetailJSON[r_index].sd_code;
        }
        if (offer_type=='main_cat') 
        {
            banner_id = OfferDetailJSON[r_index].mc_code;
        }
        if (offer_type=='sub_cat') 
        {
            banner_id = OfferDetailJSON[r_index].sc_code;
        }
        if (offer_type=='ind_products') 
        {
            banner_id = OfferDetailJSON[r_index].prod_id;
        }

        $('#largeModal').modal('show');
        $('#offer_applied_type').val(OfferDetailJSON[r_index].offer_type);
        $('#offer_value').val(OfferDetailJSON[r_index].offer_value);
    });

    $(document).on('click', '.Btnadd', function() {
        mode = "new";
        $('#largeModal').modal('show');
        var offer_type = $('#offer_type').val();
        var r_index = $(this).attr('id');
        if (offer_type=='main_dept') 
        {
            banner_id = OfferDetailJSON[r_index].md_code; 
        }
        if (offer_type=='sub_dept') 
        {
            banner_id = OfferDetailJSON[r_index].sd_code;
        }
        if (offer_type=='main_cat') 
        {
            banner_id = OfferDetailJSON[r_index].mc_code;
        }
        if (offer_type=='sub_cat') 
        {
            banner_id = OfferDetailJSON[r_index].sc_code;
        }
        if (offer_type=='ind_products') 
        {
            banner_id = OfferDetailJSON[r_index].prod_id;
        }
    });



    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');

        var offer_type = $('#offer_type').val();
        if (offer_type=='main_dept') 
        {
           banner_id = OfferDetailJSON[r_index].md_code;
           pre_offer_value = OfferDetailJSON[r_index].offer_value;
            var offer_applied_type = "";
            var offer_value = "";

            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Are you Sure Do you want to Deactivate this Data',
                type: 'blue',
                buttons: {
                    Yes: function() {
                        return $.ajax({
                            url: base_URL + 'ThirdAxisCon/removeoffers',
                            type: 'POST',
                            data: {
                                "offer_type": offer_type,
                                "offer_applied_type": offer_applied_type,
                                "offer_value": offer_value,
                                "md_code":banner_id,
                                "pre_offer_value":pre_offer_value,
                            },
                            success: function(data) {

                                var js = $.parseJSON(data);
                                var status = js.result;
                                if (status == "success") {                                    
                                    $("#Product_Button").trigger('click');
                                    $.confirm({
                                        icon: 'icon-close',
                                        title: 'Info',
                                        content: 'Inserted Sucessfully',
                                        type: 'green',
                                        buttons: {
                                            Ok: function() {},
                                        }
                                    });
                                } else {

                                    $.confirm({
                                        icon: 'icon-close',
                                        title: 'Info',
                                        content: 'Sorry Something went worng',
                                        type: 'red',
                                        buttons: {
                                            Ok: function() {},
                                        }
                                    });
                                }

                            },
                            error: function() {
                                console.log("Error");
                                //alert('something bad happened'); 
                            }
                        });
                    },
                    No: function() {},
                }
            });

        }
        if (offer_type=='sub_dept') 
        {
            banner_id = OfferDetailJSON[r_index].sd_code;
            pre_offer_value = OfferDetailJSON[r_index].offer_value;
            var md_code = $('#md_code').val();
            var offer_applied_type = "";
            var offer_value = "";

            $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Are you Sure Do you want to Deactivate this Data',
                    type: 'blue',
                    buttons: {
                        Yes: function() {
                                return $.ajax({
                                    url: base_URL + 'ThirdAxisCon/removeoffers',
                                    type: 'POST',
                                    data: {
                                        "offer_type": offer_type,
                                        "offer_applied_type": offer_applied_type,
                                        "offer_value": offer_value,
                                        "md_code":md_code,
                                        "sd_code":banner_id,
                                        "pre_offer_value":pre_offer_value
                                    },
                                    success: function(data) {
                                        var js = $.parseJSON(data);
                                        var status = js.result;
                                        if (status == "success") {
                                            $("#Product_Button").trigger('click');
                                            $.confirm({
                                                icon: 'icon-close',
                                                title: 'Info',
                                                content: 'Inserted Sucessfully',
                                                type: 'green',
                                                buttons: {
                                                    Ok: function() {},
                                                }
                                            });
                                        } else {

                                            $.confirm({
                                                icon: 'icon-close',
                                                title: 'Info',
                                                content: 'Sorry Something went worng',
                                                type: 'red',
                                                buttons: {
                                                    Ok: function() {},
                                                }
                                            });
                                        }

                                    },
                                    error: function() {
                                        console.log("Error");
                                        //alert('something bad happened'); 
                                    }
                                });
                        },
                        No: function() {},
                    }
                });

        }
        if (offer_type=='main_cat') 
        {
            banner_id = OfferDetailJSON[r_index].mc_code;
            pre_offer_value = OfferDetailJSON[r_index].offer_value;
            var md_code = $('#md_code').val();
            var sd_code = $('#sd_code').val();
            var offer_applied_type = "";
            var offer_value = "";

            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Are you Sure Do you want to Deactivate this Data',
                type: 'blue',
                buttons: {
                    Yes: function() {
                         return $.ajax({
                            url: base_URL + 'ThirdAxisCon/removeoffers',
                            type: 'POST',
                            data: {
                                "offer_type": offer_type,
                                "offer_applied_type": offer_applied_type,
                                "offer_value": offer_value,
                                "md_code":md_code,
                                "sd_code":sd_code,
                                "mc_code":banner_id,
                                "pre_offer_value":pre_offer_value
                            },
                            success: function(data) {
                                var js = $.parseJSON(data);
                                var status = js.result;
                                if (status == "success") {
                                    $("#Product_Button").trigger('click');
                                    $.confirm({
                                        icon: 'icon-close',
                                        title: 'Info',
                                        content: 'Inserted Sucessfully',
                                        type: 'green',
                                        buttons: {
                                            Ok: function() {},
                                        }
                                    });
                                } else {

                                    $.confirm({
                                        icon: 'icon-close',
                                        title: 'Info',
                                        content: 'Sorry Something went worng',
                                        type: 'red',
                                        buttons: {
                                            Ok: function() {},
                                        }
                                    });
                                }

                            },
                            error: function() {
                                console.log("Error");
                                //alert('something bad happened'); 
                            }
                        });
                    },
                    No: function() {},
                }
            });


        }
        if (offer_type=='sub_cat') 
        {
            banner_id = OfferDetailJSON[r_index].sc_code;
            pre_offer_value = OfferDetailJSON[r_index].offer_value;
            var md_code = $('#md_code').val();
            var sd_code = $('#sd_code').val();
            var mc_code = $('#mc_code').val();
            var offer_applied_type = "";
            var offer_value = "";

            $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Are you Sure Do you want to Deactivate this Data',
                    type: 'blue',
                    buttons: {
                        Yes: function() {
                            return $.ajax({
                                url: base_URL + 'ThirdAxisCon/removeoffers',
                                type: 'POST',
                                data: {
                                    "offer_type": offer_type,
                                    "offer_applied_type": offer_applied_type,
                                    "offer_value": offer_value,
                                    "md_code":md_code,
                                    "sd_code":sd_code,
                                    "mc_code":mc_code,
                                    "sc_code":banner_id,
                                    "pre_offer_value":pre_offer_value
                                },
                                success: function(data) {

                                    var js = $.parseJSON(data);
                                    var status = js.result;
                                    if (status == "success") {
                                        $("#Product_Button").trigger('click');
                                        $.confirm({
                                            icon: 'icon-close',
                                            title: 'Info',
                                            content: 'Inserted Sucessfully',
                                            type: 'green',
                                            buttons: {
                                                Ok: function() {},
                                            }
                                        });
                                    } else {

                                        $.confirm({
                                            icon: 'icon-close',
                                            title: 'Info',
                                            content: 'Sorry Something went worng',
                                            type: 'red',
                                            buttons: {
                                                Ok: function() {},
                                            }
                                        });
                                    }

                                },
                                error: function() {
                                    console.log("Error");
                                    //alert('something bad happened'); 
                                }
                            });
                        },
                        No: function() {},
                    }
                });

        }
        if (offer_type=='ind_products') 
        {
            banner_id = OfferDetailJSON[r_index].prod_id;
            pre_offer_value = OfferDetailJSON[r_index].offer_value;
            var md_code = $('#md_code').val();
            var sd_code = $('#sd_code').val();
            var mc_code = $('#mc_code').val();
            var sc_code = $('#sc_code').val();
            var offer_applied_type = "";
            var offer_value = "";

            $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Are you Sure Do you want to Deactivate this Data',
                    type: 'blue',
                    buttons: {
                        Yes: function() {
                            return $.ajax({
                                url: base_URL + 'ThirdAxisCon/removeoffers',
                                type: 'POST',
                                data: {
                                    "offer_type": offer_type,
                                    "offer_applied_type": offer_applied_type,
                                    "offer_value": offer_value,
                                    "md_code":md_code,
                                    "sd_code":sd_code,
                                    "mc_code":mc_code,
                                    "sc_code":sc_code,
                                    "prod_id":banner_id,
                                    "pre_offer_value":pre_offer_value
                                },
                                success: function(data) {

                                    var js = $.parseJSON(data);
                                    var status = js.result;
                                    if (status == "success") {
                                        $("#Product_Button").trigger('click');
                                        $.confirm({
                                            icon: 'icon-close',
                                            title: 'Info',
                                            content: 'Inserted Sucessfully',
                                            type: 'green',
                                            buttons: {
                                                Ok: function() {},
                                            }
                                        });
                                    } else {

                                        $.confirm({
                                            icon: 'icon-close',
                                            title: 'Info',
                                            content: 'Sorry Something went worng',
                                            type: 'red',
                                            buttons: {
                                                Ok: function() {},
                                            }
                                        });
                                    }

                                },
                                error: function() {
                                    console.log("Error");
                                    //alert('something bad happened'); 
                                }
                            });
                        },
                        No: function() {},
                    }
                });
        }


    });


    $('#banner_submit').click(function() {
        $('.error').hide();

        if ($('#offer_applied_type').val() == "") {
            $('.offer_applied_type').html("* Please Select the Offer Type ");
            $('.offer_applied_type').show();
        }
        else if ($('#offer_value').val() == "") {
            $('.offer_value').html("* Enter the Offer Value ");
            $('.offer_value').show();
        }
        else 
        {
            saveBannerimage();
        }
    });

    function saveBannerimage() 
    {
        var offer_type = $('#offer_type').val();
        if (offer_type=='main_dept') 
        {
           var offer_applied_type = $('#offer_applied_type').val();
           var offer_value = $('#offer_value').val();

            return $.ajax({
                url: base_URL + 'ThirdAxisCon/insertofferdetails',
                type: 'POST',
                data: {
                    "offer_type": offer_type,
                    "offer_applied_type": offer_applied_type,
                    "offer_value": offer_value,
                    "md_code":banner_id
                },
                success: function(data) {

                    var js = $.parseJSON(data);
                    var status = js.result;
                    if (status == "success") {
                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Inserted Sucessfully',
                            type: 'green',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                        $('#largeModal').modal('hide');
                        $("#Product_Button").trigger('click');
                    } else {

                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Sorry Something went worng',
                            type: 'red',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                    }

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });

        }
        if (offer_type=='sub_dept') 
        {
            var md_code = $('#md_code').val();
            var offer_applied_type = $('#offer_applied_type').val();
            var offer_value = $('#offer_value').val();

            return $.ajax({
                url: base_URL + 'ThirdAxisCon/insertofferdetails',
                type: 'POST',
                data: {
                    "offer_type": offer_type,
                    "offer_applied_type": offer_applied_type,
                    "offer_value": offer_value,
                    "md_code":md_code,
                    "sd_code":banner_id
                },
                success: function(data) {
                    var js = $.parseJSON(data);
                    var status = js.result;
                    if (status == "success") {
                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Inserted Sucessfully',
                            type: 'green',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                        $('#largeModal').modal('hide');
                        $("#Product_Button").trigger('click');
                    } else {

                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Sorry Something went worng',
                            type: 'red',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                    }

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        if (offer_type=='main_cat') 
        {
            var md_code = $('#md_code').val();
            var sd_code = $('#sd_code').val();
            var offer_applied_type = $('#offer_applied_type').val();
            var offer_value = $('#offer_value').val();

            return $.ajax({
                url: base_URL + 'ThirdAxisCon/insertofferdetails',
                type: 'POST',
                data: {
                    "offer_type": offer_type,
                    "offer_applied_type": offer_applied_type,
                    "offer_value": offer_value,
                    "md_code":md_code,
                    "sd_code":sd_code,
                    "mc_code":banner_id
                },
                success: function(data) {
                    var js = $.parseJSON(data);
                    var status = js.result;
                    if (status == "success") {
                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Inserted Sucessfully',
                            type: 'green',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                        $('#largeModal').modal('hide');
                        $("#Product_Button").trigger('click');
                    } else {

                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Sorry Something went worng',
                            type: 'red',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                    }

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        if (offer_type=='sub_cat') 
        {
            var md_code = $('#md_code').val();
            var sd_code = $('#sd_code').val();
            var mc_code = $('#mc_code').val();
            var offer_applied_type = $('#offer_applied_type').val();
            var offer_value = $('#offer_value').val();

            return $.ajax({
                url: base_URL + 'ThirdAxisCon/insertofferdetails',
                type: 'POST',
                data: {
                    "offer_type": offer_type,
                    "offer_applied_type": offer_applied_type,
                    "offer_value": offer_value,
                    "md_code":md_code,
                    "sd_code":sd_code,
                    "mc_code":mc_code,
                    "sc_code":banner_id
                },
                success: function(data) {

                    var js = $.parseJSON(data);
                    var status = js.result;
                    if (status == "success") {
                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Inserted Sucessfully',
                            type: 'green',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                        $('#largeModal').modal('hide');
                        $("#Product_Button").trigger('click');
                    } else {

                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Sorry Something went worng',
                            type: 'red',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                    }

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        if (offer_type=='ind_products') 
        {
            var md_code = $('#md_code').val();
            var sd_code = $('#sd_code').val();
            var mc_code = $('#mc_code').val();
            var sc_code = $('#sc_code').val();
            var offer_applied_type = $('#offer_applied_type').val();
            var offer_value = $('#offer_value').val();

            return $.ajax({
                url: base_URL + 'ThirdAxisCon/insertofferdetails',
                type: 'POST',
                data: {
                    "offer_type": offer_type,
                    "offer_applied_type": offer_applied_type,
                    "offer_value": offer_value,
                    "md_code":md_code,
                    "sd_code":sd_code,
                    "mc_code":mc_code,
                    "sc_code":sc_code,
                    "prod_id":banner_id
                },
                success: function(data) {

                    var js = $.parseJSON(data);
                    var status = js.result;
                    if (status == "success") {
                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Inserted Sucessfully',
                            type: 'green',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                        $('#largeModal').modal('hide');
                        $("#Product_Button").trigger('click');
                    } else {

                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Sorry Something went worng',
                            type: 'red',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                    }

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
    }

    function refreshDetails() {
        $.when(getofferDetails()).done(function() {
            var table = $('#offer_table').DataTable();
            table.destroy();
            dispOfferDetails(OfferDetailJSON);
        });
    }

    function updateBannerimage() {
        var form = $('#bannerimagesform')[0];
        var data = new FormData(form);
        data.append("banner_id", banner_id);
        data.append("imageoneinserted",imageoneinserted);
        data.append("imagetwoinserted",imagetwoinserted);

        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/updatehomebannerimage',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } else {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }		
        });
    }

    $('#largeModal').on('show.bs.modal', function() {
        $(".no").hide();
        $('#img_namee1').html('');
        $('#mobile_imageurl').prop('disabled', false);
        $('#img_namee2').html('');
        $('#web_imageurl').prop('disabled', false);



        $(this).find('form').trigger('reset');
    });


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});