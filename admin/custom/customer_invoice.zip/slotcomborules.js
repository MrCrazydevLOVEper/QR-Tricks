$(document).ready(function() {

    var SlotcomboJSON,slot_combo_id,slot_setting_id,mode;

    $.when(getslotlogiclsetting()).done(function() {
    });

    $('#showifdeactivated').hide();
    $('#showifactivated').hide();

    function getslotlogiclsetting() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getslotlogiclsetting',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                SlotcomboJSON = $.parseJSON(data);

                if (SlotcomboJSON.length>0) 
                {
                    $('#slot_rules').val(SlotcomboJSON[0]["slot_rules"]);
                    slot_setting_id = SlotcomboJSON[0]["slot_setting_id"];
                }

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });


    $('#formdatadetailsslotsubmit').click(function() {
        $('.error').hide();
        if ($('#slot_rules').val() != "") 
        {
            var form = $('#formdatadetailsslot')[0];
            var data = new FormData(form);
            data.append("slot_setting_id",slot_setting_id);
            request = $.ajax({
                type: "POST",
                enctype: 'multipart/form-data',
                url: base_URL + 'ThirdAxisCon/insertslotsettingdetails',
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                timeout: 600000,
            });
            request.done(function(response) {
                var js = $.parseJSON(response);
                var status = js.result;
                if (status == "success") {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Updated Sucessfully',
                        type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                } else {

                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Sorry Something went worng',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                }
            });
        } 
        else 
        {
            $('.slot_rules').html("* please enter the value");
            $('.slot_rules').show();

        }
    });


    $('.activatebtn').click(function() {
        return $.ajax({
            url: base_URL+'ThirdAxisCon/insertslotsettingdetails',
            type:'POST',
            data: {
                "slot_setting_id":slot_setting_id,"previous_purchase_flag":"1"
            },
            success:function(data){
                var js = $.parseJSON(data);
                var status = js.result;
                if (status == "success") {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Updated Sucessfully',
                        type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                    getslotlogiclsetting()
                } else {

                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Sorry Something went worng',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                } 
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ; 
    });

    $('.deactivatebtn').click(function() {
       return $.ajax({
            url: base_URL+'ThirdAxisCon/insertslotsettingdetails',
            type:'POST',
            data: {
                "slot_setting_id":slot_setting_id,"previous_purchase_flag":"0"
            },
            success:function(data){
                var js = $.parseJSON(data);
                var status = js.result;
                if (status == "success") {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Updated Sucessfully',
                        type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                    getslotlogiclsetting()
                } else {

                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Sorry Something went worng',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                }   
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;
    });







});