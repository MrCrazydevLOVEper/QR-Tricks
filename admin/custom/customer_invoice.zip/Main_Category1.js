$(document).ready(function() {
	var subdepartmentid;
	var MainCategoryJSON,mc_code,mode,SubDepatmentJSON;
	$.when(getMainCategory()).done(function(){
			dispMainCategory(MainCategoryJSON);				
	});

	function getMainCategory()
	{
		return $.ajax({
			url: base_URL+'/ThirdAxisCon/main_category',
			type:'POST',
			success:function(data){
				//console.log(data);
				MainCategoryJSON = $.parseJSON(data);
				
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;
	}


	function dispMainCategory(JSON)
	{	
		//$('#success_alert').show(1000);
		//console.log(dataJSON);
		var i = 1;
		$('#Main_Category').dataTable( {
			"aaSorting":[],
			"aaData": JSON,
			responsive: true,
			"aoColumns": [
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return i++;					
					}
				},
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.mdName+' ( '+data.md_code+' )';					
					}
				},					
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.sdName+' ( '+data.sd_code+' )';					
					}
				},				
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.mcName+' ( '+data.mc_code+' )';					
					}
				},									
				{ "mDataProp": "mcSeoTitle" },
				{ "mDataProp": "mcSeokeyword" },
				{ "mDataProp": "mcSeoDes" },	
				{
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  visible</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Hidden</a>&nbsp;&nbsp;';;

                    }
                },
				{
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },				
			]  				
		});
	}
	
	$('#New_Category').click(function(){
		mode="new";
		$('#largeModal').modal('show');
	});
	
	
	$(document).on('click','.BtnEdit',function(){
		
		mode="update";
		var r_index = $(this).attr('id');
		mc_code = MainCategoryJSON[r_index].mc_code;
		$('#largeModal').modal('show');
		$('#md_code').val(MainCategoryJSON[r_index].md_code);
		$('#md_code').change();
		$('#sd_code').val(MainCategoryJSON[r_index].sd_code);	
				
		$('#mcName').val(MainCategoryJSON[r_index].mcName);
		//$('.Scategory').val(MainCategoryJSON[r_index].Scategory);
		$('#mcSeoTitle').val(MainCategoryJSON[r_index].mcSeoTitle);
		$('#mcSeokeyword').val(MainCategoryJSON[r_index].mcSeokeyword);
		$('#mcSeoDes').val(MainCategoryJSON[r_index].mcSeoDes);	
		subdepartmentid = MainCategoryJSON[r_index].sd_code;


	});
	
	
	$(document).on('change','#md_code',function(){
		var md_code = $('#md_code').val();	
			return $.ajax({
			url: base_URL+'ThirdAxisCon/getSubDepartment',
			type:'POST',
			data: {"md_code":md_code},
			success:function(data){
				SubDepatmentJSON = $.parseJSON(data);
					
					$('#sd_code').html('');
					$('#sd_code').append("<option value=''>Select the Sub Department</option>");
				for(var i=0;i<SubDepatmentJSON.length;i++)
				{
					$('#sd_code').append("<option value='"+SubDepatmentJSON[i].sd_code+"'>"+SubDepatmentJSON[i].sdName+" ( "+SubDepatmentJSON[i].sd_code+" ) </option>");
				//	$('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
				}
				$('#sd_code').val(subdepartmentid);
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;
	});	
	
	$(document).on('click','.BtnDelete',function(){
		mode="delete";
		var r_index = $(this).attr('id');
		mc_code = MainCategoryJSON[r_index].mc_code;
        var md_code = MainCategoryJSON[r_index].md_code;
        var sd_code = MainCategoryJSON[r_index].sd_code;
		
		$.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Are you Sure Do you want to Delete this Data',
                type: 'blue',
					buttons: {
						Yes: function() {					
								request = $.ajax({
									type: "POST",
									url: base_URL+'ThirdAxisCon/DeleteMainCategoryData',
									data: {"md_code":md_code,"sd_code":sd_code,"mc_code":mc_code},
								});		
								request.done(function (response){
									var js = $.parseJSON(response);
									var status = js.result
									if (status == "success") {
										$.confirm({
											icon: 'icon-close',
											title: 'Info',
											content: 'Deleted Succesfully',
											type: 'green',
												buttons: {
													Ok: function() {},
												}
										});
										refreshDetails();
									}
									else
									{
										$.confirm({
											icon: 'icon-close',
											title: 'Info',
											content: 'Are you Sure Do you want to Delete this Data',
											type: 'blue',
												buttons: {
													No: function() {},
												}
										});
									}
							
								});	
						},
						No: function() {},
					}
            });	
	});
	


    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        var md_code = MainCategoryJSON[r_index].md_code;
        var sd_code = MainCategoryJSON[r_index].sd_code;
        	mc_code = MainCategoryJSON[r_index].mc_code;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreSMainCategoryData(md_code,sd_code,mc_code,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        var md_code = MainCategoryJSON[r_index].md_code;
        var sd_code = MainCategoryJSON[r_index].sd_code;
        	mc_code = MainCategoryJSON[r_index].mc_code;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreSMainCategoryData(md_code,sd_code,mc_code,flag);
                },
                No: function() {},
            }
        });

    });


    function RestoreSMainCategoryData(md_code,sd_code,mc_code,flag)
    {
    	var md_code = md_code;
    	var sd_code = sd_code;    	
    	var mc_code = mc_code;
    	var flag = flag;

        request = $.ajax({
                type: "POST",
                url: base_URL+'ThirdAxisCon/RestoreSMainCategoryData',
                data: {"md_code":md_code,"sd_code":sd_code,"mc_code":mc_code,"flag":flag},
        }); 
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }





	
	$('#Main_Category_Button').click(function(){
		$('.error').hide();
		//alert(12);
		//console.log($('#url').val()); 
		if($('#md_code').val()=="")
		{
			$('.md_code').html("* Please Fill Main Department");
			$('.md_code').show();
		}
		else  if($('#sd_code').val()=="")
		{
			$('.sd_code').html("* Please Fill Sub Department");
			$('.sd_code').show(); 
		}
		else if($('#mcName').val()=="")
		{
			$('.mcName').html("* Please Fill Category Name");
			$('.mcName').show();
		}
		else
		{
			if(mode=="new")
			{
				saveMainCategory();
			}
			else
			{
				updateMainCategory();
			}			
			
		}		
	});
	
	$('#largeModal').on('show.bs.modal', function () {
		$(".no").hide();
		$('#hide').attr('checked', false);
		$('#show').attr('checked', false);
		$('#sd_code').val('');
	    $(this).find('form').trigger('reset');
	});	
	
	function saveMainCategory()
	{	
//alert(12);	
		var form = $('#Main_Category_Form')[0];
		var data = new FormData(form);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/insertMainCategoryData',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			//console.log(js);
			var status = js.result;
			console.log(status);
			if (status == "success") {
				$.confirm({
								icon: 'icon-close',
								title: 'Info',
								content: 'Inserted Sucessfully',
								type: 'green',
									buttons: {
										Ok: function() {},
									}
							});
				$('#largeModal').modal('hide');
				refreshDetails();
				//alert(12);
			}
			else
			{
				$.confirm({
							icon: 'icon-close',
							title: 'Info',
							content: 'Sorry Something went worng',
							type: 'red',
								buttons: {
									Ok: function() {},
								}
						});
			}
			// $('.alert-success').show().delay(5000).fadeOut('slow');				
			// refreshDetails();		
		});		
	}
	
	function refreshDetails()
	{
		$.when(getMainCategory()).done(function(){
			var table = $('#Main_Category').DataTable();
			table.destroy();	
			dispMainCategory(MainCategoryJSON);				
		});		
	}
	
	function updateMainCategory()
	{
		var form = $('#Main_Category_Form')[0];
		var data = new FormData(form);
		data.append("mc_code",mc_code);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/updateMainCategoryData',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);			
			var status = js.result;
			if (status == "success") {
				$.confirm({
							icon: 'icon-close',
							title: 'Info',
							content: 'Updated Sucessfully',
							type: 'green',
								buttons: {
									Ok: function() {},
								}
						});
				$('#largeModal').modal('hide');
				refreshDetails();
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}
			//console.log(js);
			// $('#largeModal').modal('hide');
			// $('.alert-success').show().delay(5000).fadeOut('slow');				
			// refreshDetails();		
		});			
	}
        	  $(document)
              .ajaxStart(function () {
                $(".loading").show();
              })
              .ajaxStop(function () {
                $(".loading").hide();
              });

});
