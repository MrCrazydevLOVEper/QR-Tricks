$(document).ready(function() {

    var CustomerJSON, user_id, mode;
    $.when(getcustomercartlist()).done(function() {
        dispArealist(CustomerJSON);
    });

    function getcustomercartlist() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getcustomercartlist',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                CustomerJSON = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    function dispArealist(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                     "mDataProp": function(data, type, full, meta) {
                            return ""+data.added_date+" "+data.added_time+"";
                    }
                },
                {
                    "mDataProp": "user_unique_id"
                },
                {
                     "mDataProp": function(data, type, full, meta) {
                            return data.username;
                    }
                },
                {
                     "mDataProp": function(data, type, full, meta) {
                            if (data.produ_imgurl=='Requested Product') 
                            {
                                return "<p style='color:red'>"+data.produ_imgurl+"<p>";
                            }
                            else
                            {
                                return "<img src='"+data.produ_imgurl+"'' alt='product-img' height='52'>";
                            }
                    }
                },
                {
                     "mDataProp": function(data, type, full, meta) {
                            return ""+data.prod_code+" "+data.prod_name+"";
                    }
                },
                {
                    "mDataProp": "prod_quantity"
                }
            ]
        });
    }

    $(document).on('click', '.viewaddress', function() {
              
        var r_index = $(this).attr('id');
        var user_unique_id = CustomerJSON[r_index].user_unique_id;
        
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/getcustomersaddresslist',
            data: {
                "user_unique_id": user_unique_id
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            // var status = js.result
            $('#notificationmodelmsgmodel').modal('show');
            $('#notificationcontentmodalmsg').html('');

            if (js.length>0) 
            {
                for (var i = 0; i < js.length; i++) 
                {
                    $('#notificationcontentmodalmsg').append('<p style="margin: 5px;">'+js[i]["username"]+' ,</p><p  style="margin: 5px;">'+js[i]["flat_no"]+', '+js[i]["building_name"]+', '+js[i]["landmark"]+'</p><p  style="margin: 5px;">'+js[i]["area"]+', '+js[i]["city"]+'.</p><br>');
                }
            }
            else
            {
                $('#notificationcontentmodalmsg').append('<p>No record founded</p>');
            }
        });
 

    });




    function refreshDetails() {
        $.when(getcustomercartlist()).done(function() {
            var table = $('#Main_Category').DataTable();
            table.destroy();
            dispArealist(CustomerJSON);
        });
    }


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});