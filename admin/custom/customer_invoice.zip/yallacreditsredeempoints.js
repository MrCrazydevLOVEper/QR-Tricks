$(document).ready(function() {

	var yallacreditsJSON,yalla_credit_points_id,mode;

	$.when(get_yalla_credit_points()).done(function()
	{
		yalla_credit_points_id = yallacreditsJSON[0]["yalla_credit_points_id"];
		$('#google_review_points').val(yallacreditsJSON[0]["google_review_points"]);
		$('#amount_spent_points').val(yallacreditsJSON[0]["amount_spent_points"]);
		$('#blog_write_points').val(yallacreditsJSON[0]["blog_write_points"]);
	});
	
	function get_yalla_credit_points()
	{
		return $.ajax({
			url: base_URL+'ThirdAxisCon/get_yalla_credit_points',
			type:'POST',
			success:function(data)
			{
				yallacreditsJSON = $.parseJSON(data);	
			},		
			error: function() {
				console.log("Error"); 
			}
		}) ;
	}
	
	$('#Formdata_details_submit').click(function(){
		$('.error').hide();

		if($('#google_review_points').val()=="")
		{
			$('.google_review_points').html("* Google review pointscannot be empty");
			$('.google_review_points').show();
		}
		else if($('#blog_write_points').val()=="")
		{
			$('.blog_write_points').html("* Points for blog write cannot be empty");
			$('.blog_write_points').show();
		}
		else if($('#amount_spent_points').val()=="")
		{
			$('.amount_spent_points').html("* Amount spent value cannot be empty");
			$('.amount_spent_points').show();
		}		
		else
		{
			update_yalla_credit_points();			
		}		
	});

	
	function update_yalla_credit_points()
	{		
		var form = $('#Formdata_details')[0];
		var data = new FormData(form);
		data.append("yalla_credit_points_id", yalla_credit_points_id);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/update_yalla_credit_points',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			var status = js.result
			if (status == "success") {
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Updated Sucessfully',
					type: 'green',
						buttons: {
							Ok: function() {},
						}
				});
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}		
		});		
	}


  $(document)
  .ajaxStart(function () {
    $(".loading").show();
  })
  .ajaxStop(function () {
    $(".loading").hide();
  });

});
