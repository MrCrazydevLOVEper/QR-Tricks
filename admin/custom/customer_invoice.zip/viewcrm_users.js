$(document).ready(function() {

    var crmuserdetailsJSON, user_id, mode;
    var selected_main_menu=[];
    var selected_sub_menu=[];
    $.when(getcrmpaneluserlist()).done(function() {
        dispDeliverypersonsdetails(crmuserdetailsJSON);
    });


    function getcrmpaneluserlist() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getcrmpaneluserlist',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                crmuserdetailsJSON = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }

    function dispDeliverypersonsdetails(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": "username"
                },
                {
                    "mDataProp": "mobile_no"
                },
                {
                    "mDataProp": "email"
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                       return '<a id="' + meta.row + '" class="btn viewproductss" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;  view</a>&nbsp;&nbsp;';
                    }
                },{
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  Active</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Deactive</a>&nbsp;&nbsp;';

                    }
                }, {
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },
            ]
        });
    }

    $('#New_Category').click(function() {
        mode = "new";
        $('#largeModal').modal('show');
    });


    getselectedmainmenu = function (main_menu_id) 
    {
        var chks = document.getElementsByClassName('visually-hidden-lable-mainmenu');
        // console.log(chks);
        selected_main_menu = [];
        for (var i = 0; i < chks.length; i++) {
            if (chks[i].checked) {
                selected_main_menu.push(chks[i].value);
            }
        }
        console.log(selected_main_menu);
    }

    getselectedsubmenu = function (main_menu_id) 
    {
        var chks = document.getElementsByClassName('visually-hidden-lable-submenu');
        // console.log(chks);
        selected_sub_menu = [];
        for (var i = 0; i < chks.length; i++) {
            if (chks[i].checked) {
                selected_sub_menu.push(chks[i].value);
            }
        }
        console.log(selected_sub_menu);
    }


    $(document).on('click', '.BtnEdit', function() {
        mode = "update";
        var r_index = $(this).attr('id');
        user_id = crmuserdetailsJSON[r_index].user_id;
        var main_menu_id_exp = crmuserdetailsJSON[r_index].main_menu_id_exp;
        var sub_menu_id_exp = crmuserdetailsJSON[r_index].sub_menu_id_exp;
        $('#largeModal').modal('show');
        $('#username').val(crmuserdetailsJSON[r_index].username);
        $('#mobile_no').val(crmuserdetailsJSON[r_index].mobile_no);
        $('#email').val(crmuserdetailsJSON[r_index].email);
        $('#name').val(crmuserdetailsJSON[r_index].name);
        $('#password').val(crmuserdetailsJSON[r_index].password);

        var data_arry = [];
        var data_arry2 = [];

        var chks = document.getElementsByClassName('visually-hidden-lable-mainmenu');
        // console.log(chks);
        for (var i = 0; i < chks.length; i++) {
            data_arry.push(chks[i].value);
        }

        var chks2 = document.getElementsByClassName('visually-hidden-lable-submenu');
        // console.log(chks);
        for (var i = 0; i < chks2.length; i++) {
            data_arry2.push(chks2[i].value);
        }


        for (var i = 0; i < main_menu_id_exp.length; i++) 
        {
            for (var j = 0; j < data_arry.length; j++) 
            {
                // data_arry[i]
                if (data_arry[j]==main_menu_id_exp[i]) 
                {
                    var checll = document.getElementById('main_menu_id_'+main_menu_id_exp[i]+'');
                    checll.checked =1;

                }
            }
        }

        for (var i = 0; i < sub_menu_id_exp.length; i++) 
        {
            for (var j = 0; j < data_arry2.length; j++) 
            {
                // data_arry[i]
                if (data_arry2[j]==sub_menu_id_exp[i]) 
                {
                    var checll = document.getElementById('sub_menu_id_'+sub_menu_id_exp[i]+'');
                    checll.checked =1;

                }
            }
        }

        getselectedmainmenu();
        getselectedsubmenu();

    });


    $(document).on('click', '.viewproductss', function() {
        mode = "update";
        var r_index = $(this).attr('id');
        $('.appendmenudetails').html('');
        user_id = crmuserdetailsJSON[r_index].user_id;
        var username = crmuserdetailsJSON[r_index].username;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/getuseraccesmenubyid',
            data: {
                "user_id": user_id
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var menudetails = js.menudetails
            $('#menuaccedmodal').modal('show');

            if (menudetails.length>0) 
            {
                for (var i = 0; i < menudetails.length; i++) 
                {
                     $('.appendmenudetails').append('<p class="col-sm-3 ">'+menudetails[i].main_menu_name+'</p>');
                }
            }
            else
            {
                $('.appendmenudetails').append('No recorde found');
            }


        });
    });


    $(document).on('click', '.BtnDelete', function() {
        mode = "delete";
        var r_index = $(this).attr('id');
        user_id = crmuserdetailsJSON[r_index].user_id;
        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Delete this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                    request = $.ajax({
                        type: "POST",
                        url: base_URL + 'ThirdAxisCon/deletecrmpalenusers',
                        data: {
                            "user_id": user_id
                        },
                    });
                    request.done(function(response) {
                        var js = $.parseJSON(response);
                        var status = js.result
                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Deleted Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                            refreshDetails();
                        } else {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Are you Sure Do you want to Delete this Data',
                                type: 'blue',
                                buttons: {
                                    No: function() {},
                                }
                            });
                        }

                    });
                },
                No: function() {},
            }
        });

    });

    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        user_id = crmuserdetailsJSON[r_index].user_id;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	Restoredeliverypersonslist(user_id,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        user_id = crmuserdetailsJSON[r_index].user_id;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	Restoredeliverypersonslist(user_id,flag);
                },
                No: function() {},
            }
        });

    });


    function Restoredeliverypersonslist(user_id,flag)
    {
    	var user_id = user_id;
    	var flag = flag;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/Restorecrmpanelusers',
            data: {
                "user_id": user_id,"flag":flag
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


    $('#usercreation_Button').click(function() {
        $('.error').hide();
        //console.log($('#url').val()); 
        if ($('#username').val() == "") {
            $('.username').html("* Please Fill Name");
            $('.username').show();
        }    
        if ($('#name').val() == "") {
            $('.name').html("* Please Fill User Name");
            $('.name').show();
        }  
        if ($('#password').val() == "") {
            $('.password').html("* Please Fill Password");
            $('.password').show();
        } 
        if (selected_main_menu.length<=0 && selected_sub_menu.length<=0) 
        {
            $('.selectmenulistarray').html("* Select any menu list");
            $('.selectmenulistarray').show();
        } 
        else 
        {
            if (mode == "new") {
                insertcrmpanelusers();
            } else {
                updatecrmpanelusers();
            }

        }
    });

    function insertcrmpanelusers() {
        var form = $('#usercreation_Form')[0];
        var data = new FormData(form);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/insertcrmpanelusers',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            console.log(status);
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Inserted Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }
        });
    }

    function refreshDetails() {
        $.when(getcrmpaneluserlist()).done(function() {
            var table = $('#Main_Category').DataTable();
            table.destroy();
            dispDeliverypersonsdetails(crmuserdetailsJSON);
        });
    }

    function updatecrmpanelusers() {
        var form = $('#usercreation_Form')[0];
        var data = new FormData(form);
        data.append("user_id", user_id);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/updatecrmpanelusers',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } else {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }		
        });
    }

    $('#largeModal').on('show.bs.modal', function() {
        $(".no").hide();
        $('#hide').attr('checked', false);
        $('#show').attr('checked', false);
        $(this).find('form').trigger('reset');
    });



    $(document).on('click', '.Btnavaliablehidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        user_id = crmuserdetailsJSON[r_index].user_id;
        var avaliable_status = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to update as User Not Available',
            type: 'blue',
            buttons: {
                Yes: function() {
                    Restoreavaliable_status(user_id,avaliable_status);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnavaliableRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        user_id = crmuserdetailsJSON[r_index].user_id;
        var avaliable_status = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to update as User Available',
            type: 'blue',
            buttons: {
                Yes: function() {
                    Restoreavaliable_status(user_id,avaliable_status);
                },
                No: function() {},
            }
        });

    });


    function Restoreavaliable_status(user_id,avaliable_status)
    {
        var user_id = user_id;
        var flag = flag;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/Restoreavaliable_status',
            data: {
                "user_id": user_id,"avaliable_status":avaliable_status
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


















    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});