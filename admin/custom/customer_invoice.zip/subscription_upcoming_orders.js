$(document).ready(function() {

	var subscriptionorderJSON,subscription_order_id,mode,SubDepatmentJSON,filterJson;
	$.when(getsubscriptionOrderdetails()).done(function(){
			dispOrder(subscriptionorderJSON);				
	});


	function getsubscriptionOrderdetails()
	{
        var d = new Date();
        var localTime = d.getTime();
        var localOffset = d.getTimezoneOffset() * 60000;
        var utc = localTime + localOffset;
        var offset = 4;    //UTC of Dubai is +04.00
        var dubai = utc + (3600000*offset);

		var today = new Date(dubai);
		var dd = String(today.getDate()+1).padStart(2, '0');
		var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
		var yyyy = today.getFullYear();

		today =  yyyy + '-' + mm + '-' + dd;
		// document.write(today);

		$('.fromdateee').val(today);
		return $.ajax({
			url: base_URL+'/ThirdAxisCon/getsubscriptionupcomingOrderdetails',
			type:'POST',
            data: {
                "sort_date":today,
                "sort_status":' ',
            },
			success:function(data){
				//console.log(data);
				var js = $.parseJSON(data);
				subscriptionorderJSON = js.order_list;
				
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;
	}


	function dispOrder(JSON)
	{	
		//$('#success_alert').show(1000);
		//console.log(dataJSON);
        var d = new Date();
        var localTime = d.getTime();
        var localOffset = d.getTimezoneOffset() * 60000;
        var utc = localTime + localOffset;
        var offset = 4;    //UTC of Dubai is +04.00
        var dubai = utc + (3600000*offset);

		var today = new Date(dubai);
		var dd = String(today.getDate()).padStart(2, '0');
		var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
		var yyyy = today.getFullYear();

		todaysdatee =  yyyy + '-' + mm + '-' + dd;

		var i = 1;
		$('#Main_Category').dataTable( {
			"aaSorting":[],
			"aaData": JSON,
			responsive: true,
			"aoColumns": [
				{ 
					"mDataProp": function ( data, type, full, meta) 
					{
						return " <span >"+data.order_placed_datentime+" </span>";		
					}
				},		
				{ 
					"mDataProp": function ( data, type, full, meta) 
					{
						return ""+data.subscription_order_no+"";	
										
					}
				},	
				{ 
					"mDataProp": function ( data, type, full, meta) 
					{

						return ""+data.delivery_date+"";					
					}
				},	
				{ 
					"mDataProp": function ( data, type, full, meta) 
					{
						return ""+data.User_full_name+"";											
					}
				},		
				{ 
					"mDataProp": function ( data, type, full, meta) 
					{
						return ""+data.mobile_no+"";						
					}
				},

				{
                    "mDataProp": function(data, type, full, meta) 
					{

						return '<a id="' + meta.row + '" class="btn viewproductss" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;  view</a>&nbsp;&nbsp;';					
					}
                },		
				{ 
					"mDataProp": function ( data, type, full, meta) 
					{
						return " AED "+data.total_price+"";					
					}
				}			
			]  				
		});
	}
	


	$(document).on('click','#searchbtn_fltr_ordrcnfm',function()
	{
		$('.error').hide();
		var sort_date = $('.fromdateee').val();	
		return $.ajax({
			url: base_URL+'/ThirdAxisCon/getsubscriptionOrderdetails',
			type:'POST',
            data: {
                "sort_date":sort_date,
                "sort_status":' ',
            },
			success:function(data){
				//console.log(data);
				var js = $.parseJSON(data);
				subscriptionorderJSON = js.order_list;
				var table = $('#Main_Category').DataTable();
				table.destroy();	
				dispOrder(subscriptionorderJSON);					
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;

	});


	$(document).on('click','.viewproductss',function(){
		
		var r_index = $(this).attr('id');
		 subscription_order_id = subscriptionorderJSON[r_index].subscription_order_id;

			return $.ajax({
			url: base_URL+'ThirdAxisCon/getsubscriptionupcomingOrderdetailsbyid',
			type:'POST',
			data: {"subscription_order_id":subscription_order_id},
			success:function(data){
				$('#productmodel').modal('show');
				var js = $.parseJSON(data);
				SubDepatmentJSON = js.order_details;
				
				$('.appendproductdetail').html('');
				$('.appendproductinfotr').html('');
				for(var i=0;i<SubDepatmentJSON[0].produc_info.length;i++)
				{
					if(SubDepatmentJSON[0].produc_info[i].product_type=='AP')
					{
						offer_price='';
						if (SubDepatmentJSON[0].produc_info[i].prod_originalprice!=SubDepatmentJSON[0].produc_info[i].price_pt) 
						{
							offer_price='<small><s>'+SubDepatmentJSON[0].produc_info[i].prod_originalprice+'</s> </small>'+SubDepatmentJSON[0].produc_info[i].price_pt+'';
						}
						else
						{
							offer_price=''+SubDepatmentJSON[0].produc_info[i].price_pt+'';
						}

						$('.appendproductinfotr').append('<tr>'+
							'<td><img src="'+SubDepatmentJSON[0].produc_info[i].produ_imgurl+'" alt="product-img" height="52"></td>'+
	                        '<th scope="row">'+SubDepatmentJSON[0].produc_info[i].prod_code+' - '+SubDepatmentJSON[0].produc_info[i].prod_name+' ( '+SubDepatmentJSON[0].produc_info[i].prod_quantity+' '+SubDepatmentJSON[0].produc_info[i].unit+') </th>'+
	                        '<td>'+SubDepatmentJSON[0].produc_info[i].quantity+'</td>'+
	                        '<td>' +offer_price+'</td>'+
	                        '<td> '+SubDepatmentJSON[0].produc_info[i].prod_total_price+' </td>'+
	                    '</tr>');
					}
				};

				$('.appendorderinfobox').html('');
				$('.appendorderinfobox').append('  <p class="mb-2"><span class="font-weight-semibold mr-2 custom_pdf_style">Order Id </span> : #'+SubDepatmentJSON[0].subscription_order_no+'</p>'+
                '<p class="mb-2"><span class="font-weight-semibold mr-2 custom_pdf_style">Delivery Date  </span> : '+SubDepatmentJSON[0].delivery_date+'</p>'+
                '<p class="mb-2"><span class="font-weight-semibold mr-2 custom_pdf_style">Payment Type</span> : COD</p>');

				$('.appendaddress').html('');
				$('.appendaddress').append("<h4>"+SubDepatmentJSON[0].ad_username+",</h4>  <p>"+SubDepatmentJSON[0].flat_no+" , "+SubDepatmentJSON[0].building_name+" "+
					""+SubDepatmentJSON[0].landmark+""+SubDepatmentJSON[0].area+"  "+SubDepatmentJSON[0].city+"</p> <p> <b> Moble no : </b>"+SubDepatmentJSON[0].ad_mobile_no+"");


				$('.appendproductfooter').html('');
			    if(SubDepatmentJSON[0].prod_subtotal!=null && SubDepatmentJSON[0].prod_subtotal!="0" && SubDepatmentJSON[0].prod_subtotal!="")
			    {
					$('.appendproductfooter').append('<tr>'+
	                           ' <td scope="row" colspan="3" style="border:none" class="text-right"></td>'+
	                           ' <th scope="row" class="text-right" style="background: #f3f7f9;">Item total </th>'+
	                           ' <td style="background: #f3f7f9;"><div class="col-sm-12 font-weight-bold">'+
	                           '<input class="form-control order_ed_total_price_pt" name="order_ed_total_price_pt" readonly style="border:none;background:#f3f7f9;" value="'+SubDepatmentJSON[0].prod_subtotal+'" placeholder="Enter Brand Name">'+
	                           '</div>'+
	                   '</tr>');
			    }
			    if(SubDepatmentJSON[0].discount_price!=null && SubDepatmentJSON[0].discount_price!="0" && SubDepatmentJSON[0].discount_price!="" && SubDepatmentJSON[0].discount_price!=0)
			    {
					$('.appendproductfooter').append('<tr>'+
	                           ' <td scope="row" colspan="3" style="border:none" class="text-right"></td>'+
	                           ' <th scope="row" class="text-right" style="background: #f3f7f9;">Item Discount </th>'+
	                           ' <td style="background: #f3f7f9;"><div class="col-sm-12 font-weight-bold">'+
	                           '<input class="form-control order_ed_total_price_pt" name="order_ed_total_price_pt" readonly style="border:none;background:#f3f7f9;" value="'+SubDepatmentJSON[0].discount_price+'" placeholder="Enter Brand Name">'+
	                           '</div>'+
	                   '</tr>');
			    }
				$('.appendproductfooter').append('<tr>'+
                           ' <td scope="row" colspan="3" style="border:none" class="text-right"></td>'+
                           ' <th scope="row" class="text-right" style="background: #f3f7f9;">Total Bill Value </th>'+
                           ' <td style="background: #f3f7f9;"><div class="col-sm-12 font-weight-bold">'+
                           '<input class="form-control order_ed_total_price_pt" name="order_ed_total_price_pt" readonly style="border:none;background:#f3f7f9;" value="'+SubDepatmentJSON[0].total_price+'" placeholder="Enter Brand Name">'+
                           '</div>'+
                   '</tr>');
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;

	});
	
	
	
	$('#largeModal').on('show.bs.modal', function () {
		$(".no").hide();
		$('#hide').attr('checked', false);
		$('#show').attr('checked', false);
		$('#sdId').val('');
	    $(this).find('form').trigger('reset');
	    $('.appendaddress').html('');
	});	
	
	$('#productmodel').on('show.bs.modal', function () {
		$('.appendproductdetail').html('');
	});	
	
	
	function refreshDetails()
	{
		$.when(getsubscriptionOrderdetails()).done(function(){
			var table = $('#Main_Category').DataTable();
			table.destroy();	
			dispOrder(subscriptionorderJSON);				
		});		
	}

	$(document)
		.ajaxStart(function () {
		$(".loading").show();
		})
		.ajaxStop(function () {
		$(".loading").hide();
	});

});
