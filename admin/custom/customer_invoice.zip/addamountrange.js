$(document).ready(function() {

    var pricerangeJSOM,price_range_discount_id,mode;
    $.when(getpricerangediscountdetails()).done(function(){
            disppricerangediscount(pricerangeJSOM);    
    });
    
    function getpricerangediscountdetails()
    {
        return $.ajax({
            url: base_URL+'ThirdAxisCon/getpricerangediscountdetails',
            type:'POST',
            success:function(data){
                //console.log(data);
                pricerangeJSOM = $.parseJSON(data);
                
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;
    }

    
    function disppricerangediscount(JSON)
    {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
            var i = 1;
        $('#Sub_Category').dataTable( {
            "aaSorting":[],
            "aaData": JSON,
            responsive: true,
            "aoColumns": [
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return i++;                 
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.offer_name+' ';
                    }
                },                  
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.offer_from+'';
                    }
                },              
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.offer_to+' ';
                    }
                },          
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.price_range_from+' - '+ data.price_range_to+'';
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.price_range_discount_type=='P') 
                        {
                            return ''+ data.price_range_discount_value+' %';  
                        }
                        else if (data.price_range_discount_type=='A') 
                        {
                            return ''+ data.price_range_discount_value+' AED';    
                        }                       
                    }
                },
                { "mDataProp": "price_range_max_discount" },
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  Active</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Deactive</a>&nbsp;&nbsp;';;

                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },              
            ]               
        });
    }
    
    $('#New_Category').click(function(){
        mode="new";
        $('#largeModal').modal('show');
    });
    
    $(document).on('click','.BtnEdit',function(){
        mode="update";
        var r_index = $(this).attr('id');
        price_range_discount_id = pricerangeJSOM[r_index].price_range_discount_id;
        $('#largeModal').modal('show');
        $('#offer_name').val(pricerangeJSOM[r_index].offer_name);
        $('.offer_from').val(pricerangeJSOM[r_index].offer_from);
        $('.offer_to').val(pricerangeJSOM[r_index].offer_to);
        $('#price_range_from').val(pricerangeJSOM[r_index].price_range_from);
        $('#price_range_to').val(pricerangeJSOM[r_index].price_range_to);
        $('#price_range_discount_type').val(pricerangeJSOM[r_index].price_range_discount_type);
        $('#price_range_discount_value').val(pricerangeJSOM[r_index].price_range_discount_value);
        $('#price_range_max_discount').val(pricerangeJSOM[r_index].price_range_max_discount);

    });
        
    
    $(document).on('click','.BtnDelete',function(){
        mode="delete";
        var r_index = $(this).attr('id');
        price_range_discount_id = pricerangeJSOM[r_index].price_range_discount_id; 
           $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Are you Sure Do you want to Delete this Promo Code',
                type: 'blue',
                    buttons: {
                        Yes: function() {                   
                                request = $.ajax({
                                        type: "POST",
                                        url: base_URL+'ThirdAxisCon/Deletepricerangediscount',
                                        data: {"price_range_discount_id":price_range_discount_id},
                                }); 
                                request.done(function (response){
                                    var js = $.parseJSON(response);
                                    var status = js.result
                                    if (status == "success") {
                                        $.confirm({
                                            icon: 'icon-close',
                                            title: 'Info',
                                            content: 'Deleted Succesfully',
                                            type: 'green',
                                                buttons: {
                                                    Ok: function() {},
                                                }
                                        });
                                        refreshDetails();
                                    }
                                    else
                                    {
                                        $.confirm({
                                            icon: 'icon-close',
                                            title: 'Info',
                                            content: 'Are you Sure Do you want to Delete this Data',
                                            type: 'blue',
                                                buttons: {
                                                    No: function() {},
                                                }
                                        });
                                    }
                            
                                }); 
                        },
                        No: function() {},
                    }
            });
        
        
    

    });
    


    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        price_range_discount_id = pricerangeJSOM[r_index].price_range_discount_id;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Promo Code',
            type: 'blue',
            buttons: {
                Yes: function() {
                    Restorepromocode(price_range_discount_id,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        price_range_discount_id = pricerangeJSOM[r_index].price_range_discount_id;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Promo Code',
            type: 'blue',
            buttons: {
                Yes: function() {
                    Restorepromocode(price_range_discount_id,flag);
                },
                No: function() {},
            }
        });

    });


    function Restorepromocode(price_range_discount_id,flag)
    {
        var price_range_discount_id = price_range_discount_id;
        var flag = flag;        

        request = $.ajax({
                type: "POST",
                url: base_URL+'ThirdAxisCon/Restorepricerangediscount',
                data: {"price_range_discount_id":price_range_discount_id,"flag":flag},
        }); 
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


    
    $('#Promocode_Button').click(function(){
        $('.error').hide();

        if($('#offer_name').val()=="")
        {
            $('.offer_name').html("* Offer Name Cannot be empty");
            $('.offer_name').show();
        }

        else if($('.offer_from').val()=="")
        {
            $('.offer_from_error').html("* From Date Cannot be empty");
            $('.offer_from_error').show();
        }
        else if($('.offer_to').val()=="")
        {
            $('.offer_to_error').html("* To Date Cannot be empty");
            $('.offer_to_error').show();
        }   
        else if($('#price_range_from').val()=="" || $('#price_range_to').val()=="")
        {
            $('.price_range_error').html("* From and to Amount Cannot be empty");
            $('.price_range_error').show();
        }  
        else if( parseInt($('#price_range_from').val()) > parseInt($('#price_range_to').val()))
        {
            $('.price_range_error').html("* From Amount Cannot be greater than To Amount");
            $('.price_range_error').show();
        }  
        else if($('#price_range_discount_type').val()=="")
        {
            $('.price_range_discount_type').html("* Discount type Cannot be empty");
            $('.price_range_discount_type').show();
        }   
        else if($('#price_range_discount_value').val()=="")
        {
            $('.price_range_discount_value').html("* Discount value Cannot be empty");
            $('.price_range_discount_value').show();
        }   
        else if($('#price_range_max_discount').val()=="")
        {
            $('.price_range_max_discount').html("* Discount Max Allowed Cannot be empty");
            $('.price_range_max_discount').show();
        }       
        else
        {
            
            if(mode=="new")
            {
                savepromocode();
                // alert('hi');
            }
            else
            {
                updatepromocode();
                // alert('hi');
            }           
            
        }       
    });
    
    $('#largeModal').on('show.bs.modal', function () {
        $(this).find('form').trigger('reset');
    }); 
    
    function savepromocode()
    {       
        var form = $('#FormDataDetailss')[0];
        var data = new FormData(form);
        request = $.ajax({
                type: "POST",
                enctype: 'multipart/form-data',
                url: base_URL+'ThirdAxisCon/insertpricerangediscount',
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                timeout: 600000,
        }); 
        request.done(function (response){
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Inserted Sucessfully',
                    type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            }
            else
            {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                });
            }       
        });     
    }

    
    function updatepromocode()
    {
        var form = $('#FormDataDetailss')[0];
        var data = new FormData(form);
        data.append("price_range_discount_id",price_range_discount_id);
        request = $.ajax({
                type: "POST",
                enctype: 'multipart/form-data',
                url: base_URL+'ThirdAxisCon/updatepricerangediscount',
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                timeout: 600000,
        }); 
        request.done(function (response){
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            }
            else
            {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                });
            }       
        });         
    }

    function refreshDetails()
    {
        $.when(getpricerangediscountdetails()).done(function(){
            var table = $('#Sub_Category').DataTable();
            table.destroy();    
            disppricerangediscount(pricerangeJSOM);                
        });     
    }



  $(document)
  .ajaxStart(function () {
    $(".loading").show();
  })
  .ajaxStop(function () {
    $(".loading").hide();
  });

});
