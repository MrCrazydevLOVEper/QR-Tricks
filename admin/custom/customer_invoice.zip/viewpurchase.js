$(document).ready(function() {

    var list = $("#rows-list");
    var t = $("tbody#rows-list tr:first-child").html(); 
    var v = $("tbody#rows-list-view tr:first-child").html(); 
    var Purchaselist, area_master_id, mode;
    $.when(getpurchase()).done(function() {
        disppurchaselist(Purchaselist);
    });

    function getpurchase() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getpurchase',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                Purchaselist = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    function disppurchaselist(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": "purchase_date"
                }, {
                    "mDataProp": "bill_no"
                }, {
                    "mDataProp": "created_date"
                },{
                    "mDataProp": function(data, type, full, meta) {
                        return '<a id="' + meta.row + '" class="btn viewproductss" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;  view</a>&nbsp;&nbsp;';
                    }
                },{
                "mDataProp": function(data, type, full, meta) {
                    return '<a id="' + meta.row + '" class="addImage"><i class="fa fa-plus" aria-hidden="true"></i></a>' +
                        '<a id="' + meta.row + '" class="btn BtnImageEdit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;';

                }
                }, {
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },
            ]
        });
    }


    function refreshDetails() {
        $.when(getpurchase()).done(function() {
            var table = $('#Main_Category').DataTable();
            table.destroy();
            disppurchaselist(Purchaselist);
        });
    }



    $('#New_Category').click(function() {
        mode = "new";
        $('#largeModal').modal({
              backdrop: 'static',
             keyboard: false 
        });
        $('#product-info-id').hide();
        $('.dispaddprodandviewprod').hide();
    });

    $(document).on('click', '.viewproductss', function() {
        var r_index = $(this).attr('id');
        yb_purchase_bill_id = Purchaselist[r_index].yb_purchase_bill_id;
        var flag = flag;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/viewprocurmentproducts',
            data: {
                "yb_purchase_bill_id": yb_purchase_bill_id
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            $('#largeviewModal').modal({
                  backdrop: 'static',
                 keyboard: false 
            });
            var purchase_products = js.purchase_products;
            $('#purchase_date_view').val(purchase_products[0]["purchase_date"]);
            $('#bill_no_view').val(purchase_products[0]["bill_no"]);
            $('#product-info-view-id').show();
            $('tbody#rows-list-view').html('');
            if (purchase_products.length>=1) 
            {
                var sub_total = 0;
                for (var i = 0; i < purchase_products[0].purchase_products_list.length; i++) 
                {
                    $("tbody#rows-list-view").append("<tr>" + v + "</tr>");
                    sub_total += Number(purchase_products[0].purchase_products_list[i].total_product_price);

                    if(purchase_products[0].purchase_products_list[i].purchase_product_type=='Avaliableproduct')
                    {
                        $('.order_prod_name').last().append(purchase_products[0].purchase_products_list[i].purchase_product+' ( '+purchase_products[0].purchase_products_list[i].purchase_product_unit+' )');
                        $('.order_prod_vendor_name').last().append(purchase_products[0].purchase_products_list[i].vendor_name);
                        $('.order_prod_qty').last().append(purchase_products[0].purchase_products_list[i].purchase_product_quantity);
                        $('.order_prod_wst').last().append(purchase_products[0].purchase_products_list[i].purchase_wastages);
                        $('.order_prod_sal').last().append(purchase_products[0].purchase_products_list[i].salable_stock);
                        $('.order_prod_exp').last().append(purchase_products[0].purchase_products_list[i].expiry_date);
                        $('.order_prod_price').last().append(purchase_products[0].purchase_products_list[i].purchase_product_price);
                        $('.order_prod_total').last().append(purchase_products[0].purchase_products_list[i].total_product_price);
                    }
                    else
                    {
                        $('.order_prod_name').last().append(purchase_products[0].purchase_products_list[i].purchase_product+' ( '+purchase_products[0].purchase_products_list[i].purchase_product_unit+' )');
                        $('.order_prod_vendor_name').last().append(purchase_products[0].purchase_products_list[i].vendor_name);
                        $('.order_prod_qty').last().append(purchase_products[0].purchase_products_list[i].purchase_product_quantity);
                        $('.order_prod_wst').last().append(purchase_products[0].purchase_products_list[i].purchase_wastages);
                        $('.order_prod_sal').last().append(purchase_products[0].purchase_products_list[i].salable_stock);
                        $('.order_prod_exp').last().append(purchase_products[0].purchase_products_list[i].expiry_date);
                        $('.order_prod_price').last().append(purchase_products[0].purchase_products_list[i].purchase_product_price);
                        $('.order_prod_total').last().append(purchase_products[0].purchase_products_list[i].total_product_price);
                    }
                }
                $('.appendproductfooter_view').html('');
                $('.appendproductfooter_view').append('<tr>'+
                           ' <td scope="row" colspan="6" style="border:none" class="text-right"></td>'+
                           ' <td scope="row" class="text-right" style="background: #f3f7f9;">Item total </td>'+
                           ' <td style="background: #f3f7f9;"><div class="col-sm-12 font-weight-bold">'+
                           ''+sub_total.toFixed(2)+'</td>'+                           
                   '</tr>');
                // $('.purchased_total_amt').val(sub_total.toFixed(2));

                 $('.displaybillimagesview').html('');
                 if (purchase_products[0].purchase_products_bill_img.length>0) 
                 {
                    for (var i = 0; i < purchase_products[0].purchase_products_bill_img.length; i++) 
                    {
                        $('.displaybillimagesview').append(                            
                        "<div class='pro-im'>" +
                        "<img src='" + purchase_products[0].purchase_products_bill_img[i]["bill_image_url"] + "' alt='user' width=100>" +
                        "<div class='pro-img-overlay'>" +
                        "<ul class='pro-img-overlay-1'>" +
                        "<li class='el-item'>" +
                        "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href='" + purchase_products[0].purchase_products_bill_img[i]["bill_image_url"] + "'>" +
                        "<i class='fa fa-eye'></i></a>" +
                        "</li>" +
                        "</ul></div></div>"+
                       '');                        
                    }                    
                 }
                 else
                 {
                    $('.displaybillimagesview').append('<p>No images added</p>');
                 }
            }
            else
            {
                $("tbody#rows-list-view").append("<tr>" + v + "</tr>");
                $('.appendproductfooterview').html('');
            }

        });
        
    });




    $('#closepurchasemodelview').click(function() 
    {
        $('#largeviewModal').modal('hide');
    });





    $(document).on('click', '.BtnEdit', function() {
        mode = "update";
        var r_index = $(this).attr('id');
        yb_purchase_bill_id = Purchaselist[r_index].yb_purchase_bill_id;

         window.location.replace(''+base_URL+'/ThirdAxisCon/edit_procurement/'+yb_purchase_bill_id+'');

    });


    $(document).on('click', '.BtnDelete', function() {
        //mode = "delete";
        var r_index = $(this).attr('id');
        yb_purchase_bill_id = Purchaselist[r_index].yb_purchase_bill_id;
        $.confirm({
            title: 'Delete',
            content: 'Are you sure you want to delete this bill ?',
            type: 'blue',
            buttons: {
                ok: function() {
                    request = $.ajax({
                        type: "POST",
                        url: base_URL + 'ThirdAxisCon/deletepurchasebills',
                        data: {
                            "yb_purchase_bill_id": yb_purchase_bill_id
                        },
                        success: function(data) {
                            //                            $("#image-display").load(" #image-display > *");
                            var js = $.parseJSON(data);
                            var status = js.status;
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Deleted Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                            refreshDetails();
                        },
                        error: function() {
                            console.log("Error");
                        }
                    });
                },
                cancel: function() {

                }
            }
        });

    });



    /*Add Thumbnail images for product start*/

    $(document).on('click', '.addImage', function() {
        mode = "insert"
        var r_index = $(this).attr('id');
        yb_purchase_bill_id = Purchaselist[r_index].yb_purchase_bill_id;
        $('#addImageForm').modal('show');
        $('#hidden_id').val(yb_purchase_bill_id);
        $('#hidden_date').val(Purchaselist[r_index].purchase_date);
    });

    $(document).on('click', '.BtnImageEdit', function() {
        var r_index = $(this).attr('id');
        yb_purchase_bill_id = Purchaselist[r_index].yb_purchase_bill_id;
        $('#imageEditForm').modal('show');
        $('#hidden_id').val(yb_purchase_bill_id);

        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/getpurchasebillImages',
            data: {
                "yb_purchase_bill_id": yb_purchase_bill_id
            },
        });
        request.done(function(response) {
            var result = $.parseJSON(response);
            $('#user_uploaded_image1').html('');
            if (result.length>0) 
            {
                for (var i = 0; i < result.length; i++) {
                    // console.log(imageName[i]);
                    $('#user_uploaded_image1').append('<div class="image-display" id="image-display' + result[i].purchase_bill_img_id + '"><div><img src="' + result[i].bill_image_url + '" class="user-update-image" alt="user profile" width="100px" style="padding-top: 15px;"></div><div class="image-delete-icon"><i class="fa fa-trash image-delete" id="' + result[i].purchase_bill_img_id + '"></i></div></div>');
                }
            }
            
        });
    });

    /*====== Start Delete image ======*/

    $(document).on('click', '.image-delete', function() {
        //mode = "delete";
        var productImageId = $(this).attr('id');
        $.confirm({
            title: 'Delete',
            content: 'Are you sure you want to delete this image ?',
            type: 'blue',
            buttons: {
                ok: function() {
                    request = $.ajax({
                        type: "POST",
                        url: base_URL + 'ThirdAxisCon/deletepurchasebillImage',
                        data: {
                            "product_image_id": productImageId
                        },
                        success: function(data) {
                            //                            $("#image-display").load(" #image-display > *");
                            $('#image-display' + productImageId).remove();
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Deleted Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                        },
                        error: function() {
                            console.log("Error");
                        }
                    });
                },
                cancel: function() {

                }
            }
        });

    });
    /*====== End Delete image ======*/


    $('#upload_image').click(function() {
        if (mode == "insert") {
            insertThumbnaiImage();
        }
    });

    function insertThumbnaiImage() {
        var form = $('#product_image_form')[0];
        var data = new FormData(form);
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/InsertpurchasebillImage',
            method: "POST",
            data: data,
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                var js = $.parseJSON(data);
                var status = js.result
                if (status == "success") {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Inserted Sucessfully',
                        type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                    $('#addImageForm').modal('hide');
                    refreshDetails();
                } else if (status == "imgerror") {

                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Please Do check your image size and upload <br> max size of img 2000000',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                } else {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Error',
                        content: 'Sorry Something went worng please try again',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                }
            },
            error: function() {
                console.log("Error");
            }
        });
    }

    $('#addImageForm').on('show.bs.modal', function() {
        $(this).find('form').trigger('reset');
    });

    /*Add Thumbnail images for product end*/


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});