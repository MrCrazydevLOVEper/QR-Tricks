$(document).ready(function() {

    var url = window.location.href;
    var parts = url.split('/');
    var lastSegment = parts.pop() || parts.pop();
    var settingJSON,settings_id,mode;
    $.when(getsettingdetails()).done(function(){
            dispsettingdisp(settingJSON);     
    });
    
    function getsettingdetails()
    {
        return $.ajax({
            url: base_URL+'ThirdAxisCon/get_customer_clasification_settings_list_details',
            type:'POST',
            data: {
                "url_type":lastSegment,
            },
            success:function(data){
                settingJSON = $.parseJSON(data);

                console.log(settingJSON);
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;
    }     

    
    function dispsettingdisp(JSON)
    {
        var i = 1;
        $('#Sub_Category').dataTable( {
            "aaSorting":[],
            "aaData": JSON,
            responsive: true,
            "aoColumns": [
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return i++;                 
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.start_value+' ';
                    }
                }, 
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.end_value+' ';
                    }
                }, 
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.points+' ';
                    }
                }, 
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  visible</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Hidden</a>&nbsp;&nbsp;';

                    }
                }, 
                {
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;';
                    }
                },              
            ]               
        });
    }

    $('#New_Category').click(function(){
        mode="new";
        $('#largeModal').modal('show');
    });
    

    $(document).on('click','.BtnEdit',function(){
        mode="update";
        var r_index = $(this).attr('id');
        settings_id = settingJSON[r_index].settings_id;
        $('#largeModal').modal('show');
        $('#start_value').val(settingJSON[r_index].start_value);
        $('#end_value').val(settingJSON[r_index].end_value);
        $('#points').val(settingJSON[r_index].points);
    });


    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        settings_id = settingJSON[r_index].settings_id;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this data',
            type: 'blue',
            buttons: {
                Yes: function() {
                    Restorepromocode(settings_id,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        settings_id = settingJSON[r_index].settings_id;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this data',
            type: 'blue',
            buttons: {
                Yes: function() {
                    Restorepromocode(settings_id,flag);
                },
                No: function() {},
            }
        });

    });


    function Restorepromocode(settings_id,flag)
    {
        var settings_id = settings_id;
        var flag = flag;        

        request = $.ajax({
                type: "POST",
                url: base_URL+'ThirdAxisCon/updateflag_customer_clasification_settings',
                data: {"settings_id":settings_id,"flag":flag,"url_type":lastSegment},
        }); 
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }
    
    $('#FormDataDetailss_Button').click(function(){
        $('.error').hide();

        if($('#start_value').val()=="" || $('#end_value').val()=="")
        {
            $('.start_end_range_error').html("* Values Cannot be empty");
            $('.start_end_range_error').show();
        }  
        else if( parseInt($('#start_value').val()) > parseInt($('#end_value').val()))
        {
            $('.start_end_range_error').html("* Start value Cannot be greater than End value");
            $('.start_end_range_error').show();
        }  
        else if($('#points').val()=="")
        {
            $('.points').html("* Points value Cannot be empty");
            $('.points').show();
        }         
        else
        {            
            if(mode=="new")
            {
                savesettings();
            }
            else
            {
                updatesettings();
            }              
        }       
    });
    
    $('#largeModal').on('show.bs.modal', function () {
        $(this).find('form').trigger('reset');
    }); 
    
    function savesettings()
    {       
        var form = $('#FormDataDetailss')[0];
        var data = new FormData(form);
        data.append("url_type",lastSegment);
        request = $.ajax({
                type: "POST",
                enctype: 'multipart/form-data',
                url: base_URL+'ThirdAxisCon/insert_customer_clasification_settings',
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                timeout: 600000,
        }); 
        request.done(function (response){
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Inserted Sucessfully',
                    type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            }
            else
            {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                });
            }       
        });     
    }

    function updatesettings()
    {
        var form = $('#FormDataDetailss')[0];
        var data = new FormData(form);
        data.append("settings_id",settings_id);
        data.append("url_type",lastSegment);
        request = $.ajax({
                type: "POST",
                enctype: 'multipart/form-data',
                url: base_URL+'ThirdAxisCon/update_customer_clasification_settings',
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                timeout: 600000,
        }); 
        request.done(function (response){
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            }
            else
            {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                });
            }       
        });         
    }

    function refreshDetails()
    {
        $.when(getsettingdetails()).done(function(){
            var table = $('#Sub_Category').DataTable();
            table.destroy();    
            dispsettingdisp(settingJSON);                
        });     
    }

    $(document)
    .ajaxStart(function () {
        $(".loading").show();
    })
    .ajaxStop(function () 
    {
        $(".loading").hide();
    });

});
