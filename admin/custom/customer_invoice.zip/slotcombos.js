$(document).ready(function() {

    var SlotcomboJSON, slot_combo_id, mode;
    var imageoneinserted='';
    var imagetwoinserted='';
    $.when(getslotcombosdetails()).done(function() {
        dispslotcombosdetails(SlotcomboJSON);
    });

    function getslotcombosdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getslotcombosdetails',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                SlotcomboJSON = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    function dispslotcombosdetails(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [

				{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },

                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.slot_prod1_img !== null)
                        //return "<a href="+data.mobile_imageurl+" target='_blank'>Click to view Image</a>";
                        //return "<img src="+data.mobile_imageurl+" width=100>";
                            return "<div class='pro-im'>" +
                            "<img src=" + data.slot_prod1_img + " alt='slot img' width=100>" +
                            "<div class='pro-img-overlay'>" +
                            "<ul class='pro-img-overlay-1'>" +
                            "<li class='el-item'>" +
                            "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href=" + data.slot_prod1_img + ">" +
                            "<i class='mdi mdi-magnify-plus'></i></a>" +
                            "</li>" +
                            "</ul></div></div><br> (" + data.slot_prod1 +")";
                        else
                            return '';
                    }
                },

                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.slot_prod2_img !== null)
                        //return "<a href="+data.mobile_imageurl+" target='_blank'>Click to view Image</a>";
                        //return "<img src="+data.mobile_imageurl+" width=100>";
                            return "<div class='pro-im'>" +
                            "<img src=" + data.slot_prod2_img + " alt='slot img' width=100>" +
                            "<div class='pro-img-overlay'>" +
                            "<ul class='pro-img-overlay-1'>" +
                            "<li class='el-item'>" +
                            "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href=" + data.slot_prod2_img + ">" +
                            "<i class='mdi mdi-magnify-plus'></i></a>" +
                            "</li>" +
                            "</ul></div></div><br> (" + data.slot_prod2 +")";
                        else
                            return '';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.slot_prod3_img !== null)
                        //return "<a href="+data.mobile_imageurl+" target='_blank'>Click to view Image</a>";
                        //return "<img src="+data.mobile_imageurl+" width=100>";
                            return "<div class='pro-im'>" +
                            "<img src=" + data.slot_prod3_img + " alt='slot img' width=100>" +
                            "<div class='pro-img-overlay'>" +
                            "<ul class='pro-img-overlay-1'>" +
                            "<li class='el-item'>" +
                            "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href=" + data.slot_prod3_img + ">" +
                            "<i class='mdi mdi-magnify-plus'></i></a>" +
                            "</li>" +
                            "</ul></div></div><br> (" + data.slot_prod3 +")";
                        else
                            return '';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                            return data.slot_price;
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.product_type=='high') 
                        {
                            return "High";
                        }
                        if (data.product_type=='low') 
                        {
                            return "Low";
                        }
                        if (data.product_type=='medium') 
                        {
                            return "Medium";
                        }
                    }
                },
      
                // {
                //     "mDataProp": function(data, type, full, meta) {
                //         if (data.web_imageurl !== null)
                //         //return "<a href="+data.web_imageurl+" target='_blank'>Click to view Image</a>";
                //         //return "<img src="+data.web_imageurl+" width=100>";
                //             return "<div class='pro-im'>" +
                //             "<img src=" + data.web_imageurl + " alt='user' width=100>" +
                //             "<div class='pro-img-overlay'>" +
                //             "<ul class='pro-img-overlay-1'>" +
                //             "<li class='el-item'>" +
                //             "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href=" + data.web_imageurl + ">" +
                //             "<i class='mdi mdi-magnify-plus'></i></a>" +
                //             "</li>" +
                //             "</ul></div></div>";
                //         else
                //             return '';
                //     }
                // },
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  visible</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Hidden</a>&nbsp;&nbsp;';;

                    }
                },
                 {
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },
            ]
        });
    }

    $('#New_Category').click(function() {
        mode = "new";

        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getallproductslistt',
            type: 'POST',
            success: function(data) {
                $('#slot_prod1').html('');
                var productlistJSON = $.parseJSON(data);

                 $('#slot_prod1').each(function() {
                    if (this.selectize) {
                        for(x=0; x < productlistJSON.products.length; ++x){
                            this.selectize.addOption({value:productlistJSON.products[x]['prod_code'], text: productlistJSON.products[x]['prod_value']});
                        }
                    }
                }); 
                 $('#slot_prod2').each(function() {
                    if (this.selectize) {
                        for(x=0; x < productlistJSON.products.length; ++x){
                            this.selectize.addOption({value:productlistJSON.products[x]['prod_code'], text: productlistJSON.products[x]['prod_value']});
                        }
                    }
                }); 
                 $('#slot_prod3').each(function() {
                    if (this.selectize) {
                        for(x=0; x < productlistJSON.products.length; ++x){
                            this.selectize.addOption({value:productlistJSON.products[x]['prod_code'], text: productlistJSON.products[x]['prod_value']});
                        }
                    }
                }); 

                $('#largeModal').modal('show');

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });


    });

    $(document).on('click', '.BtnEdit', function() {
        mode = "update";
        var r_index = $(this).attr('id');

        request = $.ajax({
            url: base_URL + 'ThirdAxisCon/getallproductslistt',
        });
        request.done(function(data) {
            var productlistJSON = $.parseJSON(data);

             $('#slot_prod1').each(function() {
                if (this.selectize) {
                    for(x=0; x < productlistJSON.products.length; ++x){
                        this.selectize.addOption({value:productlistJSON.products[x]['prod_code'], text: productlistJSON.products[x]['prod_value']});
                    }
                }
            }); 
             $('#slot_prod2').each(function() {
                if (this.selectize) {
                    for(x=0; x < productlistJSON.products.length; ++x){
                        this.selectize.addOption({value:productlistJSON.products[x]['prod_code'], text: productlistJSON.products[x]['prod_value']});
                    }
                }
            }); 
             $('#slot_prod3').each(function() {
                if (this.selectize) {
                    for(x=0; x < productlistJSON.products.length; ++x){
                        this.selectize.addOption({value:productlistJSON.products[x]['prod_code'], text: productlistJSON.products[x]['prod_value']});
                    }
                }
            }); 
             $('#largeModal').modal('show');

            
            setTimeout(function(){ seteditvalues(r_index); }, 500);
        });       

    });



    function seteditvalues(r_index) 
    {        
        $('#slot_price').val(SlotcomboJSON[r_index].slot_price);
        $('#product_type').val(SlotcomboJSON[r_index].product_type);
        slot_combo_id = SlotcomboJSON[r_index].slot_combo_id;
        var $select = $("#slot_prod1").selectize();
        var selectize = $select[0].selectize;
        var yourDefaultIds = SlotcomboJSON[r_index].slot_prod1; 
        selectize.setValue(yourDefaultIds);

        var $select = $("#slot_prod2").selectize();
        var selectize = $select[0].selectize;
        var yourDefaultIds = SlotcomboJSON[r_index].slot_prod2; 
        selectize.setValue(yourDefaultIds);

        var $select = $("#slot_prod3").selectize();
        var selectize = $select[0].selectize;
        var yourDefaultIds = SlotcomboJSON[r_index].slot_prod3; 
        selectize.setValue(yourDefaultIds);
    }


    $(document).on('click', '.BtnDelete', function() {
        mode = "delete";
        var r_index = $(this).attr('id');
        slot_combo_id = SlotcomboJSON[r_index].slot_combo_id;
        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Delete this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                    request = $.ajax({
                        type: "POST",
                        url: base_URL + 'ThirdAxisCon/deleteslotcombosimage',
                        data: {
                            "slot_combo_id": slot_combo_id
                        },
                    });
                    request.done(function(response) {
                        var js = $.parseJSON(response);
                        var status = js.result
                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Deleted Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                            refreshDetails();
                        } else {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Are you Sure Do you want to Delete this Data',
                                type: 'blue',
                                buttons: {
                                    No: function() {},
                                }
                            });
                        }

                    });
                },
                No: function() {},
            }
        });

    });

    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        slot_combo_id = SlotcomboJSON[r_index].slot_combo_id;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestorerowDatas(slot_combo_id,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        slot_combo_id = SlotcomboJSON[r_index].slot_combo_id;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestorerowDatas(slot_combo_id,flag);
                },
                No: function() {},
            }
        });

    });


    function RestorerowDatas(slot_combo_id,flag)
    {
    	var slot_combo_id = slot_combo_id;
    	var flag = flag;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/Restoreslotcombosimage',
            data: {
                "slot_combo_id": slot_combo_id,"flag":flag
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


    $('#formdetails_submit').click(function() {
        $('.error').hide();
        if ($('#slot_prod1').val() == "") {
            $('.slot_prod1').html("* Please Select Product ");
            $('.slot_prod1').show();
        } 
        if ($('#slot_prod2').val() == "") {
            $('.slot_prod2').html("* Please Select Product ");
            $('.slot_prod2').show();
        } 
        if ($('#slot_prod3').val() == "") {
            $('.slot_prod3').html("* Please Select Product ");
            $('.slot_prod3').show();
        } 
        if ($('#slot_price').val() == "") {
            $('.slot_price').html("* Slot price cannot be empty ");
            $('.slot_price').show();
        } 
        if ($('#product_type').val() == "") {
            $('.product_type').html("* Please Enter Product type ");
            $('.product_type').show();
        }        

        else {
            if (mode == "new") 
            {
                saveslotcombo();
            } 
            else 
            {
                updateslotcombo();
            }

        }
    });

    function saveslotcombo() {
        var form = $('#formdatadetails')[0];
        var data = new FormData(form);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/insertslotcombosimages',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Inserted Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }
        });
    }

    function refreshDetails() {
        $.when(getslotcombosdetails()).done(function() {
            var table = $('#Main_Category').DataTable();
            table.destroy();
            dispslotcombosdetails(SlotcomboJSON);
        });
    }

    function updateslotcombo() {
        var form = $('#formdatadetails')[0];
        var data = new FormData(form);
        data.append("slot_combo_id", slot_combo_id);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/updateslotcombosimage',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } else {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }		
        });
    }

    $('#largeModal').on('show.bs.modal', function() {
        $(".no").hide();
        $(this).find('form').trigger('reset');

         var $select = $('#slot_prod1').selectize();
         var control = $select[0].selectize;
         control.clear();    

         var $select = $('#slot_prod2').selectize();
         var control = $select[0].selectize;
         control.clear();         
         
         var $select = $('#slot_prod3').selectize();
         var control = $select[0].selectize;
         control.clear();

    });


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});