$(document).ready(function() {

    var ReportDetailsJSON, area_master_id, mode;
    $.when(getreportdetails()).done(function() {
        dispDetailslist(ReportDetailsJSON);
    });

    function getreportdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/promousagereport',
            type: 'POST',
            success: function(data) 
            {
                ReportDetailsJSON = $.parseJSON(data);
            },
            error: function() 
            {
                console.log("Error");
            }
        });
    }

    function dispDetailslist(JSON) 
    {
        var i =1;
        $('#yalla_pusage_report').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: ' Promo Usage Report',
                    text: "Export as Excel",
                     exportOptions: {
                        message: " Promo Usage Report",
                        columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    },
                },            
            ],
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.order_placed_datentime==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.order_placed_datentime;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.orderno==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.orderno;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.user_unique_id==null) 
                        {
                            return 'Guest User';
                        }
                        else
                        {
                            return data.user_unique_id;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.username_last==null || data.username_last==' ') 
                        { 
                            return '<span style="color:red">Guest Order </span><br>('+data.username_last+')';
                            // return data.ad_username;
                        }
                        else
                        {
                            return data.username_last; 
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.promocode_type==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return  data.promocode_type.replace(/[^a-zA-Z ]/g, " ");   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.promocode_discount_type=='A') 
                        {
                            return 'AED '+data.promocode_discount_value+' ';   
                        }
                        else
                        {
                            return '% '+data.promocode_discount_value+' ';   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.promo_code==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.promo_code;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.orderbag_total==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.orderbag_total;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.total_price==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.total_price;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.promocode_price==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return ''+data.promocode_price+'';   
                        }                        
                    }
                },
            ]
        });
    }

    function refreshDetails() {
        $.when(getreportdetails()).done(function() {
            var table = $('#yalla_pusage_report').DataTable();
            table.destroy();
            dispDetailslist(ReportDetailsJSON);
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});