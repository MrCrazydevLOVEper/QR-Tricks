$(document).ready(function() {

    var wastageJSON,AllProductList,yb_purchase_bill_id,wastages_record_id,mode;
    $.when(getwastageproductlist()).done(function(){
            dispwastageaddedproducts(wastageJSON);     
            getproductlist();
    });
    
    function getwastageproductlist()
    {
        var selected_date='';
        var selected_product='';
        return $.ajax({
            url: base_URL+'ThirdAxisCon/getallwastagehistory',
            type:'POST',
            data: {
                "selected_date":selected_date,"selected_product":selected_product
            },
            success:function(data){
                wastageJSON = $.parseJSON(data);
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;
    }     

    function getproductlist()
    {
        return $.ajax({
            url: base_URL+'ThirdAxisCon/getallproductslistt',
            type:'POST',
            success:function(data)
            {
                AllProductList = $.parseJSON(data);
                dispallproductlist(AllProductList)
            },      
            error: function() {
                console.log("Error");  
            }
        }) ;
    }

    function dispallproductlist(JSON)
    {
         $('.product_code').each(function() {
            if (this.selectize) {
                for(x=0; x < JSON.products.length; ++x){
                    this.selectize.addOption({value:JSON.products[x].prod_code, text: JSON.products[x].prod_value});
                }
            }
        }); 
    }

    
    function dispwastageaddedproducts(JSON)
    {
        var i = 1;
        $('#Sub_Category').dataTable( {
            "aaSorting":[],
            "aaData": JSON,
            responsive: true,
            "aoColumns": [
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return i++;                 
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.wastages_date+' ';
                    }
                },                  
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.prd_code+' - '+ data.prod_name+'';
                    }
                },              
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.wastages_count+' '+ data.purchase_product_unit+'';
                    }
                },          
                {
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnRevert Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-retweet" aria-hidden="true"></i>  Revert</a>&nbsp;&nbsp;';
                    }
                },              
            ]               
        });
    }
    
    
    $('#wastagesort_Button').click(function()
    {
        $('.error').hide();
        var selected_date= $('#basic-datepicker').val();
        var selected_product= $('#product_code').val();
        return $.ajax({
            url: base_URL+'ThirdAxisCon/getallwastagehistory',
            type:'POST',
            data: {
                "selected_date":selected_date,"selected_product":selected_product
            },
            success:function(data)
            {
                wastageJSON = $.parseJSON(data);
                var table = $('#Sub_Category').DataTable();
                table.destroy();  
                dispwastageaddedproducts(wastageJSON); 

            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;      
    });    
    

    $(document).on('click', '.BtnRevert', function() 
    {
        var r_index = $(this).attr('id');
        var purchase_products_id = wastageJSON[r_index].purchase_products_id;
        wastages_record_id = wastageJSON[r_index].wastages_record_id;
        var wastages_count = wastageJSON[r_index].wastages_count;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you sure do you want to Revert this data',
            type: 'blue',
            buttons: {
                yes: function() 
                {
                   Revertwastageproduct(purchase_products_id,wastages_record_id,wastages_count);
                },
                No: function() 
                {

                },
            }
        });
     
    });

    function Revertwastageproduct(purchase_products_id,wastages_record_id, wastages_count) 
    {
        return $.ajax({
            url: base_URL+'ThirdAxisCon/revertwastageproduct',
            type:'POST',
            data: {
                "purchase_products_id":purchase_products_id,"wastages_record_id":wastages_record_id,"wastages_count":wastages_count
            },
            success:function(data){
                var js = $.parseJSON(data);
                var status = js.result;
                if (status == "success") 
                {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Reverted Sucessfully',
                        type: 'green',
                            buttons: {
                                Ok: function() {},
                            }
                    });
                    $( "#wastagesort_Button" ).trigger( "click" );
                } 
                else 
                {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Sorry unnabale Revert',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                } 
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;
    }


    $(document)
    .ajaxStart(function () {
        $(".loading").show();
    })
    .ajaxStop(function () 
    {
        $(".loading").hide();
    });

});
