$(document).ready(function() {

    var ReportDetailsJSON, area_master_id, mode;
    $.when(getreportdetails()).done(function() {
        dispDetailslist(ReportDetailsJSON);
    });

    function getreportdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/ordercancellationreport',
            type: 'POST',
            success: function(data) 
            {
                ReportDetailsJSON = $.parseJSON(data);
            },
            error: function() 
            {
                console.log("Error");
            }
        });
    }

    function dispDetailslist(JSON) 
    {
        var i =1;
        $('#yalla_ocancel_report').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: ' Order Cancellation Report',
                    text: "Export as Excel",
                     exportOptions: {
                        message: " Order Cancellation Report",
                        columns: [ 1, 2, 3, 4, 5, 6, 7]
                    },
                },            
            ],
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.user_unique_id==null) 
                        {
                            return 'Guest User';
                        }
                        else
                        {
                            return data.user_unique_id;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.username==null || data.username==' ') 
                        { 
                            return '<span style="color:red">Guest Order </span><br>('+data.ad_username+')';
                            // return data.ad_username;
                        }
                        else
                        {
                            return data.username; 
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.order_place_date==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.order_place_date;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.order_completed_date==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.order_completed_date;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.orderno==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.orderno;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.total_price==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.total_price;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.order_celreason==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.order_celreason;   
                        }                        
                    }
                },
            ]
        });
    }

    function refreshDetails() {
        $.when(getreportdetails()).done(function() {
            var table = $('#yalla_ocancel_report').DataTable();
            table.destroy();
            dispDetailslist(ReportDetailsJSON);
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});