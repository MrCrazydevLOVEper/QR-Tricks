$(document).ready(function() {


    var url = window.location.href;
    var parts = url.split('/');
    var lastSegment = parts.pop() || parts.pop();
    var orderJSON ;
    var products_added_fynl_array=[];
    var products_aval_code=[];
    var products_req_code=[];
    var yb_user_address=[];
    var Addressjson;
    var t = $("tbody#rows-list tr:first-child").html(); 

// ==================================================================================================================//

    // Common function
    $.when(getorderdetailsforedit()).done(function()
    {
            products_added_fynl_array=orderJSON[0]["product_info_details"];
            yb_user_address=orderJSON[0]["address_info_details"];
            products_aval_code=orderJSON[0]["products_aval_code"];
            products_req_code=orderJSON[0]["products_req_code"];
            Addressjson = orderJSON[0]["Addressjson"];
            toggleElements();
            appendproducts();
            append_address_function();

            $('.order_no_value').html('');
            $('.order_no_value').append(''+orderJSON[0]["orderno"]+'');

            $('.ordered_date_value').html('');
            $('.ordered_date_value').append(''+orderJSON[0]["order_st_date"]+'');

            $('.delivery_date').val(orderJSON[0]["delivery_date"]);
            $('#user_unique_id').val(orderJSON[0]["user_unique_id"]);

    });        

    $( "#product_type" ).val('Avaliableproduct');
    $( "#product_type" ).trigger( "change" );

    // $(document).ready(toggleElements,appendproducts);

    $(document).on('keypress blur', '.numbersOnly', function() {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    });



// ==================================================================================================================//

    // Get order detail function

    function getorderdetailsforedit()
    {
        // console.log(lastSegment);

        return $.ajax({
            url: base_URL+'ThirdAxisCon/getorderdetailsforedit',
            type:'POST',
            data: {
                "orderno":lastSegment,
            },
            success:function(data){
                orderJSON = $.parseJSON(data);
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;
    } 


// ==================================================================================================================//

    // Product append function

        function appendproducts()
        {
            $('tbody#rows-list').html('');

            var prod_discount = 0;
            var prod_bag_sub_total = 0;
            var prod_bag_total = 0;
            var requested_prod_bag_total = 0;
            var avaliable_prod_bag_total = 0;
            var slot_prod_bag_total = 0;
            var order_promo_discount = 0;
            var order_price_range_discount= 0;


            for (var i = 0; i < products_added_fynl_array.length; i++) 
            {   
                $('.appendproductfooter').show();
                $("tbody#rows-list").append("<tr>" + t + "</tr>");

                if (products_added_fynl_array[i]["product_type"]=='Avaliableproduct') 
                {
                    prod_bag_sub_total += parseFloat(products_added_fynl_array[i]["original_amt"]).toFixed(2)  * parseFloat(products_added_fynl_array[i]["product_quantity"]).toFixed(2);
                    avaliable_prod_bag_total+= parseFloat(products_added_fynl_array[i]["product_price"]).toFixed(2)  * parseFloat(products_added_fynl_array[i]["product_quantity"]).toFixed(2);

                    $('.order_prod_img').last().append('<img src="'+products_added_fynl_array[i].produ_imgurl+'" alt="product-img" height="52">');
                    $('.order_prod_name').last().append(''+products_added_fynl_array[i].prod_name+' ( '+products_added_fynl_array[i].product_weight+'  '+products_added_fynl_array[i].unit_id+')');

                    $('.order_prod_qty').last().append('<div class="col-sm-12">'+
                                        '<input class="form-control numbersOnly" id="product_quantity'+i+'" name="order_ed_quantity_req[]"  onblur=\'update_prod_details("'+i+'","'+products_added_fynl_array[i].product_code+'");\''+
                                        'value="'+products_added_fynl_array[i].product_quantity+'" placeholder="Enter Brand Name">'+
                                        '</div>');
                    $('.order_prod_price').last().append('<div class="col-sm-12">'+
                                        '<input class="form-control numbersOnly" id="product_price'+i+'" name="order_ed_price_pt_req[]" onblur=\'update_prod_details("'+i+'","'+products_added_fynl_array[i].product_code+'");\''+
                                        ' value="'+products_added_fynl_array[i].product_price+'" placeholder="Enter Brand Name">'+
                                       '</div>');
                    $('.order_prod_total').last().append('<div class="col-sm-12">'+
                                        '<input class="form-control order_ed_total_price" name="order_ed_total_price_req[]" readonly style="border:none" value="'+products_added_fynl_array[i].product_total_price+'" placeholder="Enter Brand Name">'+
                                        '</div>');                
                    $('.order_prod_remove').last().append('<div class="col-sm-12">'+
                                        '<span class="removeproducts" onclick=\'remove_products("'+i+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div>');
                }
                else if (products_added_fynl_array[i]["product_type"]=='Requestproduct') 
                {
                    requested_prod_bag_total+= parseFloat(products_added_fynl_array[i]["product_price"]).toFixed(2)  * parseFloat(products_added_fynl_array[i]["product_quantity"]).toFixed(2);

                    $('.order_prod_img').last().append(products_added_fynl_array[i].produ_imgurl);
                    $('.order_prod_name').last().append(''+products_added_fynl_array[i].prod_name+' ( '+products_added_fynl_array[i].product_weight+' '+products_added_fynl_array[i].unit_id+' )');

                    $('.order_prod_qty').last().append('<div class="col-sm-12">'+
                                        '<input class="form-control numbersOnly" id="product_quantity'+i+'" name="order_ed_quantity_req[]"  onblur=\'update_prod_details("'+i+'","'+products_added_fynl_array[i].product_code+'");\''+
                                        'value="'+products_added_fynl_array[i].product_quantity+'" placeholder="Enter Brand Name">'+
                                        '</div>');
                    $('.order_prod_price').last().append('<div class="col-sm-12">'+
                                        '<input class="form-control numbersOnly" id="product_price'+i+'" name="order_ed_price_pt_req[]" onblur=\'update_prod_details("'+i+'","'+products_added_fynl_array[i].product_code+'");\''+
                                        ' value="'+products_added_fynl_array[i].product_price+'" placeholder="Enter Brand Name">'+
                                       '</div>');
                    $('.order_prod_total').last().append('<div class="col-sm-12">'+
                                        '<input class="form-control order_ed_total_price" name="order_ed_total_price_req[]" readonly style="border:none" value="'+products_added_fynl_array[i].product_total_price+'" placeholder="Enter Brand Name">'+
                                        '</div>');
                    $('.order_prod_remove').last().append('<div class="col-sm-12">'+
                                        '<span class="removeproducts" onclick=\'remove_products("'+i+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div>');
                }
                else if (products_added_fynl_array[i]["product_type"]=='slot_prod') 
                {
                    slot_prod_bag_total+= parseFloat(products_added_fynl_array[i]["product_price"]).toFixed(2)  * parseFloat(products_added_fynl_array[i]["product_quantity"]).toFixed(2);

                    $('.order_prod_img').last().append('<div  style="display: inline-flex;"> <img src="'+products_added_fynl_array[i].slot_prod1+'" alt="product-img" height="52">'+
                            '<img src="'+products_added_fynl_array[i].slot_prod2+'" alt="product-img" height="52">'+
                            '<img src="'+products_added_fynl_array[i].slot_prod3+'" alt="product-img" height="52"></div>');

                    $('.order_prod_name').last().append('<p>'+products_added_fynl_array[i].slot_prod_detail1+'</p>'+
                            '<p>'+products_added_fynl_array[i].slot_prod_detail2+'</p>'+
                            '<p>'+products_added_fynl_array[i].slot_prod_detail3+'</p>');

                    $('.order_prod_qty').last().append('<div class="col-sm-12">'+
                                        '<input readonly class="form-control numbersOnly" style="border:none" id="product_quantity'+i+'" name="order_ed_quantity_req[]"  onblur=\'update_prod_details("'+i+'","'+products_added_fynl_array[i].product_code+'");\''+
                                        'value="'+products_added_fynl_array[i].product_quantity+'" placeholder="Enter Brand Name">'+
                                        '</div>');
                    $('.order_prod_price').last().append('<div class="col-sm-12">'+
                                        '<input readonly class="form-control numbersOnly" style="border:none" id="product_price'+i+'" name="order_ed_price_pt_req[]" onblur=\'update_prod_details("'+i+'","'+products_added_fynl_array[i].product_code+'");\''+
                                        ' value="'+products_added_fynl_array[i].product_price+'" placeholder="Enter Brand Name">'+
                                       '</div>');
                    $('.order_prod_total').last().append('<div class="col-sm-12">'+
                                        '<input class="form-control order_ed_total_price" name="order_ed_total_price_req[]" readonly style="border:none" value="'+products_added_fynl_array[i].product_total_price+'" placeholder="Enter Brand Name">'+
                                        '</div>');
                    $('.order_prod_remove').last().append('<div class="col-sm-12">'+
                                        '<span class="removeproducts" onclick=\'remove_products("'+i+'");\'><i class="fa fa-times-circle-o" aria-hidden="true"></i> remove</span>'+
                                        '</div>');
                }
            }

            if (orderJSON[0]["promocode_id"]!='0' && orderJSON[0]["promocode_id"]!=null && orderJSON[0]["promocode_id"]!=0.00) 
            {
                order_promo_discount = orderJSON[0]["promocode_price"];
                $('.promocode_display').show();
            }
            else
            {
                $('.promocode_display').hide();
                order_promo_discount=0;
            }

            if (orderJSON[0]["price_range_discount"]!='0' && orderJSON[0]["price_range_discount"]!=null && orderJSON[0]["price_range_discount"]!=0.00) 
            {
                order_price_range_discount = orderJSON[0]["price_range_discount"];
                $('.pricerange_display').show();
            }
            else
            {
                $('.pricerange_display').hide();
                order_price_range_discount=0;
            }


            setTimeout(function()
            {
                prod_bag_total = parseFloat((requested_prod_bag_total).toFixed(2)) + parseFloat((avaliable_prod_bag_total).toFixed(2)) + parseFloat((slot_prod_bag_total).toFixed(2));
                prod_bag_sub_total = parseFloat((prod_bag_sub_total).toFixed(2)) + parseFloat((requested_prod_bag_total).toFixed(2)) + parseFloat((slot_prod_bag_total).toFixed(2));

                prod_discount =  parseFloat((prod_bag_sub_total).toFixed(2)) - parseFloat((prod_bag_total).toFixed(2));

                prod_bag_total = parseFloat(prod_bag_sub_total).toFixed(2) - parseFloat(prod_discount).toFixed(2) - 
                parseFloat(order_promo_discount).toFixed(2) - parseFloat(order_price_range_discount).toFixed(2);

                $('#order_sub_total').val(parseFloat(prod_bag_sub_total).toFixed(2));
                $('#order_discount').val(parseFloat(prod_discount).toFixed(2));
                $('#order_total').val(parseFloat(prod_bag_total).toFixed(2));
                $('#order_promo_discount').val(parseFloat(order_promo_discount).toFixed(2));
                $('#order_price_range_discount').val(parseFloat(order_price_range_discount).toFixed(2));
            }, 100);
        }

        update_prod_details = function(selected_index , product_code)
        {
            // console.log(selected_index);

            var product_quantity = 0;
            var product_price = 0.00;
            if ($('#product_quantity'+selected_index+'').val()!='') 
            {
                product_quantity =  $('#product_quantity'+selected_index+'').val();
            }

            if ($('#product_price'+selected_index+'').val()!='') 
            {
                product_price =  $('#product_price'+selected_index+'').val();
            }

            var sub_total = 0;
            sub_total = product_price *product_quantity;
            sub_total = sub_total.toFixed(2);

            for (var i = 0; i < products_added_fynl_array.length; i++) 
            {
                if (""+i+""==""+selected_index+"") 
                {
                    products_added_fynl_array[i]["product_quantity"] = product_quantity;
                    products_added_fynl_array[i]["product_price"] = parseFloat(product_price).toFixed(2);
                    products_added_fynl_array[i]["product_total_price"] = parseFloat(sub_total).toFixed(2);
                }
            }
            appendproducts();
        }

        remove_products  = function(selected_index)
        {
            for (var i = 0; i < products_added_fynl_array.length; i++) 
            {
                if (""+i+""==""+selected_index+"") 
                {
                    products_added_fynl_array. splice(i, 1);
                }
            }
            var products_added_fynl_array_re = products_added_fynl_array.filter(function(){return true;});
            products_added_fynl_array=[];
            products_added_fynl_array=products_added_fynl_array_re;

            // console.log(products_added_fynl_array);
            appendproducts();
        }

        $(document).on('keypress keyup', '#order_discount', function() 
        {
            if ($('#order_discount').val()=='') 
            {
                $('#order_discount').val(0.00);
            }
            var sub_total = 0;
            var order_sub_total = $('#order_sub_total').val();
            var order_discount = $('#order_discount').val();

            if (parseFloat(order_sub_total) > parseFloat(order_discount)) 
            {
                sub_total = order_sub_total - order_discount;    
            }

            // $('#order_discount').val(order_discount.toFixed(2));
            $('#order_total').val(sub_total.toFixed(2));
        });

// ==================================================================================================================//

    // Product Toggel function

        function toggleElements()
        {
            $( "#product_type" ).trigger( "change" );        
        }

        $(document).on('change', "#product_type", function() 
        {
            if ($(this).val()=="Avaliableproduct") 
            {
                var $select = $('#product_code').selectize();
                var control = $select[0].selectize;
                control.clear();
                $('.Avaliableproductshow').show();
                $('.productdetails_show').show();
                $('.Requestproductshow').hide();
                $('#product_code').val('');
                $('#product_code_req').val('');
                $('#unit_id').val('');
                $('#product_weight').val('');
                $('#product_quantity').val('');
                $('#product_id').val('');
                $('#produ_imgurl').val('');
                $('#original_amt').val('');
                $('#prod_name').val('');
                $('#product_price').val('0.00');
                $('#product_total_price').val('0.00');

            }
            else if ($(this).val()=="Requestproduct") 
            {
                var $select = $('#product_code').selectize();
                var control = $select[0].selectize;
                control.clear();
                $('.Requestproductshow').show();
                $('.productdetails_show').show();
                $('.Avaliableproductshow').hide();
                $('#product_code').val('');
                $('#product_code_req').val('');
                $('#unit_id').val('');
                $('#product_weight').val('');
                $('#product_quantity').val('');
                $('#product_id').val('');
                $('#produ_imgurl').val('');
                $('#original_amt').val('');
                $('#prod_name').val('');
                $('#product_price').val('0.00');
                $('#product_total_price').val('0.00');
            }
            else
            {
                var $select = $('#product_code').selectize();
                var control = $select[0].selectize;
                control.clear();
                $('.Requestproductshow').hide();
                $('.Avaliableproductshow').hide();
                $('.productdetails_show').hide();
                $('#product_code').val('');
                $('#product_code_req').val('');
                $('#unit_id').val('');
                $('#product_weight').val('');
                $('#product_quantity').val('');
                $('#product_price').val('');
                $('#product_total_price').val('');
                $('#product_id').val('');
                $('#produ_imgurl').val('');
                $('#original_amt').val('');
                $('#prod_name').val('');
            }
        });


// ==================================================================================================================//

    // Get Product Details

        $(document).on('change', "#product_code", function() 
        {
            // console.log($(this).val());
            var prod_code = $(this).val();

            if (prod_code!='') 
            {
                return $.ajax({
                    url: base_URL+'ThirdAxisCon/getproductssforeditid',
                    type:'POST',
                    data: {"prod_code":prod_code},
                    success:function(data){
                        var productdetailsofid = $.parseJSON(data);                       
                        $('#product_weight').val(productdetailsofid[0]["prod_quantity"]);
                        $('#unit_id').val(productdetailsofid[0]["unit_id"]);
                        $('#product_price').val(productdetailsofid[0]["selling_price"]);
                        $('#product_quantity').val('1');
                        $('#product_id').val(productdetailsofid[0]["prod_id"]);
                        $('#produ_imgurl').val(productdetailsofid[0]["produ_imgurl"]);
                        $('#original_amt').val(productdetailsofid[0]["original_amt"]);
                        $('#prod_name').val(productdetailsofid[0]["prod_name"]);
                        doaddprodtotalcalc();
                    },      
                    error: function() {
                        console.log("Error"); 
                        //alert('something bad happened'); 
                    }
                }) ;
            }
        });

// ==================================================================================================================//

    // Get User Address Details

        $(document).on('change', "#user_unique_id", function() 
        {
            // console.log($(this).val());
            var user_unique_id = $(this).val();

            if (user_unique_id!='') 
            {
                return $.ajax({
                    url: base_URL+'ThirdAxisCon/getuseraddressdetails',
                    type:'POST',
                    data: {"user_unique_id":user_unique_id},
                    success:function(data){
                        Addressjson = $.parseJSON(data);  
                        yb_user_address=[]; 
                        if (Addressjson.length>0) 
                        { 
                            yb_user_address.push(Addressjson[0]); 
                        }                            
                        append_address_function(); 
                    },      
                    error: function() {
                        console.log("Error"); 
                        //alert('something bad happened'); 
                    }
                }) ;
            }
        });
        

        function append_address_function() 
        {
            $('.display_address_info').html('');
            if (Addressjson.length>0) 
            {                
                $('.display_address_info').append('<label for="fname" class="col-12 text-left control-label col-form-label" >Customer Address</label><br>'+
                '<div class="col-8 ml-3"> <p class="p-0 m-0"><b>'+yb_user_address[0]["username"]+'</b></p>'+
                '<p class="p-0 m-0">'+yb_user_address[0]["flat_no"]+', '+yb_user_address[0]["building_name"]+' '+
                ''+yb_user_address[0]["landmark"]+', '+yb_user_address[0]["area"]+' ,'+
                ''+yb_user_address[0]["city"]+'</p> <p> +971 '+yb_user_address[0]["mobile_no"]+'</p></div>'+
                '<div class="col-3"> <input type="hidden"  id="fynl_address_id" class="fynl_address_id" value="'+yb_user_address[0]["address_id"]+'">'+
                ' <a class="btn BtnEdit mt-3 ml-2" style="padding:0px; color:red" role="button" ><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Change</a></div>');

                $('.user_unique_id_address').hide();
            }                                  
            else
            {
                $('.display_address_info').append('<p class="error_custom user_unique_id_address">* Please Add the address to continue next</p>');
                $('.user_unique_id_address').show();
            } 
        }

        $(document).on('click', ".BtnEdit", function() 
        {
            var fynl_address_id = $('#fynl_address_id').val();

            // $('#largeModal').modal('show');
                $('#largeModal').modal({
                      backdrop: 'static',
                     keyboard: false  // to prevent closing with Esc button (if you want this too)
                })

            $('.Address_list_append_loop').html('');
            for (var i = 0; i < Addressjson.length; i++) 
            {
                $('.Address_list_append_loop').append(''+
                    '<div class="col-8">'+
                    '  <input type="radio" id="address_id'+Addressjson[i]["address_id"]+'" name="address_id" value="'+i+'">'+
                       '<label class="address_lable" for="address_id'+Addressjson[i]["address_id"]+'">'+
                         '<p class="p-0 m-0"><b>'+Addressjson[i]["username"]+'</b></p>'+
                        '<p class="p-0 m-0">'+Addressjson[i]["flat_no"]+', '+Addressjson[i]["building_name"]+' '+
                        ''+Addressjson[i]["landmark"]+', <br>'+Addressjson[i]["area"]+' ,'+
                        ''+Addressjson[i]["city"]+'</p> <p> +971 '+Addressjson[i]["mobile_no"]+'</p>'+
                       '</label>'+
                    '</div>');

            }
            $("#address_id"+fynl_address_id+"").prop( "checked", true );

            // <div class="mb-8">
                
                
            // </div>

        });

        $(document).on('click', "#Submit_address", function() 
        {
            var selected_address_val = $('input[name="address_id"]:checked').val();

            for (var i = 0; i < Addressjson.length; i++) 
            {
                if (i==selected_address_val) 
                {
                    yb_user_address=[]; 
                    yb_user_address.push(Addressjson[i]); 
                    append_address_function();
                }
            }
            $('#largeModal').modal('hide');

        });


// ==================================================================================================================//

    // Do Total calculation 

        $(document).on('keypress keyup', '#product_quantity', function() 
        {
            if ($('#product_price').val()=='') 
            {
                $('#product_price').val(0);
                doaddprodtotalcalc();
            }
            else
            {
                doaddprodtotalcalc();
            }
        });

        $(document).on('keypress keyup', '#product_price', function() 
        {
            if ($('#product_price').val()=='') 
            {
                $('#product_price').val(0);
                doaddprodtotalcalc();
            }
            else
            {
                doaddprodtotalcalc();
            }
        });

        function doaddprodtotalcalc() {
            var sub_total = 0;
            var product_price = $('#product_price').val();
            var product_quantity = $('#product_quantity').val();
            sub_total = product_price *product_quantity;
            $('#product_total_price').val(sub_total.toFixed(2));
        }

// ==================================================================================================================//

    // Product submit function

        $(document).on('click', "#addproductsbtnn", function() 
        {
            $('.error').hide();
            if($('#product_type').val()=='')
            {
                $('.product_type').html('product type cannot be empty')
                $('.product_type').show();
            }
            else if($('#product_type').val()=='Avaliableproduct' && $('#product_code').val()=='')
            {
                $('.product_code').html('product code cannot be empty')
                $('.product_code').show();
            }
            else if($('#product_type').val()=='Requestproduct' && $('#product_code_req').val()=='')
            {
                $('.product_code_req').html('product name cannot be empty')
                $('.product_code_req').show();
            }
            else if($('#unit_id').val()=='' || $('#unit_id').val()==null)
            {
                $('.unit_id').html('unit type cannot be empty')
                $('.unit_id').show();
            }
            else if($('#product_weight').val()=='')
            {
                $('.product_weight').html('product weight cannot be empty')
                $('.product_weight').show();
            }
            else if($('#product_quantity').val()=='')
            {
                $('.product_quantity').html('product quantity cannot be empty')
                $('.product_quantity').show();
            }
            else if($('#product_price').val()=='')
            {
                $('.product_price').html('product price cannot be empty')
                $('.product_price').show();
            }
            else if($('#product_total_price').val()=='')
            {
                $('.product_total_price').html('product total_price cannot be empty')
                $('.product_total_price').show();
            }
            else
            {
                if ($('#product_type').val()=='Requestproduct') 
                {
                    
                    var prod_add_array = 
                    [
                        { 
                             "product_type": ""+$('#product_type').val()+"",
                             "product_id": "0",
                             "product_code": "0",
                             "product_code_req": ""+$('#product_code_req').val()+"",
                             "unit_id": ""+$('#unit_id').val()+"",
                             "product_weight": ""+$('#product_weight').val()+"",
                             "product_quantity": ""+$('#product_quantity').val()+"",
                             "product_price": ""+$('#product_price').val()+"",
                             "produ_imgurl": "Requested product",
                             "original_amt": ""+$('#product_price').val()+"",
                             "product_total_price": ""+$('#product_total_price').val()+"",
                             "prod_name": ""+$('#product_code_req').val()+""
                        }
                    ];
                    var n = products_req_code.includes($('#product_code_req').val());
                    if (n==true) 
                    {
                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Product already added',
                            type: 'blue',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                    }
                    else
                    {
                        products_added_fynl_array.push(prod_add_array[0]);
                        products_req_code.push($('#product_code_req').val());
                    }

                }
                if ($('#product_type').val()=='Avaliableproduct') 
                {
                    var prod_add_array = 
                    [
                        { 
                             "product_type": ""+$('#product_type').val()+"",
                             "product_id": ""+$('#product_id').val()+"",
                             "product_code": ""+$('#product_code').val()+"",
                             "product_code_req": ""+$('#product_code_req').val()+"",
                             "unit_id": ""+$('#unit_id').val()+"",
                             "product_weight": ""+$('#product_weight').val()+"",
                             "product_quantity": ""+$('#product_quantity').val()+"",
                             "product_price": ""+$('#product_price').val()+"",
                             "produ_imgurl": ""+$('#produ_imgurl').val()+"",
                             "original_amt": ""+$('#original_amt').val()+"",
                             "product_total_price": ""+$('#product_total_price').val()+"",
                             "prod_name": ""+$('#prod_name').val()+""
                        }
                    ];

                    var n = products_aval_code.includes($('#product_code').val());
                    if (n==true) 
                    {
                        $.confirm({
                            icon: 'icon-close',
                            title: 'Info',
                            content: 'Product already added',
                            type: 'blue',
                            buttons: {
                                Ok: function() {},
                            }
                        });
                    }
                    else
                    {
                        products_added_fynl_array.push(prod_add_array[0]);
                        products_aval_code.push($('#product_code').val());
                    }

                }
            
                toggleElements();
                appendproducts();
                // console.log(products_added_fynl_array);
            } 
        });
        
// ==================================================================================================================//

    // Product submit function

        $(document).on('click', "#submit_fynl_order", function() 
        {
            $('.error').hide();
            // if($('#user_unique_id').val()=='')
            // {
            //     $('.user_unique_id').html('* Select User to assign order')
            //     $('.user_unique_id').show();
            // }
            if($('.delivery_date').val()=='')
            {
                $('.delivery_date_form').html('* Select Delivery  Date')
                $('.delivery_date_form').show();
            }
            else if(yb_user_address.length==0)
            {
                $('.common_error_fn').html('* Please Add or Select the Address')
                $('.common_error_fn').show();
            }
            else if(products_added_fynl_array.length==0)
            {
                $('.common_error_fn').html('* Please Add the Products to submit order')
                $('.common_error_fn').show();
            }
            else
            {
                return $.ajax({
                    url: base_URL+'ThirdAxisCon/updateneworder',
                    type:'POST',
                    data: {"yb_user_address":yb_user_address,"products_added_fynl_array":products_added_fynl_array,
                    "user_unique_id":$('#user_unique_id').val(), "order_sub_total":$('#order_sub_total').val(), 
                    "order_discount":$('#order_discount').val(), "order_total":$('#order_total').val(), "delivery_date":$('.delivery_date').val(), 
                    "order_no":lastSegment,"order_promo_discount":$('#order_promo_discount').val(),"order_price_range_discount":$('#order_price_range_discount').val()},
                    success:function(data)
                    {       
                        var js = $.parseJSON(data);
                        var status = js.status;
                        var message = js.msg;

                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: ''+message+'',
                                type: 'green',
                                buttons: {
                                    Ok: function() {
                                        window.location.replace(''+base_URL+'/ThirdAxisCon/orderconfirm');
                                    },
                                }
                            });
                        } 
                        else if (status == "fail") {

                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: ''+message+'',
                                type: 'red',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                        } 

                    },      
                    error: function() {
                        console.log("Error"); 
                        //alert('something bad happened'); 
                    }
                }) ;
            }
        });



        $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});