$(document).ready(function() {

    var NotificationJSON, notification_id, mode;
    $.when(getnotificationlist()).done(function() {
        dispArealist(NotificationJSON);
    });

    function getnotificationlist() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getnotificationlist',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                NotificationJSON = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    function dispArealist(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": "notification_message"
                },{
                    "mDataProp": function(data, type, full, meta) {
                        if (data.view_flag == 0)
                            return '<a id="' + meta.row + '" class="btn Btnhidden show_notifications" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  Read</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore show_notifications" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Unread</a>&nbsp;&nbsp;';

                    }
                }
            ]
        });
    }

    $(document).on('click', '.show_notifications', function() {
        $('#notificationmodelmsgmodel').modal('show');
        $('#notificationcontentmodalmsg').html('');
        var dispbtmcontyt='';


        var r_index = $(this).attr('id');
        var search_key = NotificationJSON[r_index].search_key;
        var notification_message = NotificationJSON[r_index].notification_message;
        var notification_type = NotificationJSON[r_index].notification_type;

        if(notification_type=='products')
        {
            dispbtmcontyt = "<br><br><a href='"+base_URL+"ThirdAxisCon/searchproductkey/"+search_key+"/findproduct' > Click to add <b style='text-decoration: underline;'> "+search_key+"</b> to product list </a> ";
            $('#notificationcontentmodalmsg').append(notification_message+''+dispbtmcontyt);
        }
        if(notification_type=='orders')
        {
            dispbtmcontyt = "<br><br><a href='"+base_URL+"ThirdAxisCon/orderconfirm'> View Order</a>";
            $('#notificationcontentmodalmsg').append(notification_message+''+dispbtmcontyt);
        }
        if(notification_type=='coupon')
        {
            $('#notificationcontentmodalmsg').append(notification_message);
        }
        if(notification_type=='requested_prod')
        {
            $('#notificationcontentmodalmsg').append(notification_message);
        }

        

        var notification_id = NotificationJSON[r_index].notification_id;
        
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/updatenotificationviewflag',
            data: {
                "notification_id": notification_id
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result

            refreshDetails();
        });
 

    });




    function refreshDetails() {
        $.when(getnotificationlist()).done(function() {
            var table = $('#Main_Category').DataTable();
            table.destroy();
            dispArealist(NotificationJSON);
        });
    }


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});