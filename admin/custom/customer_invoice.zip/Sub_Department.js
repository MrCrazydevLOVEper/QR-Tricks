$(document).ready(function() {
			
	var SubDepartmentJSON,sd_code,mode;
	$.when(getMainCategory()).done(function(){
			dispMainCategory(SubDepartmentJSON);				
	});

	function getMainCategory()
	{
		return $.ajax({
			url: base_URL+'/ThirdAxisCon/SubDepartmentView',
			type:'POST',
			success:function(data){
				//console.log(data);
				SubDepartmentJSON = $.parseJSON(data);
				
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;
	}


	function dispMainCategory(JSON)
	{	
		//$('#success_alert').show(1000);
		//console.log(dataJSON);
		 var i =1;
		$('#Main_Category').dataTable( {
			"aaSorting":[],
			"aaData": JSON,
			responsive: true,
			"aoColumns": [
					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                            return ''+data.mdName+' ( '+data.md_code+' )';
                    }
                },
				{ "mDataProp": "sd_code" },
				{ 
					"mDataProp": "sdName"
				},				
				{ "mDataProp": "sdSeoTitle" },
				{ "mDataProp": "sdSeokeyword" },
				{ "mDataProp": "sdSeoDes" },	
				{
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  visible</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Hidden</a>&nbsp;&nbsp;';;

                    }
                },
				{
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },			
			]  				
		});
	}
	
	$('#New_Category').click(function(){
		mode="new";
		// $('#largeModal').modal('show');
		$('#largeModal').modal({
	          backdrop: 'static',
    		 keyboard: false  // to prevent closing with Esc button (if you want this too)
	    })		

	});
	
	$(document).on('click','.BtnEdit',function(){
		mode="update";
		var r_index = $(this).attr('id');
		sd_code = SubDepartmentJSON[r_index].sd_code;
		$('#largeModal').modal('show');
		$('#sdName').val(SubDepartmentJSON[r_index].sdName);
		$('#md_code').val(SubDepartmentJSON[r_index].md_code);
		// selectize.setValue("Fresh daily food ( 10 )");


		//$('.Scategory').val(SubDepartmentJSON[r_index].Scategory);
		$('#url').val(SubDepartmentJSON[r_index].url);
		$('#sdSeoTitle').val(SubDepartmentJSON[r_index].sdSeoTitle);
		$('#sdSeokeyword').val(SubDepartmentJSON[r_index].sdSeokeyword);
		$('#sdSeoDes').val(SubDepartmentJSON[r_index].sdSeoDes);		
		if(SubDepartmentJSON[r_index].Scategory==1)
		{
			$('#hide').attr('checked', false);
			$('#show').attr('checked', true);
			$('.no').show();
		}
		else if(SubDepartmentJSON[r_index].Scategory==0)
		{
			$('#hide').attr('checked', true);
			$('#show').attr('checked', false);
			$('.no').hide();
		}

		var $select = $(document.getElementById("md_code"));
		var selectize = $select[0].selectize;
		selectize.setValue(SubDepartmentJSON[r_index].md_code);

	});
	
	$(document).on('click','.BtnDelete',function(){
		mode="delete";
		var r_index = $(this).attr('id');
		sd_code = SubDepartmentJSON[r_index].sd_code;
		
		$.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Are you Sure Do you want to Delete this Data',
                type: 'blue',
					buttons: {
						Yes: function() {					
								request = $.ajax({
									type: "POST",
									url: base_URL+'ThirdAxisCon/DeleteSubDepartmentData',
									data: {"sd_code":sd_code},
								});	
								request.done(function (response){
									var js = $.parseJSON(response);
									var status = js.result
									if (status == "success") {
										$.confirm({
											icon: 'icon-close',
											title: 'Info',
											content: 'Deleted Succesfully',
											type: 'green',
												buttons: {
													Ok: function() {},
												}
										});
										refreshDetails();
									}
									else
									{
										$.confirm({
											icon: 'icon-close',
											title: 'Info',
											content: 'Are you Sure Do you want to Delete this Data',
											type: 'blue',
												buttons: {
													No: function() {},
												}
										});
									}
							
								});	
						},
						No: function() {},
					}
            });	
	});
	


    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        sd_code = SubDepartmentJSON[r_index].sd_code;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreSubDepartmentData(sd_code,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        sd_code = SubDepartmentJSON[r_index].sd_code;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreSubDepartmentData(sd_code,flag);
                },
                No: function() {},
            }
        });

    });


    function RestoreSubDepartmentData(sd_code,flag)
    {
    	var sd_code = sd_code;
    	var flag = flag;

        request = $.ajax({
                type: "POST",
                url: base_URL+'ThirdAxisCon/RestoreSubDepartmentData',
                data: {"sd_code":sd_code,"flag":flag},
        }); 
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }

	
	$('#Sub_Department_Button').click(function(){
		$('.error').hide();
		//console.log($('#url').val()); 
		if($('#md_code').val()=="")
		{
			$('.md_code').html("* Please Fill Main Department");
			$('.md_code').show();
		}
		else if($('#sdName').val()=="")
		{
			$('.sdName').html("* Please Fill Sub Department");
			$('.sdName').show();
		}
		else
		{
			if(mode=="new")
			{
				saveMainCategory();
			}
			else
			{
				updateMainCategory();
			}			
			
		}		
	});
	
	$('#largeModal').on('show.bs.modal', function () {
		$(".no").hide();
		$('#hide').attr('checked', false);
		$('#show').attr('checked', false);
	    $(this).find('form').trigger('reset');
		 var $select = $('#md_code').selectize();
		 var control = $select[0].selectize;
		 control.clear();
	});	
	
	function saveMainCategory()
	{	
//alert(12);	
		var form = $('#Sub_Department_Form')[0];
		var data = new FormData(form);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/insertSubDepartmentData',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			//console.log(js);
			var status = js.result;
			console.log(status);
			if (status == "success") {
							$.confirm({
								icon: 'icon-close',
								title: 'Info',
								content: 'Inserted Sucessfully',
								type: 'green',
									buttons: {
										Ok: function() {},
									}
							});
				$('#largeModal').modal('hide');
				refreshDetails();
				//alert(12);
			}
			else
			{
				$.confirm({
							icon: 'icon-close',
							title: 'Info',
							content: 'Sorry Something went worng',
							type: 'red',
								buttons: {
									Ok: function() {},
								}
						});
			}
			// $('.alert-success').show().delay(5000).fadeOut('slow');				
			// refreshDetails();		
		});		
	}
	
	function refreshDetails()
	{
		$.when(getMainCategory()).done(function(){
			var table = $('#Main_Category').DataTable();
			table.destroy();	
			dispMainCategory(SubDepartmentJSON);				
		});		
	}
	
	function updateMainCategory()
	{
		var form = $('#Sub_Department_Form')[0];
		var data = new FormData(form);
		data.append("sd_code",sd_code);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/updateSubDepartmentData',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);			
			var status = js.result;
			if (status == "success") {
						$.confirm({
							icon: 'icon-close',
							title: 'Info',
							content: 'Updated Sucessfully',
							type: 'green',
								buttons: {
									Ok: function() {},
								}
						});
				$('#largeModal').modal('hide');
				refreshDetails();
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}
			//console.log(js);
			// $('#largeModal').modal('hide');
			// $('.alert-success').show().delay(5000).fadeOut('slow');				
			// refreshDetails();		
		});			
	}
        	  $(document)
              .ajaxStart(function () {
                $(".loading").show();
              })
              .ajaxStop(function () {
                $(".loading").hide();
              });

});
