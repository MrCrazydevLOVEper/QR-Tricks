$(document).ready(function() {

    var SlotcomboJSON,slot_combo_id,slot_setting_id,mode;

    $.when(getslotlogiclsetting()).done(function() {
    });

    $('#showifdeactivated').hide();
    $('#showifactivated').hide();

    function getslotlogiclsetting() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getslotlogiclsetting',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                SlotcomboJSON = $.parseJSON(data);

                if (SlotcomboJSON.length>0) 
                {
                    $('#last_purchase').val(SlotcomboJSON[0]["last_purchase"]);
                    $('#last_purchase_avg').val(SlotcomboJSON[0]["last_purchase_avg"]);
                    $('#last_highest_redeem').val(SlotcomboJSON[0]["last_highest_redeem"]);
                    $('#last_redeem_high_medium').val(SlotcomboJSON[0]["last_redeem_high_medium"]);
                    $('#last_medium_redeem').val(SlotcomboJSON[0]["last_medium_redeem"]);
                    $('#no_of_purchase').val(SlotcomboJSON[0]["no_of_purchase"]);
                    $('#last_redeem_high_medium_second').val(SlotcomboJSON[0]["last_redeem_high_medium_second"]);
                    $('#no_of_spin').val(SlotcomboJSON[0]["no_of_spin"]);
                    $('#slot_setting_id').val(SlotcomboJSON[0]["slot_setting_id"]);
                    $('#previous_purchase').val(SlotcomboJSON[0]["previous_purchase"]);
                    slot_setting_id = SlotcomboJSON[0]["slot_setting_id"];

                    if (SlotcomboJSON[0]["previous_purchase_flag"]==0) 
                    {
                        $('#showifdeactivated').show();
                        $('#showifactivated').hide();
                    }
                    if (SlotcomboJSON[0]["previous_purchase_flag"]==1) 
                    {
                        $('#showifdeactivated').hide();
                        $('#showifactivated').show();
                    }

                }

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    $('#updateslotloginbtn').click(function() {

        if ($('#last_purchase').val() != "" && $('#last_purchase_avg').val() != "" && $('#last_highest_redeem').val() != "" && 
            $('#last_redeem_high_medium').val() != "" && $('#last_medium_redeem').val() != "" && $('#no_of_purchase').val() != "" && 
            $('#last_redeem_high_medium_second').val() != "" && $('#no_of_spin').val() != "" ) 
        {
            insertslotsettingdetails();
        } 
        else 
        {
           alert('please enter all the values');

        }
    });

    function insertslotsettingdetails() {
        var form = $('#formdatadetails')[0];
        var data = new FormData(form);
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/insertslotsettingdetails',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
            } else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }
        });
    }

    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });


    $('#formdatadetailsslotsubmit').click(function() {
        $('.error').hide();
        if ($('#previous_purchase').val() != "") 
        {
            var form = $('#formdatadetailsslot')[0];
            var data = new FormData(form);
            data.append("slot_setting_id",slot_setting_id);
            request = $.ajax({
                type: "POST",
                enctype: 'multipart/form-data',
                url: base_URL + 'ThirdAxisCon/insertslotsettingdetails',
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                timeout: 600000,
            });
            request.done(function(response) {
                var js = $.parseJSON(response);
                var status = js.result;
                if (status == "success") {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Updated Sucessfully',
                        type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                } else {

                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Sorry Something went worng',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                }
            });
        } 
        else 
        {
            $('.previous_purchase').html("* please enter the value");
            $('.previous_purchase').show();

        }
    });


    $('.activatebtn').click(function() {
        return $.ajax({
            url: base_URL+'ThirdAxisCon/insertslotsettingdetails',
            type:'POST',
            data: {
                "slot_setting_id":slot_setting_id,"previous_purchase_flag":"1"
            },
            success:function(data){
                var js = $.parseJSON(data);
                var status = js.result;
                if (status == "success") {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Updated Sucessfully',
                        type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                    getslotlogiclsetting()
                } else {

                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Sorry Something went worng',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                } 
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ; 
    });

    $('.deactivatebtn').click(function() {
       return $.ajax({
            url: base_URL+'ThirdAxisCon/insertslotsettingdetails',
            type:'POST',
            data: {
                "slot_setting_id":slot_setting_id,"previous_purchase_flag":"0"
            },
            success:function(data){
                var js = $.parseJSON(data);
                var status = js.result;
                if (status == "success") {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Updated Sucessfully',
                        type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                    getslotlogiclsetting()
                } else {

                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Sorry Something went worng',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                }   
            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;
    });







});