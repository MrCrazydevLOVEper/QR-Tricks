$(document).ready(function() {

    var ReportDetailsJSON, area_master_id, mode;
    $.when(getreportdetails()).done(function() {
        dispDetailslist(ReportDetailsJSON);
    });

    function getreportdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/yalladatewiseprocurmentreport',
            type: 'POST',
            success: function(data) 
            {
                ReportDetailsJSON = $.parseJSON(data);
            },
            error: function() 
            {
                console.log("Error");
            }
        });
    }


    function dispDetailslist(JSON) 
    {
        var i =1;
        $('#yalla_cpurchase_report').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: 'Datewise Procurement Report',
                    text: "Export as Excel",
                     exportOptions: {
                        message: "Datewise Procurement Report",
                        columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                    },
                },            
            ],
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.purchase_date==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.purchase_date;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.purchase_prod_code==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.purchase_prod_code;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.purchase_product==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.purchase_product;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.purchase_product_type=="Requestproduct") 
                        {
                            return '';
                        }
                        else
                        {
                            return data.mdName;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.purchase_product_type=="Requestproduct") 
                        {
                            return '';
                        }
                        else
                        {
                            return data.sdName;   
                        }                         
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.purchase_product_type=="Requestproduct") 
                        {
                            return '';
                        }
                        else
                        {
                            return data.mcName;   
                        }                         
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.purchase_product_type=="Requestproduct") 
                        {
                            return '';
                        }
                        else
                        {
                            return data.scName;   
                        }  
                    }
                },  { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.purchase_product_quantity==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.purchase_product_quantity +' '+ data.purchase_product_unit;   
                        }  
                    }
                },  { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.total_product_price==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.total_product_price;   
                        }  
                    }
                },  { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.created_by==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.created_by;   
                        }  
                    }
                },  { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.vendor_name==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.vendor_name;   
                        }  
                    }
                }, 
            ]
        });
    }

    function refreshDetails() {
        $.when(getreportdetails()).done(function() {
            var table = $('#yalla_cpurchase_report').DataTable();
            table.destroy();
            dispDetailslist(ReportDetailsJSON);
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});