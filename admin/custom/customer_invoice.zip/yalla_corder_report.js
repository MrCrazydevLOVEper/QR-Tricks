$(document).ready(function() {

    var ReportDetailsJSON, area_master_id, mode;
    $.when(getreportdetails()).done(function() {
        dispDetailslist(ReportDetailsJSON);
    });

    function getreportdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/customerorderreport',
            type: 'POST',
            success: function(data) 
            {
                ReportDetailsJSON = $.parseJSON(data);
            },
            error: function() 
            {
                console.log("Error");
            }
        });
    }

    function dispDetailslist(JSON) 
    {
        var i =1;
        $('#yalla_corder_report').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: 'Customer order Report',
                    text: "Export as Excel",
                     exportOptions: {
                        message: "Customer order Report",
                        columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 ,13]
                    },
                },            
            ],
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.ord_user_unique_id==null) 
                        {
                            return 'Guest User';
                        }
                        else
                        {
                            return data.ord_user_unique_id;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.username_last==null || data.username_last==' ') 
                        { 
                            return '<span style="color:red">Guest Order </span><br>('+data.ad_username+')';
                            // return data.ad_username;
                        }
                        else
                        {
                            return data.username_last; 
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.order_placed_datentime==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.order_placed_datentime;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.order_completed_date==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.order_completed_date;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.orderno==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.orderno;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.total_price==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.total_price;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.orderbag_total==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.orderbag_total;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.margin==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.margin;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.net_margin==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.net_margin;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.no_of_units==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.no_of_units;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.area==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.area;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.dispatcher_persons==null) 
                        {
                            return '';   
                        }
                        else
                        {
                            return ''+data.dispatcher_persons+'';       
                        }
                    }
                }, 
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.delivery_persons==null) 
                        {
                            return '';  
                        }
                        else
                        { 
                            return ''+data.delivery_persons+ '';  
                        }
                    }
                }, 
            ]
        });
    }

    function refreshDetails() {
        $.when(getreportdetails()).done(function() {
            var table = $('#yalla_corder_report').DataTable();
            table.destroy();
            dispDetailslist(ReportDetailsJSON);
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});