$(document).ready(function() {

    var wastageJSON,AllProductList,yb_purchase_bill_id,mode;
    $('#Wastageentrydetailsdisp').hide();  
    $.when(getproductlist()).done(function(){
            dispallproductlist(AllProductList);     
    });
    
    function getproductlist()
    {
        return $.ajax({
            url: base_URL+'ThirdAxisCon/getallproductslistt',
            type:'POST',
            success:function(data)
            {
                AllProductList = $.parseJSON(data);
            },      
            error: function() {
                console.log("Error");  
            }
        }) ;
    }

    function dispallproductlist(JSON)
    {
         $('.product_code').each(function() {
            if (this.selectize) {
                for(x=0; x < JSON.products.length; ++x){
                    this.selectize.addOption({value:JSON.products[x].prod_code, text: JSON.products[x].prod_value});
                }
            }
        }); 
    }


    $(document).on('change', "#product_code", function() 
    {
        var selected_product_code = $(this).val();
        if (selected_product_code!='' && selected_product_code!=null && selected_product_code!=undefined) 
        {
            return $.ajax({
                url: base_URL+'ThirdAxisCon/getselectedproductofpurchase',
                type:'POST',
                data: {
                    "selected_product_code":selected_product_code
                },
                success:function(data){
                    wastageJSON = $.parseJSON(data);
                    var table = $('#Sub_Category').DataTable();
                    table.destroy(); 
                    dispwastageaddedproducts(wastageJSON);  
                    $('#Wastageentrydetailsdisp').show();  
                },      
                error: function() {
                    console.log("Error"); 
                    //alert('something bad happened'); 
                }
            }) ; 
        }      

    });          

    
    function dispwastageaddedproducts(JSON)
    {
        var i = 1;
        $('#Sub_Category').dataTable( {
            "aaSorting":[],
            "aaData": JSON,
            responsive: true,
            "aoColumns": [
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return i++;                 
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.purchase_date+' ';
                    }
                },                  
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.prd_code+' - '+ data.prod_name+'';
                    }
                },              
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.salable_stock+' '+ data.purchase_product_unit+'';
                    }
                },               
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.expiry_date==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return ''+ data.expiry_date+'';
                        }
                        // return ''+ data.expiry_date+'';
                    }
                },          
                {
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>  Record wastages</a>&nbsp;&nbsp;';
                    }
                },              
            ]               
        });
    }
    
    $('#New_Category').click(function(){
        mode="new";
        $('#largeModal').modal('show');
    });
    
    $(document).on('click','.BtnEdit',function(){
        mode="update";
        var d = new Date();
        var localTime = d.getTime();
        var localOffset = d.getTimezoneOffset() * 60000;
        var utc = localTime + localOffset;
        var offset = 4;    //UTC of Dubai is +04.00
        var dubai = utc + (3600000 * offset);
        var nd = new Date(dubai);
        
        var today = new Date(dubai);
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();
        today = yyyy + '-' + mm + '-' + dd;

        var r_index = $(this).attr('id');
        yb_purchase_bill_id = wastageJSON[r_index].yb_purchase_bill_id;
        $('#largeModal').modal('show');
        $('#product_detail_wd').val(''+wastageJSON[r_index].prd_code+' - '+ wastageJSON[r_index].prod_name+'');
        $('#basic-datepicker').val(today);
        $('#unit_id').val(wastageJSON[r_index].purchase_product_unit);
        $('#salable_stock_from').val(wastageJSON[r_index].salable_stock);
        $('#yb_purchase_bill_id').val(wastageJSON[r_index].yb_purchase_bill_id);
        $('#prod_code').val(wastageJSON[r_index].prd_code);
        $('#purchase_products_id').val(wastageJSON[r_index].purchase_products_id);
    });
        
    
    $('#wastages_Button').click(function(){
        $('.error').hide();

        var salable_stock_from = $('#salable_stock_from').val();
        var wastage_count_from = $('#wastage_count_from').val();

        if($('#product_detail_wd').val()=="")
        {
            $('.product_detail_wd').html("* Product Name Cannot be empty");
            $('.product_detail_wd').show();
        }
        else if($('.wastages_date').val()=="")
        {
            $('.wastages_date_error').html("* Wastage Date Cannot be empty");
            $('.wastages_date_error').show();
        }  
        else if($('#unit_id').val()=="")
        {
            $('.unit_id').html("* Unit type type Cannot be empty");
            $('.unit_id').show();
        }   
        else if($('#salable_stock_from').val()=="")
        {
            $('.salable_stock_error').html("* salable stock value Cannot be empty");
            $('.salable_stock_error').show();
        }   
        else if($('#wastage_count_from').val()=="")
        {
            $('.wastage_count_error').html("* Wastage value Cannot be empty");
            $('.wastage_count_error').show();
        }
        else if(parseFloat(wastage_count_from)<=0)
        {
            $('.wastage_count_error').html("* Wastage value Cannot be zero or less than zero");
            $('.wastage_count_error').show();
        }
        else if(parseFloat(wastage_count_from)>parseFloat(salable_stock_from))
        {
            $('.wastage_count_error').html("* Wastage value Cannot be greater than salable stock");
            $('.wastage_count_error').show();
        }
        else
        {
            updatewastages();
        }       
    });
    
    $('#largeModal').on('show.bs.modal', function () 
    {
        $(this).find('form').trigger('reset');
    }); 
    
    function updatewastages()
    {       
        var product_detail_wd =  $('#prod_code').val();

        var form = $('#FormDataDetailss')[0];
        var data = new FormData(form);
        request = $.ajax({
                type: "POST",
                enctype: 'multipart/form-data',
                url: base_URL+'ThirdAxisCon/updatewastagesproducts',
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                timeout: 600000,
        }); 
        request.done(function (response){
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Inserted Sucessfully',
                    type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                });
                refreshDetails()
                $('#largeModal').modal('hide');                
                var $select = $("#product_code").selectize();
                var selectize = $select[0].selectize;
                selectize.setValue(product_detail_wd);
            }
            else
            {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                });
            }       
        });     
    }

    function refreshDetails()
    {
        $.when(getproductlist()).done(function(){
            var table = $('#Sub_Category').DataTable();
            table.destroy();    
            // dispwastageaddedproducts(wastageJSON);                
        });     
    }



    $(document)
    .ajaxStart(function () {
        $(".loading").show();
    })
    .ajaxStop(function () 
    {
        $(".loading").hide();
    });

});
