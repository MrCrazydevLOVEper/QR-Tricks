$(document).ready(function() {
	var imageoneinserted='';
	var yallacreditsJSON,yalla_credit_offers_id,mode;

	$('#main_category_show_hide').hide();
	$('#sub_category_show_hide').hide();
	$('#main_department_show_hide').hide();
	$('#sub_department_show_hide').hide();

	$.when(getyallacreditsofferdetails()).done(function(){
			dispyallacreditsoffer(yallacreditsJSON);	
	});
	
	function getyallacreditsofferdetails()
	{
		return $.ajax({
			url: base_URL+'ThirdAxisCon/getyallacreditsofferdetails',
			type:'POST',
			success:function(data){
				//console.log(data);
				yallacreditsJSON = $.parseJSON(data);
				
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;
	}

	
	function dispyallacreditsoffer(JSON)
	{
		//$('#success_alert').show(1000);
		//console.log(dataJSON);
			var i = 1;
		$('#Sub_Category').dataTable( {
			"aaSorting":[],
			"aaData": JSON,
			responsive: true,
			"aoColumns": [
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return i++;					
					}
				},
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.offer_name+' ( '+ data.offer_code+' )';
					}
				},					
				{ 
					"mDataProp": function ( data, type, full, meta) 
					{
						if (data.offer_type=='internal') 
						{
							return 'Internal';
						}
						if (data.offer_type=='external') 
						{
							return 'External';
						}
					}
				},				
				{ 
					"mDataProp": function ( data, type, full, meta) {
						if (data.discount_type=='P') 
						{
							return 'Percentage';
						}
						if (data.discount_type=='A') 
						{
							return 'AED';
						}
					}
				},			
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.discount_value+' ';
					}
				},
				{
	                "mDataProp": function(data, type, full, meta) {
	                    if (data.offer_image_url !== null)
	                    //return "<a href="+data.produ_imgurl+" target='_blank'>Click to view Image</a>";
	                    //return "<img src="+data.produ_imgurl+" width=100>";
	                        return "<div class='pro-im'>" +
	                        "<img src='" + data.offer_image_url + "' alt='user' width=100>" +
	                        "<div class='pro-img-overlay'>" +
	                        "<ul class='pro-img-overlay-1'>" +
	                        "<li class='el-item'>" +
	                        "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href='" + data.offer_image_url + "'>" +
	                        "<i class='fa fa-eye'></i></a>" +
	                        "</li>" +
	                        "</ul></div></div>";
	                    else
	                        return '';
	                }
	            },
				{
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return '<a id="' + meta.row + '" class="btn viewoffers" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;  view</a>&nbsp;&nbsp;';
                    }
                },
				{
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  visible</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Hidden</a>&nbsp;&nbsp;';;

                    }
                },
				{
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },				
			]  				
		});
	}
	
	$('#New_Category').click(function(){
		mode="new";
		$('#largeModal').modal('show');
	});


	$(document).on('click','.viewoffers',function(){
		$('#largeModalview').modal('show');
		var r_index = $(this).attr('id');
		var offer_type = '';
        if (yallacreditsJSON[r_index].discount_type == 'P') {
            offer_type = 'Percentage';
        } else {
            offer_type = 'AED';
        }

		$('.offer_name_view').html('');
		$('.offer_type_view').html('');
		$('.discount_type_view').html('');
		$('.discount_max_value_view').html('');
		$('.offer_from_date_view').html('');
		$('.offer_method_view').html('');
		$('.offer_code_view').html('');
		$('.min_credit_points_view').html('');
		$('.discount_value_view').html('');
		$('.offer_image_url_view').html('');
		$('.offer_discription_view').html('');

		$('.offer_name_view').append(yallacreditsJSON[r_index].offer_name);
		$('.offer_type_view').append(yallacreditsJSON[r_index].offer_type);
		$('.discount_type_view').append(offer_type);
		$('.discount_max_value_view').append(yallacreditsJSON[r_index].discount_max_value);
		$('.offer_from_date_view').append(yallacreditsJSON[r_index].offer_from_date);
		$('.offer_method_view').append(yallacreditsJSON[r_index].offer_method);
		$('.offer_code_view').append(yallacreditsJSON[r_index].offer_code);
		$('.min_credit_points_view').append(yallacreditsJSON[r_index].min_credit_points);
		$('.discount_value_view').append(yallacreditsJSON[r_index].discount_value);
		$('.offer_discription_view').append(yallacreditsJSON[r_index].offer_discription);

		$('.offer_image_url_view').append('<div class="image-display" id="image-display"><div><img src=" '+yallacreditsJSON[r_index].offer_image_url+ '" class="user-update-image" alt="user profile" width="100px" style="padding-top: 15px;"></div> </div>');

	});

	$(document).on('change','#offer_type',function()
	{
		if ($(this).val()=='internal') 
		{
			$('#offer_method_hide_show').show();
		}
		else
		{
			$('#offer_method_hide_show').hide();
		}
		$('#offer_method').val('');
		$( "#offer_method" ).trigger( "change" );
	});


	$(document).on('change','#offer_method',function()
	{
		console.log($(this).val());
		if ($(this).val()=='main_category') 
		{
			$('#main_category_show_hide').show();
			$('#sub_category_show_hide').hide();
			$('#main_department_show_hide').hide();
			$('#sub_department_show_hide').hide();
		}
		else if ($(this).val()=='sub_category') 
		{
			$('#main_category_show_hide').hide();
			$('#sub_category_show_hide').show();
			$('#main_department_show_hide').hide();
			$('#sub_department_show_hide').hide();
		}
		else if ($(this).val()=='main_department') 
		{
			$('#main_category_show_hide').hide();
			$('#sub_category_show_hide').hide();
			$('#main_department_show_hide').show();
			$('#sub_department_show_hide').hide();
		}
		else if ($(this).val()=='sub_department') 
		{
			$('#main_category_show_hide').hide();
			$('#sub_category_show_hide').hide();
			$('#main_department_show_hide').hide();
			$('#sub_department_show_hide').show();
		}
		else
		{
			$('#main_category_show_hide').hide();
			$('#sub_category_show_hide').hide();
			$('#main_department_show_hide').hide();
			$('#sub_department_show_hide').hide();
		}

		 var $select = $('#offer_method_id_md').selectize();
		 var control = $select[0].selectize;
		 control.clear();
		 var $select = $('#offer_method_id_sd').selectize();
		 var control = $select[0].selectize;
		 control.clear();
		 var $select = $('#offer_method_id_mc').selectize();
		 var control = $select[0].selectize;
		 control.clear();
		 var $select = $('#offer_method_id_sc').selectize();
		 var control = $select[0].selectize;
		 control.clear();

	});


	
	$(document).on('click','.BtnEdit',function(){
		mode="update";
		var r_index = $(this).attr('id');
		yalla_credit_offers_id = yallacreditsJSON[r_index].yalla_credit_offers_id;
		$('#largeModal').modal('show');

        if(yallacreditsJSON[r_index].offer_image_url!='')
        {
        	imageoneinserted = yallacreditsJSON[r_index].offer_image_url;
            $('#img_namee1').html('');
            $('#img_namee1').show();
			$('#img_namee1').append('<div class="image-display" id="image-display"><div><img src=" '+yallacreditsJSON[r_index].offer_image_url+ '" class="user-update-image" alt="user profile" width="100px" style="padding-top: 15px;"></div><p style="color:red">delete and add new </p> <div class="image-delete-icon image-delete" id="dispimg_namee1">Delete <i class="fa fa-bitbucket image-delete" ></i></div> </div>');
			$('#offer_image_url').prop('disabled', true);
        } 
		$('#offer_name').val(yallacreditsJSON[r_index].offer_name);
		$('#offer_code').val(yallacreditsJSON[r_index].offer_code);
		$('#offer_type').val(yallacreditsJSON[r_index].offer_type);
		$('#min_credit_points').val(yallacreditsJSON[r_index].min_credit_points);
		$('#discount_type').val(yallacreditsJSON[r_index].discount_type);
		$('#discount_value').val(yallacreditsJSON[r_index].discount_value);
		$('#discount_max_value').val(yallacreditsJSON[r_index].discount_max_value);
		$('#offer_discription').val(yallacreditsJSON[r_index].offer_discription);
		$('.offer_from_date').val(yallacreditsJSON[r_index].offer_from_date);
		// $('.offer_to_date').val(yallacreditsJSON[r_index].offer_to_date);
		$('#yalla_credit_offers_id').val(yallacreditsJSON[r_index].yalla_credit_offers_id);

		$( "#offer_type" ).trigger( "change" );

		$('#offer_method').val(yallacreditsJSON[r_index].offer_method);
		
		$( "#offer_method" ).trigger( "change" );
		
		if (yallacreditsJSON[r_index].offer_method=='main_department') 
		{
	        setTimeout(function(){ 
	            var $select = $("#offer_method_id_md").selectize();
	            var selectize = $select[0].selectize;
	            var yourDefaultIds = yallacreditsJSON[r_index].offer_method_id; 
	            selectize.setValue(yourDefaultIds);
	        }, 500);
		}
		
		if (yallacreditsJSON[r_index].offer_method=='sub_department') 
		{
	        setTimeout(function(){ 
	            var $select = $("#offer_method_id_sd").selectize();
	            var selectize = $select[0].selectize;
	            var yourDefaultIds = yallacreditsJSON[r_index].offer_method_id; 
	            selectize.setValue(yourDefaultIds);
	        }, 500);
		}
		
		if (yallacreditsJSON[r_index].offer_method=='main_category') 
		{
	        setTimeout(function(){ 
	            var $select = $("#offer_method_id_mc").selectize();
	            var selectize = $select[0].selectize;
	            var yourDefaultIds = yallacreditsJSON[r_index].offer_method_id; 
	            selectize.setValue(yourDefaultIds);
	        }, 500);
		}
		
		if (yallacreditsJSON[r_index].offer_method=='sub_category') 
		{
	        setTimeout(function(){ 
	            var $select = $("#offer_method_id_sc").selectize();
	            var selectize = $select[0].selectize;
	            var yourDefaultIds = yallacreditsJSON[r_index].offer_method_id; 
	            selectize.setValue(yourDefaultIds);
	        }, 500);
		}
	});

	$(document).on('click','#dispimg_namee1',function(){
		$('#img_namee1').hide();
		$('#offer_image_url').prop('disabled', false);
		imageoneinserted='';
	});		
	
	$(document).on('click','.BtnDelete',function(){
		mode="delete";
		var r_index = $(this).attr('id');
		yalla_credit_offers_id = yallacreditsJSON[r_index].yalla_credit_offers_id;	

		   $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Are you Sure Do you want to Delete this Data',
                type: 'blue',
					buttons: {
						Yes: function() {					
								request = $.ajax({
										type: "POST",
										url: base_URL+'ThirdAxisCon/DeleteYallacreditsoffers',
										data: {"yalla_credit_offers_id":yalla_credit_offers_id},
								});	
								request.done(function (response){
									var js = $.parseJSON(response);
									var status = js.result
									if (status == "success") {
										$.confirm({
											icon: 'icon-close',
											title: 'Info',
											content: 'Deleted Succesfully',
											type: 'green',
												buttons: {
													Ok: function() {},
												}
										});
										refreshDetails();
									}
									else
									{
										$.confirm({
											icon: 'icon-close',
											title: 'Info',
											content: 'Are you Sure Do you want to Delete this Data',
											type: 'blue',
												buttons: {
													No: function() {},
												}
										});
									}
							
								});	
						},
						No: function() {},
					}
            });
	});

    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        yalla_credit_offers_id = yallacreditsJSON[r_index].yalla_credit_offers_id;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreSubCategoryData(yalla_credit_offers_id,flag);
                },
                No: function() {},
            }
        });

    });

    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        yalla_credit_offers_id = yallacreditsJSON[r_index].yalla_credit_offers_id;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreSubCategoryData(yalla_credit_offers_id,flag);
                },
                No: function() {},
            }
        });

    });


    function RestoreSubCategoryData(yalla_credit_offers_id,flag)
    {
    	var yalla_credit_offers_id = yalla_credit_offers_id
    	var flag = flag;

        request = $.ajax({
                type: "POST",
                url: base_URL+'ThirdAxisCon/RestoreYallacreditsoffers',
                data: {"yalla_credit_offers_id":yalla_credit_offers_id,"flag":flag},
        }); 
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


	
	$('#Form_details_submit').click(function(){
		$('.error').hide();
		//console.log($('#mcName').val());
		if($('#offer_name').val()=="")
		{
			$('.offer_name').html("* Please Fill Offer Name");
			$('.offer_name').show();
		}
		else if($('#offer_code').val()=="")
		{
			$('.offer_code').html("* Please Fill Offer Code");
			$('.offer_code').show();
		}

		else if($('#offer_type').val()=="")
		{
			$('.offer_type').html("* Select Offer type");
			$('.offer_type').show();
		}
		else if($('#min_credit_points').val()=="")
		{
			$('.min_credit_points').html("* Enter minimun credit points");
			$('.min_credit_points').show();
		}

		else if($('#discount_type').val()=="")
		{
			$('.discount_type').html("* Select the discount type");
			$('.discount_type').show();
		}
		else if($('#discount_value').val()=="")
		{
			$('.discount_value').html("* Enter discount value");
			$('.discount_value').show();
		}
		else if($('#discount_max_value').val()=="")
		{
			$('.discount_max_value').html("* Enter max discount value");
			$('.discount_max_value').show();
		}
		else if($('#offer_image_url').val()=="" && mode=="new")
		{
			$('.offer_image_url').html("* Select the offer image");
			$('.offer_image_url').show();
		}
		else if($('.offer_from_date').val()=="")
		{
			$('.offer_from_date_error').html("* Select the from date");
			$('.offer_from_date_error').show();
		}
		// else if($('.offer_to_date').val()=="")
		// {
		// 	$('.offer_to_date_error').html("* Select the to date");
		// 	$('.offer_to_date_error').show();
		// }
		else if($('#offer_type').val()=="internal" && $('#offer_method').val()=='')
		{
			$('.offer_method').html("* Select Offer Method");
			$('.offer_method').show();
		}
		else if($('#offer_type').val()=="internal" && $('#offer_method').val()=='')
		{
			$('.offer_method').html("* Select Offer Method");
			$('.offer_method').show();
		}
		else if($('#offer_method').val()=="main_category" && $('#offer_method_id_mc').val()=='')
		{
			$('.offer_method_id_mc').html("* Select Category type");
			$('.offer_method_id_mc').show();
		}
		else if($('#offer_method').val()=="sub_category" && $('#offer_method_id_sc').val()=='')
		{
			$('.offer_method_id_sc').html("* Select Category type");
			$('.offer_method_id_sc').show();
		}
		else if($('#offer_method').val()=="main_department" && $('#offer_method_id_md').val()=='')
		{
			$('.offer_method_id_md').html("* Select Category type");
			$('.offer_method_id_md').show();
		}
		else if($('#offer_method').val()=="sub_department" && $('#offer_method_id_sd').val()=='')
		{
			$('.offer_method_id_sd').html("* Select Category type");
			$('.offer_method_id_sd').show();
		}
		else if($('#offer_discription').val()=="")
		{
			$('.offer_discription').html("* Enter the Offer Dsicription");
			$('.offer_discription').show();
		}
		else
		{
			if(mode=="new")
			{
				Saveyallacreditoffers();
			}
			else
			{
				updateyallacreditoffers();
			}			
		}		
	});
	
	$('#largeModal').on('show.bs.modal', function () 
	{
		$(this).find('form').trigger('reset');

		$('#img_namee1').hide();
		$('#offer_image_url').prop('disabled', false);
		imageoneinserted='';

		var $select = $('#offer_method_id_md').selectize();
		var control = $select[0].selectize;
		control.clear();
		var $select = $('#offer_method_id_sd').selectize();
		var control = $select[0].selectize;
		control.clear();
		var $select = $('#offer_method_id_mc').selectize();
		var control = $select[0].selectize;
		control.clear();
		var $select = $('#offer_method_id_sc').selectize();
		var control = $select[0].selectize;
		control.clear();
	});	
	
	function Saveyallacreditoffers()
	{		
		var form = $('#Form_details')[0];
		var data = new FormData(form);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/insertyallacreditoffers',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			//console.log(js);
			var status = js.result
			if (status == "success") {
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Updated Sucessfully',
					type: 'green',
						buttons: {
							Ok: function() {},
						}
				});
				$('#largeModal').modal('hide');
				refreshDetails();
			}
			else if (status == "Image_error") 
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Image size is too large please select another image',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}
			else if (status == "Image_empty") 
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Select the offer image',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}	
		});		
	}
	
	function refreshDetails()
	{
		$.when(getyallacreditsofferdetails()).done(function(){
			var table = $('#Sub_Category').DataTable();
			table.destroy();	
			dispyallacreditsoffer(yallacreditsJSON);				
		});		
	}
	
	function updateyallacreditoffers()
	{
		var form = $('#Form_details')[0];
		var data = new FormData(form);
		data.append("imageoneinserted",imageoneinserted);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/updateyallacreditoffers',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			var status = js.result
			if (status == "success") {
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Updated Sucessfully',
					type: 'green',
						buttons: {
							Ok: function() {},
						}
				});
				$('#largeModal').modal('hide');
				refreshDetails();
			}
			else if (status == "Image_error") 
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Image size is too large please select another image',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}
			else if (status == "Image_empty") 
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Select the offer image',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}		
		});			
	}

        	  $(document)
              .ajaxStart(function () {
                $(".loading").show();
              })
              .ajaxStop(function () {
                $(".loading").hide();
              });

});
