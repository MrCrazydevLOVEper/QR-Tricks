$(document).ready(function() {

	var referandearnJSON,refer_and_earn_id,mode;

	$.when(getreferandearndetails()).done(function()
	{
		refer_and_earn_id = referandearnJSON[0]["refer_and_earn_id"];
		$('#new_customer_value').val(referandearnJSON[0]["new_customer_value"]);
		$('#discount_type').val(referandearnJSON[0]["discount_type"]);
		$('#max_discount').val(referandearnJSON[0]["max_discount"]);
		$('#existing_customer_value').val(referandearnJSON[0]["existing_customer_value"]);
		$('#frequency').val(referandearnJSON[0]["frequency"]);
		$('#min_purchase').val(referandearnJSON[0]["min_purchase"]);
	});
	
	function getreferandearndetails()
	{
		return $.ajax({
			url: base_URL+'ThirdAxisCon/getreferandearndetails',
			type:'POST',
			success:function(data)
			{
				referandearnJSON = $.parseJSON(data);	
			},		
			error: function() {
				console.log("Error"); 
			}
		}) ;
	}
	
	$('#Formdata_details_submit').click(function(){
		$('.error').hide();

		if($('#new_customer_value').val()=="")
		{
			$('.new_customer_value').html("* New customer value cannot be empty");
			$('.new_customer_value').show();
		}
		else if($('#existing_customer_value').val()=="")
		{
			$('.existing_customer_value').html("* Existing customer value cannot be empty");
			$('.existing_customer_value').show();
		}
		else if($('#discount_type').val()=="")
		{
			$('.discount_type').html("* Discount type cannot be empty");
			$('.discount_type').show();
		}
		else if($('#frequency').val()=="")
		{
			$('.frequency').html("* Frequency Cannot be empty");
			$('.frequency').show();
		}	
		else if($('#max_discount').val()=="")
		{
			$('.max_discount').html("* Max discount Cannot be empty");
			$('.max_discount').show();
		}	
		else if($('#min_purchase').val()=="")
		{
			$('.min_purchase').html("* Minimum purchase cannot be empty");
			$('.min_purchase').show();
		}			
		else
		{
			updatereferandearnvalue();			
		}		
	});

	
	function updatereferandearnvalue()
	{		
		var form = $('#Formdata_details')[0];
		var data = new FormData(form);
		data.append("refer_and_earn_id", refer_and_earn_id);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/updatereferandearnvalues',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			var status = js.result
			if (status == "success") {
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Updated Sucessfully',
					type: 'green',
						buttons: {
							Ok: function() {},
						}
				});
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}		
		});		
	}


  $(document)
  .ajaxStart(function () {
    $(".loading").show();
  })
  .ajaxStop(function () {
    $(".loading").hide();
  });

});
