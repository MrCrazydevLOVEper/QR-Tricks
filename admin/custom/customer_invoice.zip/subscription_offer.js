$(document).ready(function() {

    var banner_id, mode, BannerproductDetailJSON,filtered_prod;

    $.when(getbannerproductsDetails()).done(function() {
        dispBannerproductDetails(BannerproductDetailJSON);
        getbrandlistdata();
    });

    function getbannerproductsDetails() 
    {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getsubscriptionofferprod',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                BannerproductDetailJSON = $.parseJSON(data);
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }

    $(document).on('change', '#md_code', function() {
        var md_code = $('#md_code').val();
        $('#sd_code').val('');
        $('#sd_code').html('');
        $('#sd_code').append("<option value=''>Select the Sub Department</option>");
        $('#mc_code').val('');
        $('#mc_code').html('');
        $('#mc_code').append("<option value=''>Select the Main Category</option>");
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        if(md_code!='')
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getSubDepartment',
                type: 'POST',
                data: {
                    "md_code": md_code
                },
                success: function(data) {
                    SubDepatmentJSON = $.parseJSON(data);
                    for (var i = 0; i < SubDepatmentJSON.length; i++) {
                        $('#sd_code').append("<option value='" + SubDepatmentJSON[i].sd_code + "'>" + SubDepatmentJSON[i].sdName + " ( " + SubDepatmentJSON[i].sd_code + " )</option>");
                        //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                    }
                    getbrandlistdata();
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            getbrandlistdata();
        }
    });


    $(document).on('change', '#sd_code', function() {
        var md_code = $('#md_code').val();
        var sd_code = $('#sd_code').val();
        $('#mc_code').val('');
        $('#mc_code').html('');
        $('#mc_code').append("<option value=''>Select the Main Category</option>");
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        if(md_code!='' && sd_code!='')
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getMainCategory',
                type: 'POST',
                data: {
                    "sd_code": sd_code,
                    "md_code": md_code
                },
                success: function(data) {
                    MainCategoryJSON = $.parseJSON(data);
                   $('#mc_code').html('');
                   $('#mc_code').append("<option value=''>Select the Main Category</option>");
                    for (var i = 0; i < MainCategoryJSON.length; i++) {
                        $('#mc_code').append("<option value='" + MainCategoryJSON[i].mc_code + "'>" + MainCategoryJSON[i].mcName + " ( " + MainCategoryJSON[i].mc_code + " )</option>");
                        //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                    }
                    getbrandlistdata();
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            getbrandlistdata();
        }

    });


    $(document).on('change', '#mc_code', function() {
        var md_code = $('#md_code').val();
        var sd_code = $('#sd_code').val();
        var mc_code = $('#mc_code').val();
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        if(md_code!='' && sd_code!='' && mc_code!='')
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getSubCategory',
                type: 'POST',
                data: {
                    "sd_code": sd_code,
                    "md_code": md_code,
                    "mc_code": mc_code
                },
                success: function(data) {
                    MainCategoryJSON = $.parseJSON(data);
                   $('#sc_code').html('');
                   $('#sc_code').append("<option value=''>Select the Sub Category</option>");
                    for (var i = 0; i < MainCategoryJSON.length; i++) {
                        $('#sc_code').append("<option value='" + MainCategoryJSON[i].sc_code + "'>" + MainCategoryJSON[i].scName + " ( " + MainCategoryJSON[i].sc_code + " )</option>");
                        //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                    }
                    getbrandlistdata();
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            getbrandlistdata();
        }
    });

    $(document).on('change', '#sc_code', function() {
         getbrandlistdata();

    });

    function getbrandlistdata()
    {
        var md_code = 0;
        var sd_code = 0;
        var mc_code = 0;
        var sc_code = 0;

        if($('#md_code').val()!='')
        {
            md_code = $('#md_code').val();
        }
        if($('#sd_code').val()!='')
        {
            sd_code = $('#sd_code').val();
        }
        if($('#mc_code').val()!='')
        {
            mc_code = $('#mc_code').val();
        }
        if($('#sc_code').val()!='')
        {
            sc_code = $('#sc_code').val();
        }

        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getbrandnamelist',
            type: 'POST',
            data: {
                "sd_code": sd_code,
                "md_code": md_code,
                "mc_code": mc_code,
                "sc_code": sc_code
            },
            success: function(data) {
                BrandJson = $.parseJSON(data);
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
                for (var i = 0; i < BrandJson.length; i++) {
                    $('#brand_name').append("<option value='" + BrandJson[i].brand_name + "'>" + BrandJson[i].brand_name + "</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
                // $('#sd_code').val(subdepartmentid);
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }



    function dispBannerproductDetails(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        var myoddtbl = $('#offer_product_table').DataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            columnDefs: [
                { orderable: true, className: 'reorder', targets: 1 },
                { orderable: false, targets: '_all' }
            ],
          rowReorder: {
                selector: 'tr',
                dataSrc:JSON
            },
            ordering: false,
            // paging: false,
            // dom: 'Bfrtip',
            // buttons: [
            //     {
            //         extend: 'csv',
            //         title: 'Hot Seller List ',
            //         text: "Export as Excel",
            //          exportOptions: {
            //             message: "Hot Seller Product List",
            //             columns: [ 3, 2, 5]
            //         },
            //     },            
            //     // {
            //     //     extend: 'pdf',
            //     //     messageTop: "Hot Seller Product List",
            //     //     title: 'Hot Seller List ',
            //     //      exportOptions: {
            //     //         columns: [ 2, 3, 5]
            //     //     },
            //     // },
            //     //     'print'
            // ],

            "aoColumns": [

                {
                    "mDataProp": function (data, type, full, meta) 
                    {
                        return '<input type="checkbox" class="select-checkbox" value="'+data.prod_code+'" data-attr-prod_id="'+data.prod_id+'"  name="user_id" >';
                    },
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },

                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.offer_name+"";                    
                    }
                },      
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.prod_code+"";                    
                    }
                },      
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.subscribe_offer_type=="P") 
                        {
                            return "Percentage";                    
                        }
                        else
                        {
                            return "Amount";                    
                        }
                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.subscribe_offer_value+"";                    
                    }
                },
                 {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Deactivate</a>&nbsp;&nbsp;';

                    }
                },
            ],

    'createdRow': function(row, data, dataIndex){
         $(row).attr('id', data.prod_code);
      }

        });

        myoddtbl.on( 'row-reorder', function ( e, details, changes ) {
            var newPosition = [];
            var id = [];
            for (var i = 0; i < details.length; i++) 
            {
                newPosition.push(details[i].newPosition+1);
                id.push(details[i].node.id);
            }
            var emp_arr = newPosition.toString();
            var emp_prod_id = id.toString();


            if(id.length>0)
            {
                return $.ajax({
                    url: base_URL + 'ThirdAxisCon/updatehotsellersort',
                    type: 'POST',
                    data: {
                        "hotseller_sort": emp_arr,
                        "prod_code": emp_prod_id
                    },
                    success: function(data) 
                    {
                        refreshDetails();
                    },
                    error: function() 
                    {
                        console.log("Error");
                    }
                });

            }
            editor
                .edit( changes.nodes, false, {
                    submit: 'changed'
                } )
                .multiSet( changes.dataSrc, changes.values )
                .submit();
        } );


    }


    $('input[name="selectAllcheck"]').click(function()
    {
        var table = $('#offer_product_table').DataTable();
        if($(this).prop("checked") == true)
        {

            table.$('td > input:checkbox').each(function () 
            {
                table.$("input[name='user_id']").prop('checked',true);
            }); 

        }
        else if($(this).prop("checked") == false)
        {
            table.$('td > input:checkbox').each(function () 
            {
                table.$("input[name='user_id']").prop('checked',false);
            }); 
            // $.each($("input[name='user_id']"), function(){
            //     $("input[name='user_id']").prop('checked',false);
            // });
        }
    });


    $(document).on('click','#button_deactivate',function()
    {
        var banner_id = $('#banner_id').val();
        var prod_id = [];
        var prod_code = [];
        var table = $('#offer_product_table').DataTable();
        table.$('td > input:checkbox').each(function () {
            if (this.checked) {
                prod_code.push($(this).val());
                prod_id.push($(this).attr('data-attr-prod_id'));
            }
        });        
        var emp_arr =  prod_code.join(",");
        var emp_prod_id =  prod_id.join(",");
        if(prod_id.length==0)
        {
            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Please Select any product to Remove the offer',
                type: 'red',
                buttons: {
                    Ok: function() {},
                }
            });
        }
        else
        {
            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Are you Sure Do you want to Remove this product offer',
                type: 'blue',
                buttons: {
                    Yes: function() {
                        request = $.ajax({
                            url: base_URL + 'ThirdAxisCon/updateofferstosubscription',
                            type: 'POST',
                            data: {
                                "emp_arr":emp_arr,
                                "emp_prod_id":emp_prod_id,
                                "subscribe_offer_flag":0,
                                "offer_applied_type":"",
                                "offer_value":"",
                            },
                        });
                        request.done(function(response) {
                            var js = $.parseJSON(response);
                            var status = js.result
                            if (status == "success") {
                                $.confirm({
                                    icon: 'icon-close',
                                    title: 'Info',
                                    content: 'Removed Succesfully',
                                    type: 'green',
                                    buttons: {
                                        Ok: function() {
                                            refreshDetails();
                                        },
                                    }
                                });
                                refreshDetails();
                            } else {
                                $.confirm({
                                    icon: 'icon-close',
                                    title: 'Info',
                                    content: 'Sorry something went wrong',
                                    type: 'blue',
                                    buttons: {
                                        No: function() {},
                                    }
                                });
                            }

                        });
                    },
                    No: function() {},
                }
            });
        }

    }); 



    $('#Product_Button').click(function() 
    {
        if ($('#md_code').val()!="" || $('#sd_code').val()!="" || $('#mc_code').val()!="" || $('#sc_code').val()!="" || $('#brand_name').val()!="" ) 
        {
            var md_code =0;
            var sd_code =0;
            var mc_code =0;
            var sc_code =0;
            var brand_name =0;

            if($('#md_code').val()!='')
            {
                md_code = $('#md_code').val();
            }
            if($('#sd_code').val()!='')
            {
                sd_code = $('#sd_code').val();
            }
            if ($('#mc_code').val()!='')
            {
                mc_code = $('#mc_code').val();
            }
            if ($('#sc_code').val()!='')
            {
                sc_code = $('#sc_code').val();
            }
            if ($('#brand_name').val()!='')
            {
                brand_name = $('#brand_name').val();
            }


            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getprodtoapplysubscriptionoffer',
                type: 'POST',
                data: {
                    "md_code": md_code,
                    "sd_code": sd_code,
                    "mc_code": mc_code,
                    "sc_code":sc_code,
                    "brand_name": brand_name
                },
                success: function(data) {
                    filtered_prod = $.parseJSON(data);
                    // console.log(result);
                    // OfferDetailJSON = $.parseJSON(data);
                    dispOfferDetails(filtered_prod);

                    
                $('.disptbl').show();
                $('.disptbloffer').hide();

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Please Select and click filter',
                type: 'red',
                buttons: {
                    Ok: function() {},
                }
            });
        }
    });

    function dispOfferDetails(JSON) {

        $('#offer_table').DataTable().destroy();
        var i =1;

        var myTable  = $('#offer_table').DataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            columnDefs: [{
                orderable: false,
                targets: 0,
            }],

            order: [
                [1, 'asc'],
            ],
            "aoColumns": [

                {
                    "mDataProp": function (data, type, full, meta) 
                    {
                        return '<input type="checkbox" class="select-checkbox" value="'+data.prod_code+'" data-attr-prod_id="'+data.prod_id+'"  name="user_idkes" >';
                    },
                },

                {
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },

                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.prod_name+"";                    
                    }
                },      
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.prod_code+"";                    
                    }
                }, 
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if(data.subscribe_offer_type=='' || data.subscribe_offer_type==null)
                        {
                            return '';
                        }
                        else if(data.subscribe_offer_type=='P')
                        {
                            return 'Percentage';
                        }
                        else if(data.subscribe_offer_type=='A')
                        {
                            return 'Money';
                        }
                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if(data.subscribe_offer_type=='' || data.subscribe_offer_type==null)
                        {
                            return '';
                        }
                        else if(data.subscribe_offer_type=='P')
                        {
                            return '% '+data.subscribe_offer_value;
                        }
                        else if(data.subscribe_offer_type=='A')
                        {
                            return 'AED '+data.subscribe_offer_value;
                        }
                    }
                },     

                 {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return '<a id="' + meta.row + '" class="btn Btnadd" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Add</a>&nbsp;&nbsp;' ;
                    }
                },
            ]
        });

    }

    $('input[name="selectAllcheck2"]').click(function()
    {
        var myTable = $('#offer_table').DataTable();
        if($(this).prop("checked") == true)
        {
            myTable.$('td > input:checkbox').each(function () 
            {
                myTable.$("input[name='user_idkes']").prop('checked',true);
            }); 
        }
        else if($(this).prop("checked") == false)
        {
            myTable.$('td > input:checkbox').each(function () 
            {
                myTable.$("input[name='user_idkes']").prop('checked',false);
            }); 
        }
    });


    $(document).on('click','#addoffers',function()
    {
        var prod_id = [];
        var prod_code = [];
        var myTable = $('#offer_table').DataTable();
        myTable.$('td > input:checkbox').each(function () {
            if (this.checked) {
                prod_code.push($(this).val());
                prod_id.push($(this).attr('data-attr-prod_id'));
            }
        });       
        var emp_arr =  prod_code.join(",");
        var emp_prod_id =  prod_id.join(",");


        if(prod_id.length<=0)
        {
            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Please Select any product to add offer',
                type: 'red',
                buttons: {
                    Ok: function() {},
                }
            });
        }
        else
        {
            $('#emp_arr').val(emp_arr);
            $('#emp_prod_id').val(emp_prod_id);
            $('#largeModal').modal('show');
        }

    }); 

    
    $(document).on('click', '#subscription_offer_form_submit', function() 
    {
        var form = $('#subscription_offer_form')[0];
        var data = new FormData(form);
        data.append("subscribe_offer_flag","1");
        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/updateofferstosubscription',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                $( "#Product_Button" ).trigger( "click" );
            } else {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }       
        });
            
    });  

    $(document).on('click', '#idrefresh', function() {
            window.location.reload();
    });

    $(document).on('click', '.BtnRestore', function() {
        var r_index = $(this).attr('id');
        prod_id = BannerproductDetailJSON[r_index].prod_id;
        prod_code = BannerproductDetailJSON[r_index].prod_code;
        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Remove this product offer',
            type: 'blue',
            buttons: {
                Yes: function() {
                    request = $.ajax({
                        url: base_URL + 'ThirdAxisCon/updateofferstosubscription',
                        type: 'POST',
                        data: {
                            "emp_arr":prod_code,
                            "emp_prod_id":prod_id,
                            "subscribe_offer_flag":0,
                            "offer_applied_type":"",
                            "offer_value":"",
                        },
                    });
                    request.done(function(response) {
                        var js = $.parseJSON(response);
                        var status = js.result
                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Removed Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {
                                        refreshDetails();
                                    },
                                }
                            });
                            refreshDetails();
                        } else {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Sorry something went wrong',
                                type: 'blue',
                                buttons: {
                                    No: function() {},
                                }
                            });
                        }

                    });
                },
                No: function() {},
            }
        });
    });


    $(document).on('click', '.Btnadd', function() {
        var r_index = $(this).attr('id');
        prod_id = filtered_prod[r_index].prod_id;
        prod_code = filtered_prod[r_index].prod_code;
        $('#emp_arr').val(prod_code);
        $('#emp_prod_id').val(prod_id);
        $('#largeModal').modal('show');

    });

    function refreshDetails() {
        $.when(getbannerproductsDetails()).done(function() {
            var table = $('#offer_product_table').DataTable();
            table.destroy();
            dispBannerproductDetails(BannerproductDetailJSON);
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});