$(document).ready(function() {

    var OrderSettingJSON, order_setting_id, mode;
    $.when(getOrderSetting()).done(function() {
        dispOrderSetting(OrderSettingJSON);
    });

    function getOrderSetting() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getorder_setting',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                OrderSettingJSON = $.parseJSON(data);

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    function dispOrderSetting(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": "order_accept_date"
                },
                {
                    "mDataProp": "order_accept_time"
                },

                {
                    "mDataProp": "order_accept_count"
                },  {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  visible</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Hidden</a>&nbsp;&nbsp;';

                    }
                }, {
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },
            ]
        });
    }

    $('#New_Category').click(function() {
        mode = "new";
        $('#largeModal').modal('show');
    });

    $(document).on('click', '.BtnEdit', function() {
        mode = "update";
        var r_index = $(this).attr('id');
        order_setting_id = OrderSettingJSON[r_index].order_setting_id;
        $('#largeModal').modal('show');
        $('#basic-datepicker').val(OrderSettingJSON[r_index].order_accept_date);
        $('#order_accept_time').val(OrderSettingJSON[r_index].order_accept_time);
        $('#order_accept_count').val(OrderSettingJSON[r_index].order_accept_count);
    });

    $(document).on('click', '.BtnDelete', function() {
        mode = "delete";
        var r_index = $(this).attr('id');
        order_setting_id = OrderSettingJSON[r_index].order_setting_id;
        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Delete this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                    request = $.ajax({
                        type: "POST",
                        url: base_URL + 'ThirdAxisCon/DeleteOrderSettingData',
                        data: {
                            "order_setting_id": order_setting_id
                        },
                    });
                    request.done(function(response) {
                        var js = $.parseJSON(response);
                        var status = js.result
                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Deleted Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {},
                                }
                            });
                            refreshDetails();
                        } else {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Are you Sure Do you want to Delete this Data',
                                type: 'blue',
                                buttons: {
                                    No: function() {},
                                }
                            });
                        }

                    });
                },
                No: function() {},
            }
        });

    });

    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        order_setting_id = OrderSettingJSON[r_index].order_setting_id;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreOrderSettingData(order_setting_id,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        order_setting_id = OrderSettingJSON[r_index].order_setting_id;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreOrderSettingData(order_setting_id,flag);
                },
                No: function() {},
            }
        });

    });


    function RestoreOrderSettingData(order_setting_id,flag)
    {
    	var order_setting_id = order_setting_id;
    	var flag = flag;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/RestoreOrderSettingData',
            data: {
                "order_setting_id": order_setting_id,"flag":flag
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


    $('#Main_Department_Button').click(function() {
        $('.error').hide();
        //console.log($('#url').val()); 
        if ($('#basic-datepicker').val() == "") {
            $('.order_accept_date').html("* Please Fill The Date");
            $('.order_accept_date').show();
        } 
        else if ($('#order_accept_time').val() == "") {
            $('.order_accept_time').html("* Please Fill The Order Accept time");
            $('.order_accept_time').show();
        } 
        else if ($('#order_accept_count').val() == "") {
            $('.order_accept_count').html("* Please Fill The Order Count");
            $('.order_accept_count').show();
        } 

        else {
            if (mode == "new") {
                saveOrderSetting();
            } else {
                updateOrderSetting();
            }

        }
    });

    function saveOrderSetting() {

        var order_accept_date = $('#basic-datepicker').val();
        var order_accept_time = $('#order_accept_time').val();
        var order_accept_count = $('#order_accept_count').val();

        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/insertOrderSettingData',
            data: {
                "order_accept_date": order_accept_date,"order_accept_time": order_accept_time,"order_accept_count": order_accept_count
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            console.log(status);
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Inserted Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } 
            else if (status == "errorrrr") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Error !!',
                    content: 'The Selected Order Accepting Date has been added already.',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            } 
            else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }

        });

    }

    function refreshDetails() {
        $.when(getOrderSetting()).done(function() {
            var table = $('#Main_Category').DataTable();
            table.destroy();
            dispOrderSetting(OrderSettingJSON);
        });
    }

    function updateOrderSetting() 
    {

        var order_accept_date = $('#basic-datepicker').val();
        var order_accept_time = $('#order_accept_time').val();
        var order_accept_count = $('#order_accept_count').val();

        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/updateOrderSettingData',
            data: {
                "order_accept_date": order_accept_date,"order_accept_time": order_accept_time,"order_accept_count": order_accept_count,"order_setting_id":order_setting_id
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            console.log(status);
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } 
            else if (status == "errorrrr") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Error !!',
                    content: 'The Selected Order Accepting Date has been added already.',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            } 
            else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }

        });

        // var form = $('#Main_Department_Form')[0];
        // var data = new FormData(form);
        // data.append("order_setting_id", order_setting_id);
        // request = $.ajax({
        //     type: "POST",
        //     enctype: 'multipart/form-data',
        //     url: base_URL + 'ThirdAxisCon/updateOrderSettingData',
        //     data: data,
        //     processData: false,
        //     contentType: false,
        //     cache: false,
        //     timeout: 600000,
        // });
        // request.done(function(response) {
        //     var js = $.parseJSON(response);
        //     var status = js.result;
        //     if (status == "success") {
        //         $.confirm({
        //             icon: 'icon-close',
        //             title: 'Info',
        //             content: 'Updated Sucessfully',
        //             type: 'green',
        //             buttons: {
        //                 Ok: function() {},
        //             }
        //         });
        //         $('#largeModal').modal('hide');
        //         refreshDetails();
        //     }
        //     else if (status == "errorrrr") {
        //         $.confirm({
        //             icon: 'icon-close',
        //             title: 'Error !!',
        //             content: 'The Selected Order Accepting Date has been added already.',
        //             type: 'red',
        //             buttons: {
        //                 Ok: function() {},
        //             }
        //         });
        //     } 
        //     else {
        //         $.confirm({
        //             icon: 'icon-close',
        //             title: 'Info',
        //             content: 'Sorry Something went worng',
        //             type: 'red',
        //             buttons: {
        //                 Ok: function() {},
        //             }
        //         });
        //     }		
        // });
    }

    $('#largeModal').on('show.bs.modal', function() {
        $(".no").hide();
        $('#hide').attr('checked', false);
        $('#show').attr('checked', false);
        $(this).find('form').trigger('reset');
    });


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});