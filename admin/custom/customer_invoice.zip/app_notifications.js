$(document).ready(function() {

    var AppNotificationsdetailsJSON, banner_id, mode,OfferproductDetailJSON,AppNotificationsdetailsJSON;

    $.when(getinventorydetails()).done(function(){
            dispgingdetails(AppNotificationsdetailsJSON);                
    });


    function getinventorydetails()
    {

        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getsentpushnotifications',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                AppNotificationsdetailsJSON = $.parseJSON(data);
            },
            error: function() {
                console.log("Error");            }
        });
    }

    function dispgingdetails(JSON) {
        var i =1;
        $('#Sub_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                       return ''+data.msg_title+'';
                    }
                }, 
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                       return ''+data.msg_content+'';
                    }
                }, 
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.datentime+'';
                    }
                },       
            ]
        });
    }


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });


});