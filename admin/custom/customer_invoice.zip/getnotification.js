// $(document).ready(function() {
//     $.when(getsidemenus()).done(function() {
//         // dispMainCategory(MainCategoryJSON);
//     });


//     $.when(getnotifications()).done(function() {
//         // dispMainCategory(MainCategoryJSON);
//     });
//     setInterval(getnotifications, 30000);

//     function getsidemenus() {
//         $(".loading").hide();
//         return $.ajax({
//             url: base_URL + '/ThirdAxisCon/getmenudetails',
//             type: 'POST',
//             beforeSend: function(){
//                 $(".loading").hide();
//             },
//             complete: function(){
//                 $(".loading").hide();
//             },
//             success: function(data) {
//                 //console.log(data);
//                 var MainMenuJSON = $.parseJSON(data);
//                 if (MainMenuJSON.length>0) 
//                 {
//                     $('#side-menu').html('');
//                     for (var i = 0; i < MainMenuJSON.length; i++) 
//                     {
//                         if (MainMenuJSON[i]["sub_menus_count"]>0) 
//                         {
//                             var submenuss = '';
//                             for (var j = 0; j < MainMenuJSON[i]["sub_menus"].length; j++) 
//                             {
//                                 submenuss += '<li id="subdept'+MainMenuJSON[i]["sub_menus"][j]["sub_menu_id"]+'" > <a class="sidebar-link waves-effect waves-dark sidebar-link" '+
//                                             'href="'+base_URL+'ThirdAxisCon/'+MainMenuJSON[i]["sub_menus"][j]["sub_menu_con_name"]+'" '+
//                                             'aria-expanded="false">'+MainMenuJSON[i]["sub_menus"][j]["sub_menu_name"]+'</a> </li>';
//                             }

//                             $('#side-menu').append('<li id="maindept'+MainMenuJSON[i]["main_menu_id"]+'">'+
//                                     '<a href="#abcd'+MainMenuJSON[i]["main_menu_id"]+'" data-toggle="collapse">'+
//                                         '<i class="fa fa-'+MainMenuJSON[i]["main_menu_icon_name"]+' font-15 avatar-title"></i>'+
//                                         '<span> '+MainMenuJSON[i]["main_menu_name"]+' </span>'+
//                                         '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down" style="float:right;"><polyline points="6 9 12 15 18 9"></polyline></svg>'+
//                                     '</a>'+
//                                     '<div class="collapse" id="abcd'+MainMenuJSON[i]["main_menu_id"]+'">'+
//                                         '<ul class="nav-second-level">'+
//                                             ''+submenuss+''+                                    
//                                         '</ul>'+
//                                     '</div>'+
//                                 '</li>');

//                             for (var j = 0; j < MainMenuJSON[i]["sub_menus"].length; j++) 
//                             {
//                                 var url = window.location.href;
//                                 var parts = url.split('/');

//                                 var lastSegment = parts.pop() || parts.pop();

//                                 if (lastSegment==MainMenuJSON[i]["sub_menus"][j]["sub_menu_con_name"]) 
//                                 {
//                                     $("#maindept"+MainMenuJSON[i]["main_menu_id"]+"").addClass("menuitem-active");
//                                     $("#abcd"+MainMenuJSON[i]["main_menu_id"]+"").addClass("show");
//                                     $("#subdept"+MainMenuJSON[i]["sub_menus"][j]["sub_menu_id"]+"").addClass("menuitem-active");
//                                     $("#subdept"+MainMenuJSON[i]["sub_menus"][j]["sub_menu_id"]+"").find('> a').addClass("active");
//                                 }
//                             }
//                         }
//                         else
//                         {
//                              $('#side-menu').append('<li id="maindept'+MainMenuJSON[i]["main_menu_id"]+'">'+
//                                     '<a class="sidebar-link waves-effect waves-dark sidebar-link" href="'+base_URL+'ThirdAxisCon/'+MainMenuJSON[i]["main_menu_con_name"]+'" aria-expanded="false">'+
//                                         '<i class="fa fa-'+MainMenuJSON[i]["main_menu_icon_name"]+' font-15 avatar-title"></i>'+
//                                         '<span> '+MainMenuJSON[i]["main_menu_name"]+' </span>'+
//                                     '</a>'+
//                                 '</li>');
//                                 var url = window.location.href;
//                                 var parts = url.split('/');

//                                 var lastSegment = parts.pop() || parts.pop();

//                                 if (lastSegment==MainMenuJSON[i]["main_menu_con_name"]) 
//                                 {
//                                     $("#maindept"+MainMenuJSON[i]["main_menu_id"]+"").addClass("menuitem-active");
//                                     $("#maindept"+MainMenuJSON[i]["main_menu_id"]+"").find('> a').addClass("active");
//                                 }
                             
//                         }
//                     }
//                 }
//                 else
//                 {
//                     window.location.replace(base_URL);
//                 }
//             },
//             error: function() {
//                 console.log("Error");
//             }
//         });
//     }


//     function getnotifications() {
//         $(".loading").hide();
//         return $.ajax({
//             url: base_URL + '/ThirdAxisCon/getnotifications',
//             type: 'POST',
//             beforeSend: function(){
//                 $(".loading").hide();
//             },
//             complete: function(){
//                 $(".loading").hide();
//             },
//             success: function(data) {
//                 //console.log(data);
//                 var MainCategoryJSON = $.parseJSON(data);

//                 $('.noti-icon-badge').html('');
//                 $('.noti-icon-badge').append(''+MainCategoryJSON.length+'');
//                 $('#cutnotificationmsgdisplay').html('');
//                 for (var i = 0; i < MainCategoryJSON.length; i++) 
//                 {
//                     if(MainCategoryJSON[i]["notification_type"]=="products")
//                     {
//                         $('#cutnotificationmsgdisplay').append('<a  class="dropdown-item notify-item show_nofityrr " data-attr-id="'+MainCategoryJSON[i]["notification_id"]+'" data-attr-message="'+MainCategoryJSON[i]["notification_message"]+'" data-attr-type="'+MainCategoryJSON[i]["notification_type"]+'" data-attr-searchkey="'+MainCategoryJSON[i]["search_key"]+'" > '+
//                             '<div class="notify-icon">'+
//                                 '<img src="'+base_URL +'assets/img/project.png" class="img-fluid rounded-circle" alt=""> </div>'+
//                             '<p class="notify-details">Oops! No Product Avaliable</p>'+
//                             '<p class="text-muted mb-0 user-msg" >'+
//                                 '<small>'+MainCategoryJSON[i]["notification_message"]+'</small>'+
//                             '</p>'+
//                         '</a>');
//                     }
//                     else if(MainCategoryJSON[i]["notification_type"]=="orders")
//                     {
//                         $('#cutnotificationmsgdisplay').append('<a class="dropdown-item notify-item show_nofityrr" data-attr-id="'+MainCategoryJSON[i]["notification_id"]+'" data-attr-message="'+MainCategoryJSON[i]["notification_message"]+'" data-attr-type="'+MainCategoryJSON[i]["notification_type"]+'" > '+
//                             '<div class="notify-icon">'+
//                                 '<img src="'+base_URL +'assets/img/delivery-boy.png" class="img-fluid rounded-circle" alt=""> </div>'+
//                             '<p class="notify-details">Wow ! New Order</p>'+
//                             '<p class="text-muted mb-0 user-msg" >'+
//                                 '<small>'+MainCategoryJSON[i]["notification_message"]+'</small>'+
//                             '</p>'+
//                         '</a>');
//                     }

//                     else if(MainCategoryJSON[i]["notification_type"]=="coupon")
//                     {
//                         $('#cutnotificationmsgdisplay').append('<a class="dropdown-item notify-item show_nofityrr" data-attr-id="'+MainCategoryJSON[i]["notification_id"]+'" data-attr-message="'+MainCategoryJSON[i]["notification_message"]+'" data-attr-type="'+MainCategoryJSON[i]["notification_type"]+'" > '+
//                             '<div class="notify-icon">'+
//                                 '<img src="'+base_URL +'assets/img/voucher.png" class="img-fluid rounded-circle" alt=""> </div>'+
//                             '<p class="notify-details">Coupon Error</p>'+
//                             '<p class="text-muted mb-0 user-msg" >'+
//                                 '<small>'+MainCategoryJSON[i]["notification_message"]+'</small>'+
//                             '</p>'+
//                         '</a>');
//                     }

//                     else if(MainCategoryJSON[i]["notification_type"]=="requested_prod")
//                     {
//                         $('#cutnotificationmsgdisplay').append('<a class="dropdown-item notify-item show_nofityrr" data-attr-id="'+MainCategoryJSON[i]["notification_id"]+'" data-attr-message="'+MainCategoryJSON[i]["notification_message"]+'" data-attr-type="'+MainCategoryJSON[i]["notification_type"]+'" > '+
//                             '<div class="notify-icon">'+
//                                 '<img src="'+base_URL +'assets/img/request_prod.png" class="img-fluid rounded-circle" alt=""> </div>'+
//                             '<p class="notify-details">Requested Product</p>'+
//                             '<p class="text-muted mb-0 user-msg" >'+
//                                 '<small>'+MainCategoryJSON[i]["notification_message"]+'</small>'+
//                             '</p>'+
//                         '</a>');
//                     }


//                 }


//             },
//             error: function() {
//                 console.log("Error");
//                 //alert('something bad happened'); 
//             }
//         });
//     }


//     $(document).on('click', '.show_nofityrr', function() {
//         $('#notificationmodel').modal('show');
//         $('#notificationcontentmsg').html('');
//         var dispbtmcontyt='';

//         if($(this).attr('data-attr-type')=='products')
//         {
//             dispbtmcontyt = "<br><br><a href='"+base_URL+"ThirdAxisCon/searchproductkey/"+$(this).attr('data-attr-searchkey')+"/findproduct' > Click to add <b style='text-decoration: underline;'> "+$(this).attr('data-attr-searchkey')+"</b> to product list </a> ";
//             $('#notificationcontentmsg').append($(this).attr('data-attr-message')+''+dispbtmcontyt);
//         }
//         if($(this).attr('data-attr-type')=='orders')
//         {
//             dispbtmcontyt = "<br><br><a href='"+base_URL+"ThirdAxisCon/orderconfirm'> View Order</a>";
//             $('#notificationcontentmsg').append($(this).attr('data-attr-message')+''+dispbtmcontyt);
//         }
//         if($(this).attr('data-attr-type')=='coupon')
//         {
//             // dispbtmcontyt = "<br><br><a href='"+base_URL+"ThirdAxisCon/orderconfirm'> View Order</a>";
//             $('#notificationcontentmsg').append($(this).attr('data-attr-message'));
//         }
//         if($(this).attr('data-attr-type')=='requested_prod')
//         {
//             // dispbtmcontyt = "<br><br><a href='"+base_URL+"ThirdAxisCon/orderconfirm'> View Order</a>";
//             $('#notificationcontentmsg').append($(this).attr('data-attr-message'));
//         }

        

//         var notification_id = $(this).attr('data-attr-id');
        
//         request = $.ajax({
//             type: "POST",
//             url: base_URL + 'ThirdAxisCon/updatenotificationviewflag',
//             data: {
//                 "notification_id": notification_id
//             },
//         });
//         request.done(function(response) {
//             var js = $.parseJSON(response);
//             var status = js.result

//             getnotifications();
//         });
 

//     });









//     $(document)
//     .ajaxStart(function() {
//         $(".loading").hide();
//     })
//     .ajaxStop(function() {
//         $(".loading").hide();
//     });

// });