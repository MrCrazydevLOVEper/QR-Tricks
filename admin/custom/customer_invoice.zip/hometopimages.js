$(document).ready(function() {

    var BannerImageJSON, banner_id, mode;
    var imageoneinserted='';
    var imagetwoinserted='';
    var category_id,md_code,sd_code,mc_code,sc_code,display_name,redirect_url_to ='';
    var subdepartmentid = '';
    var maincategoryid = '';
    var subcategoryid = ''; 

    $('.main-department-valss').hide();
    $('.sub-department-valss').hide();
    $('.main-category-valss').hide();
    $('.sub-category-valss').hide();


    $(document).on('change', '#redirect_url_to', function() 
    {
        var redirect_url_to = $('#redirect_url_to').val();

        if (redirect_url_to=='') 
        {
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            $('.main-department-valss').hide();
            $('.sub-department-valss').hide();
            $('.main-category-valss').hide();
            $('.sub-category-valss').hide();
            subdepartmentid = '';
            maincategoryid = '';
            subcategoryid = ''; 
        }
        else if (redirect_url_to=='main_department') 
        {
            $('.main-department-valss').show();
            $('.sub-department-valss').hide();
            $('.main-category-valss').hide();
            $('.sub-category-valss').hide();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            subdepartmentid = '';
            maincategoryid = '';
            subcategoryid = ''; 
        }
        else if (redirect_url_to=='sub_department') 
        {
            $('.main-department-valss').show();
            $('.sub-department-valss').show();
            $('.main-category-valss').hide();
            $('.sub-category-valss').hide();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            subdepartmentid = '';
            maincategoryid = '';
            subcategoryid = ''; 
        }
        else if (redirect_url_to=='main_category') 
        {
            $('.main-department-valss').show();
            $('.sub-department-valss').show();
            $('.main-category-valss').show();
            $('.sub-category-valss').hide();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            subdepartmentid = '';
            maincategoryid = '';
            subcategoryid = ''; 
        }
        else if (redirect_url_to=='sub_category') 
        {
            $('.main-department-valss').show();
            $('.sub-department-valss').show();
            $('.main-category-valss').show();
            $('.sub-category-valss').show();
            $('#md_code').val('');
            $('#sd_code').val('');
            $('#mc_code').val('');
            $('#sc_code').val('');
            subdepartmentid = '';
            maincategoryid = '';
            subcategoryid = ''; 
        }
    });


    $(document).on('change', '#md_code', function() {
        var md_code = $('#md_code').val();
        $('#sd_code').val('');
        $('#sd_code').html('');
        $('#sd_code').append("<option value=''>Select the Sub Department</option>");
        $('#mc_code').val('');
        $('#mc_code').html('');
        $('#mc_code').append("<option value=''>Select the Main Category</option>");
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getSubDepartment',
            type: 'POST',
            data: {
                "md_code": md_code
            },
            success: function(data) {
                SubDepatmentJSON = $.parseJSON(data);


                for (var i = 0; i < SubDepatmentJSON.length; i++) {
                    $('#sd_code').append("<option value='" + SubDepatmentJSON[i].sd_code + "'>" + SubDepatmentJSON[i].sdName + " ( " + SubDepatmentJSON[i].sd_code + " )</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    });


    $(document).on('change', '#sd_code', function() {
        var md_code = $('#md_code').val();
        var sd_code = $('#sd_code').val();
        $('#mc_code').val('');
        $('#mc_code').html('');
        $('#mc_code').append("<option value=''>Select the Main Category</option>");
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getMainCategory',
            type: 'POST',
            data: {
                "sd_code": sd_code,
                "md_code": md_code
            },
            success: function(data) {
                MainCategoryJSON = $.parseJSON(data);
               $('#mc_code').html('');
               $('#mc_code').append("<option value=''>Select the Main Category</option>");
                for (var i = 0; i < MainCategoryJSON.length; i++) {
                    $('#mc_code').append("<option value='" + MainCategoryJSON[i].mc_code + "'>" + MainCategoryJSON[i].mcName + " ( " + MainCategoryJSON[i].mc_code + " )</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    });


    $(document).on('change', '#mc_code', function() {
        var md_code = $('#md_code').val();
        var sd_code = $('#sd_code').val();
        var mc_code = $('#mc_code').val();

        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>")
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getSubCategory',
            type: 'POST',
            data: {
                "sd_code": sd_code,
                "md_code": md_code,
                "mc_code": mc_code
            },
            success: function(data) {
                MainCategoryJSON = $.parseJSON(data);
               $('#sc_code').html('');
               $('#sc_code').append("<option value=''>Select the Sub Category</option>");
                for (var i = 0; i < MainCategoryJSON.length; i++) {
                    $('#sc_code').append("<option value='" + MainCategoryJSON[i].sc_code + "'>" + MainCategoryJSON[i].scName + " ( " + MainCategoryJSON[i].sc_code + " )</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    });


    $(document).on('click', '.BtnEdit', function() {
        mode = "update";
         $('.error').hide();
        $('#largeModal').modal('show');
        var hidden_imgurl =  $(this).attr('data-attrb-img');
        var hidden_id =  $(this).attr('data-attr-id');        
        redirect_url_to = $(this).attr('data-attr-redirect_url_to');
        $('#redirect_url_to').val(redirect_url_to);
        category_id = $(this).attr('data-attr-category_id');
        md_code = $(this).attr('data-attr-md_code');
        sd_code = $(this).attr('data-attr-sd_code');
        mc_code = $(this).attr('data-attr-mc_code');
        sc_code = $(this).attr('data-attr-sc_code');
        display_name = $(this).attr('data-attr-display_name');

        subdepartmentid = $(this).attr('data-attr-sd_code');
        maincategoryid = $(this).attr('data-attr-mc_code');
        subcategoryid = $(this).attr('data-attr-sc_code');

        if (redirect_url_to=='main_department') 
        {
            $('.main-department-valss').show();
            $('.sub-department-valss').hide();
            $('.main-category-valss').hide();
            $('.sub-category-valss').hide();
            $('#md_code').val(md_code);
        }
        else if (redirect_url_to=='sub_department') 
        {
            $('.main-department-valss').show();
            $('.sub-department-valss').show();
            $('.main-category-valss').hide();
            $('.sub-category-valss').hide();
            $('#md_code').val(md_code);
            changemaindept(md_code,sd_code);       
        }
        else if (redirect_url_to=='main_category') 
        {
            $('.main-department-valss').show();
            $('.sub-department-valss').show();
            $('.main-category-valss').show();
            $('.sub-category-valss').hide();
            $('#md_code').val(md_code);
            $('#md_code').val(md_code);
            changemaindept(md_code,sd_code);
            changesubdept(md_code,sd_code,mc_code); 
        }
        else if (redirect_url_to=='sub_category') 
        {
            $('.main-department-valss').show();
            $('.sub-department-valss').show();
            $('.main-category-valss').show();
            $('.sub-category-valss').show();
            $('#md_code').val(md_code);
            changemaindept(md_code,sd_code);
            changesubdept(md_code,sd_code,mc_code); 
            changemaincat(md_code,sd_code,mc_code,sc_code);
        }

        imageoneinserted = hidden_imgurl;
        $('#img_namee1').show();
        $('#img_namee1').html('');
        $('#img_namee1').append('<div class="image-display" id="image-display"><div><img src=" '+ hidden_imgurl + '" class="user-update-image" alt="user profile" width="100px" style="padding-top: 15px;cursor:pointer"></div><div style="cursor:pointer"  class="image-delete-icon image-delete" id="dispimg_namee1">Delete and add new &nbsp; &nbsp; <i class="fa fa-bitbucket image-delete" ></i></div> </div>');
        $('#top_imageurl').prop('disabled', true);

    });


    function changemaindept(md_code,sd_code){
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getSubDepartment',
            type: 'POST',
            data: {
                "md_code": md_code
            },
            success: function(data) {
                $(".loading").hide();
                SubDepatmentJSON = $.parseJSON(data);
               $('#sd_code').html('');
               $('#sd_code').append("<option value=''>Select the Sub Department</option>");
                for (var i = 0; i < SubDepatmentJSON.length; i++) {
                    $('#sd_code').append("<option data-attrb-display_name='"+SubDepatmentJSON[i].sdName+"' value='" + SubDepatmentJSON[i].sd_code + "'>" + SubDepatmentJSON[i].sdName + " ( " + SubDepatmentJSON[i].sd_code + " )</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
                $("#sd_code").val(sd_code);
            },
            error: function() {
                console.log("Error");
            }
        });
    }

    function changesubdept(md_code,sd_code,mc_code){
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getMainCategory',
            type: 'POST',
            data: {
                "sd_code": sd_code,
                "md_code": md_code
            },
            success: function(data) {
                $(".loading").hide();
                MainCategoryJSON = $.parseJSON(data);
               $('#mc_code').html('');
               $('#mc_code').append("<option value=''>Select the Main Category</option>");
                for (var i = 0; i < MainCategoryJSON.length; i++) {
                    $('#mc_code').append("<option data-attrb-display_name='"+MainCategoryJSON[i].mcName+"' value='" + MainCategoryJSON[i].mc_code + "'>" + MainCategoryJSON[i].mcName + " ( " + MainCategoryJSON[i].mc_code + " )</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }                
                $("#mc_code").val(mc_code);
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }

    function changemaincat(md_code,sd_code,mc_code,sc_code) 
    {
        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getSubCategory',
            type: 'POST',
            data: {
                "sd_code": sd_code,
                "md_code": md_code,
                "mc_code": mc_code
            },
            success: function(data) {
                $(".loading").hide();
                MainCategoryJSON = $.parseJSON(data);
               $('#sc_code').html('');
               $('#sc_code').append("<option value=''>Select the Sub Category</option>");
                for (var i = 0; i < MainCategoryJSON.length; i++) {
                    $('#sc_code').append("<option data-attrb-display_name='"+MainCategoryJSON[i].scName+"' value='" + MainCategoryJSON[i].sc_code + "'>" + MainCategoryJSON[i].scName + " ( " + MainCategoryJSON[i].sc_code + " )</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }       
                $("#sc_code").val(sc_code);         
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }


    $(document).on('click','#dispimg_namee1',function(){
        $('#img_namee1').hide();
        $('#top_imageurl').prop('disabled', false);
        imageoneinserted='';
    }); 


    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var hidden_id =  $(this).attr('data-attr-category_id');
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreHometopimages(hidden_id,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var hidden_id =  $(this).attr('data-attr-category_id');
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreHometopimages(hidden_id,flag);
                },
                No: function() {},
            }
        });

    });


    function RestoreHometopimages(hidden_id,flag)
    {
    	var category_id = hidden_id;
    	var flag = flag;
        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/Restorehometoimages',
            data: {
                "category_id": category_id,"flag":flag
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {
                            window.location.reload();
                        },
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


    $('#banner_submit').click(function() {

        redirect_url_to = $('#redirect_url_to').val();
        $('.error').hide();
        if (imageoneinserted=="" && mode == "update" && $('#top_imageurl').val() == "" ) 
        {
            $('.top_imageurl').html("* Please Select the image ");
            $('.top_imageurl').show();
        }
        else if($('#redirect_url_to').val() == "" )
        {
            $('.redirect_url_to').html("* Please Select Redirect Url ");
            $('.redirect_url_to').show();
        }
        else if ($('#redirect_url_to').val() != "" )
        {
            if (redirect_url_to=='main_department') 
            {
                if($('#md_code').val()=='' || $('#md_code').val()==null)
                {
                    $('.md_code').html("* Please Select Main Department ");
                    $('.md_code').show();
                }
                else 
                {
                    display_name = $('#md_code').children("option:selected").attr("data-attrb-display_name");
                    updateBannerimage();
                }
            }
            else if (redirect_url_to=='sub_department') 
            {
                if($('#md_code').val()=='' || $('#md_code').val()==null)
                {
                    $('.md_code').html("* Please Select Main Department ");
                    $('.md_code').show();
                }
                else if($('#sd_code').val()=='' || $('#sd_code').val()== null)
                {
                    $('.sd_code').html("* Please Select Sub Department ");
                    $('.sd_code').show();
                }        
                else 
                {
                    display_name = $('#sd_code').children("option:selected").attr("data-attrb-display_name");
                    updateBannerimage();
                }

            }
            else if (redirect_url_to=='main_category') 
            {
                if($('#md_code').val()==''  || $('#md_code').val()==null)
                {
                    $('.md_code').html("* Please Select Main Department ");
                    $('.md_code').show();
                }
                else if($('#sd_code').val()=='' || $('#sd_code').val()==null)
                {
                    $('.sd_code').html("* Please Select Sub Department ");
                    $('.sd_code').show();
                } 
                else if($('#mc_code').val()=='' || $('#mc_code').val()==null)
                {
                    $('.mc_code').html("* Please Select Main Category ");
                    $('.mc_code').show();
                } 
                else 
                {
                    display_name = $('#mc_code').children("option:selected").attr("data-attrb-display_name");
                    updateBannerimage();
                }

            }
            else if (redirect_url_to=='sub_category') 
            {
                if($('#md_code').val()=='' || $('#md_code').val()==null)
                {
                    $('.md_code').html("* Please Select Main Department ");
                    $('.md_code').show();
                }
                else if($('#sd_code').val()=='' || $('#sd_code').val()==null)
                {
                    $('.sd_code').html("* Please Select Sub Department ");
                    $('.sd_code').show();
                } 
                else if($('#mc_code').val()=='' || $('#mc_code').val()==null)
                {
                    $('.mc_code').html("* Please Select Main Category ");
                    $('.mc_code').show();
                } 
                else if($('#sc_code').val()=='' || $('#sc_code').val()==null)
                {
                    $('.sc_code').html("* Please Select Sub Category ");
                    $('.sc_code').show();
                } 
                else 
                {
                    display_name = $('#sc_code').children("option:selected").attr("data-attrb-display_name");
                    updateBannerimage();
                }
            }
        }

    });

    function updateBannerimage() {
        var form = $('#bannerimagesform')[0];
        var data = new FormData(form);
        data.append("category_id", category_id);
        data.append("imageoneinserted",imageoneinserted);
        data.append("display_name",display_name);

        request = $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: base_URL + 'ThirdAxisCon/updatehometopimage',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {
                            window.location.reload();
                        },
                    }
                });
                $('#largeModal').modal('hide');
                refreshDetails();
            } else {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }		
        });
    }

    $('#largeModal').on('show.bs.modal', function() {
        $(".no").hide();
        $('#img_namee1').html('');
        $('#mobile_imageurl').prop('disabled', false);
        $('#img_namee2').html('');
        $('#web_imageurl').prop('disabled', false);
        $(this).find('form').trigger('reset');
        $('.main-department-valss').hide();
        $('.sub-department-valss').hide();
        $('.main-category-valss').hide();
        $('.sub-category-valss').hide();
    });

    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });


});