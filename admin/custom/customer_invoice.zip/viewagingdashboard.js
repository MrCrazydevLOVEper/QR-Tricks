$(document).ready(function() {

    var AgingdetailsJSON, banner_id, mode,OfferproductDetailJSON,AgingdetailsJSON;

    $.when(getagingdetails()).done(function(){
            dispgingdetails(AgingdetailsJSON);                
    });


    function getagingdetails()
    {

        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getagingdetails',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                AgingdetailsJSON = $.parseJSON(data);
                console.log();

            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }

    function dispgingdetails(JSON) {
        var i =1;
        $('#Main_Category').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        if (data.prd_code==null) 
                        {
                            return ''+data.purchase_product_name+' (<span style="color:red"> Requested Product</span>)';
                        }
                        else
                        {
                            return ''+data.prd_code+' - '+data.prod_name+'';
                        }
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                       return ''+data.salable_stock+'';                           
                    }
                }, 
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.day1+'';                            
                    }
                }, 
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.day2+'';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.day3+'';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.day4+'';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.day5+'';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) 
                    {
                        return ''+data.day6+'';
                    }
                },       
            ]
        });
    }


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });


});