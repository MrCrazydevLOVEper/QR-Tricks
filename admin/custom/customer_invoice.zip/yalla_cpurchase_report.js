$(document).ready(function() {

    var ReportDetailsJSON, area_master_id, mode;
    $.when(getreportdetails()).done(function() {
        dispDetailslist(ReportDetailsJSON);
    });

    function getreportdetails() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/customerpurchasereport',
            type: 'POST',
            success: function(data) 
            {
                ReportDetailsJSON = $.parseJSON(data);
            },
            error: function() 
            {
                console.log("Error");
            }
        });
    }


    function dispDetailslist(JSON) 
    {
        var i =1;
        $('#yalla_cpurchase_report').dataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csv',
                    title: 'Customer Purchase Report',
                    text: "Export as Excel",
                     exportOptions: {
                        message: "Customer Purchase Report",
                        columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 ,13, 14, 15]
                    },
                },            
            ],
            "aoColumns": [

					{
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.user_unique_id==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.user_unique_id;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.Username==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.Username;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.order_placed_datentime==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.order_placed_datentime;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.order_completed_date==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.order_completed_date;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.orderno==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.orderno;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.prod_code==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.prod_code;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.product_name==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.product_name;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.mdName==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.mdName;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.sdName==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.sdName;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.mcName==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.mcName;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.scName==null) 
                        {
                            return '';
                        }
                        else
                        {
                            return data.scName;   
                        }                        
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.prod_total_qty==null) 
                        {
                            return '0';   
                        }
                        else
                        {
                            return ''+data.prod_total_qty+' '+data.converted_unit+'';       
                        }
                    }
                }, 
                { 
                    "mDataProp": function ( data, type, full, meta) 
                    {
                        if (data.prod_total_price==null) 
                        {
                           return 'AED 0.00';    
                        }
                        else
                        { 
                            return 'AED '+data.prod_total_price+ '';  
                        }
                    }
                }, 
            ]
        });
    }

    function refreshDetails() {
        $.when(getreportdetails()).done(function() {
            var table = $('#yalla_cpurchase_report').DataTable();
            table.destroy();
            dispDetailslist(ReportDetailsJSON);
        });
    }


    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});