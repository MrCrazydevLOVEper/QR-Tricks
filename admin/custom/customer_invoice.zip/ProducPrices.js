$(document).ready(function() {
	var subdepartmentid;
	var productpriceJSON,prod_price_id,mode,SubDepatmentJSON;
	$.when(getMainCategory()).done(function(){
			dispDietType(productpriceJSON);				
	});

	function getMainCategory()
	{
		return $.ajax({
			url: base_URL+'/ThirdAxisCon/getproductprice',
			type:'POST',
			success:function(data){
				//console.log(data);
				productpriceJSON = $.parseJSON(data);
				
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;
	}


	function dispDietType(JSON)
	{	
		//$('#success_alert').show(1000);
		//console.log(dataJSON);
		var i = 1;
		$('#Main_Category').dataTable( {
			"aaSorting":[],
			"aaData": JSON,
			responsive: true,
			"aoColumns": [
				// { 
				// 	"mDataProp": function ( data, type, full, meta) {
				// 		return i++;					
				// 	}
				// },		
				// { 
				// 	"mDataProp": function ( data, type, full, meta) {
				// 		return ""+data.md_code+""+data.sd_code+""+data.mc_code+""+data.sc_code+"";					
				// 	}
				// },		
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ""+data.prod_code+"";					
					}
				},		
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ""+data.prod_name+"";					
					}
				},
				{
	                "mDataProp": function(data, type, full, meta) {
	                    if (data.produ_imgurl !== null)
	                    //return "<a href="+data.produ_imgurl+" target='_blank'>Click to view Image</a>";
	                    //return "<img src="+data.produ_imgurl+" width=100>";
	                        return "<div class='pro-im'>" +
	                        "<img src='" + data.produ_imgurl + "' alt='user' width=100>" +
	                        "<div class='pro-img-overlay'>" +
	                        "<ul class='pro-img-overlay-1'>" +
	                        "<li class='el-item'>" +
	                        "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href='" + data.produ_imgurl + "'>" +
	                        "<i class='fa fa-eye'></i></a>" +
	                        "</li>" +
	                        "</ul></div></div>";
	                    else
	                        return '';
	                }
	            },			
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ""+data.market_price+"";					
					}
				},		
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ""+data.selling_price+"";					
					}
				},	
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ""+data.avaliable_quantity+"";					
					}
				},
				{
                    "mDataProp": function(data, type, full, meta) {
                        if (data.product_flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;cursor:unset" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  visible</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;cursor:unset" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Hidden</a>&nbsp;&nbsp;';;

                    }
                },
				// { 
				// 	"mDataProp": function ( data, type, full, meta) {
				// 		if(data.flag==1)
				// 		return '<a id="'+ meta.row +'" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;'+
				// 			   '<a id="'+ meta.row +'" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
				// 		else
				// 		return '<a id="'+ meta.row +'" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;'+
				// 			   '<a id="'+ meta.row +'" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to restore"><i class="fa fa-check" aria-hidden="true"></i></a>';
						
				// 	}
				// },				
			]  				
		});
	}
	
	$('#New_Category').click(function(){
		mode="new";
		$('#largeModal').modal('show');
	});
	
	
	$(document).on('click','.BtnEdit',function(){
		
		mode="update";
		var r_index = $(this).attr('id');
		prod_price_id = productpriceJSON[r_index].prod_price_id;
		$('#largeModal').modal('show');
		$('#diet_type_name').val(productpriceJSON[r_index].diet_type_name);
	});
	
	
	
	$('#Main_Department_Button').click(function(){
		$('.error').hide();
		//alert(12);
		//console.log($('#url').val()); 
		if($('#diet_type_name').val()=="")
		{
			$('.diet_type_name').html("Please Fill diet type name");
			$('.diet_type_name').show();
		}
		else
		{
			if(mode=="new")
			{
				saveMainCategory();
			}
			else
			{
				updateMainCategory();
			}			
			
		}		
	});
	
	$('#largeModal').on('show.bs.modal', function () {
		$(".no").hide();
		$('#hide').attr('checked', false);
		$('#show').attr('checked', false);
		$('#sdId').val('');
	    $(this).find('form').trigger('reset');
	});	
	
	function saveMainCategory()
	{	
//alert(12);	
		var form = $('#Main_Department_Form')[0];
		var data = new FormData(form);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/insertDietType',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			//console.log(js);
			var status = js.result;
			console.log(status);
			if (status == "success") {
				$.confirm({
								icon: 'icon-close',
								title: 'Info',
								content: 'Inserted Sucessfully',
								type: 'green',
									buttons: {
										Ok: function() {},
									}
							});
				$('#largeModal').modal('hide');
				refreshDetails();
				//alert(12);
			}
			else
			{
				$.confirm({
							icon: 'icon-close',
							title: 'Info',
							content: 'Sorry Something went worng',
							type: 'red',
								buttons: {
									Ok: function() {},
								}
						});
			}
			// $('.alert-success').show().delay(5000).fadeOut('slow');				
			// refreshDetails();		
		});		
	}
	
	function refreshDetails()
	{
		$.when(getMainCategory()).done(function(){
			var table = $('#Main_Category').DataTable();
			table.destroy();	
			dispDietType(productpriceJSON);				
		});		
	}
	
	function updateMainCategory()
	{
		var form = $('#Main_Department_Form')[0];
		var data = new FormData(form);
		data.append("prod_price_id",prod_price_id);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/updateDietType',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);			
			var status = js.result;
			if (status == "success") {
				$.confirm({
							icon: 'icon-close',
							title: 'Info',
							content: 'Updated Sucessfully',
							type: 'green',
								buttons: {
									Ok: function() {},
								}
						});
				$('#largeModal').modal('hide');
				refreshDetails();
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}
			//console.log(js);
			// $('#largeModal').modal('hide');
			// $('.alert-success').show().delay(5000).fadeOut('slow');				
			// refreshDetails();		
		});			
	}


    $('#uoload_excel').click(function() {

        $('#ExcelUpload').modal({
              backdrop: 'static',
             keyboard: false ,
             show:true
        })
        // $('#excelmodel').modal('show');

    });


    $('#submit_product_price_excelupload').click(function() {
        $('.error').hide();

        if ($('#product_price_excel_upload').val() == "") 
        {
            $('.product_price_excel_upload').html("* Please Select the file to upload");
            $('.product_price_excel_upload').show();
        } 

        else 
        {
            var form = $('#import_excel_form')[0];
            var data = new FormData(form);
            request = $.ajax({
                type: "POST",
                enctype: 'multipart/form-data',
                url: base_URL + 'ThirdAxisCon/bulkupload_price',
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                timeout: 600000,
            });
            request.done(function(response) {
                var js = $.parseJSON(response);
                var status = js.result
                var msg = js.msg
                if (status == "success") 
                {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: ''+msg+'',
                        type: 'green',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                     $('#ExcelUpload').modal('hide');
                    refreshDetails();
                } 
                else {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Error',
                        content: ''+msg+'',
                        type: 'red',
                        buttons: {
                            Ok: function() {},
                        }
                    });
                }                   
            }); 

        }
    });



        	  $(document)
              .ajaxStart(function () {
                $(".loading").show();
              })
              .ajaxStop(function () {
                $(".loading").hide();
              });

});
