$(document).ready(function() {
	var subdepartmentid = '';
	var maincategoryid = '' ;	
	var imageoneinserted='';
	var SubCategoryJSON,sc_code,mode;
	$.when(getSubCategory()).done(function(){
			dispSubCategory(SubCategoryJSON);
			selectmaincategory();	
	});
	
	function getSubCategory()
	{
		return $.ajax({
			url: base_URL+'ThirdAxisCon/Sub_category',
			type:'POST',
			success:function(data){
				//console.log(data);
				SubCategoryJSON = $.parseJSON(data);
				
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;
	}

	
	function dispSubCategory(JSON)
	{
		//$('#success_alert').show(1000);
		//console.log(dataJSON);
			var i = 1;
		$('#Sub_Category').dataTable( {
			"aaSorting":[],
			"aaData": JSON,
			responsive: true,
			"aoColumns": [
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return i++;					
					}
				},
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.mdName+' ('+data.md_code+')';
					}
				},					
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.sdName+' ('+data.sd_code+')';
					}
				},				
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.mcName+' ('+data.mc_code+')';
					}
				},			
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return ''+ data.scName+' ('+data.sc_code+')';
					}
				},
				{
	                "mDataProp": function(data, type, full, meta) {
	                    if (data.scImage_url !== null)
	                    //return "<a href="+data.produ_imgurl+" target='_blank'>Click to view Image</a>";
	                    //return "<img src="+data.produ_imgurl+" width=100>";
	                        return "<div class='pro-im'>" +
	                        "<img src='" + data.scImage_url + "' alt='user' width=100>" +
	                        "<div class='pro-img-overlay'>" +
	                        "<ul class='pro-img-overlay-1'>" +
	                        "<li class='el-item'>" +
	                        "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href='" + data.scImage_url + "'>" +
	                        "<i class='fa fa-eye'></i></a>" +
	                        "</li>" +
	                        "</ul></div></div>";
	                    else
	                        return '';
	                }
	            },
				{ "mDataProp": "scSeoTitle" },
				{ "mDataProp": "scSeokeyword" },
				{ "mDataProp": "scSeoDes" },
				{
                    "mDataProp": function(data, type, full, meta) {
                        if (data.flag == 1)
                            return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  visible</a>&nbsp;&nbsp;';
                        else
                            return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Hidden</a>&nbsp;&nbsp;';;

                    }
                },
				{
                    "mDataProp": function(data, type, full, meta) {
                        
                            return '<a id="' + meta.row + '" class="btn BtnEdit" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;' +
                                '<a id="' + meta.row + '" class="btn BtnDelete" style="padding:0px;" role="button" data-toggle="tooltip" data-placement="top" title="Click to delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    }
                },				
			]  				
		});
	}
	
	$('#New_Category').click(function(){
		mode="new";
		$('#largeModal').modal('show');
	});
	
	$(document).on('click','.BtnEdit',function(){
		mode="update";
		var r_index = $(this).attr('id');
		sc_code = SubCategoryJSON[r_index].sc_code;
		$('#largeModal').modal('show');
        if(SubCategoryJSON[r_index].scImage_url!='')
        {
        	imageoneinserted = SubCategoryJSON[r_index].scImage_url;
            $('#img_namee1').html('');
            $('#img_namee1').show();
			$('#img_namee1').append('<div class="image-display" id="image-display"><div><img src=" '+SubCategoryJSON[r_index].scImage_url+ '" class="user-update-image" alt="user profile" width="100px" style="padding-top: 15px;"></div><p style="color:red">delete and add new </p> <div class="image-delete-icon image-delete" id="dispimg_namee1">Delete <i class="fa fa-bitbucket image-delete" ></i></div> </div>');
			$('#scImage_url').prop('disabled', true);
        } 
		$('#md_code').val(SubCategoryJSON[r_index].md_code);
		$('#sd_code').val(SubCategoryJSON[r_index].sd_code);
		subdepartmentid = SubCategoryJSON[r_index].sd_code;
		maincategoryid = SubCategoryJSON[r_index].mc_code;
		$('#md_code').change();
		$('#sd_code').change();
		$('#scName').val(SubCategoryJSON[r_index].scName);		
		$('#scSeoTitle').val(SubCategoryJSON[r_index].scSeoTitle);
		$('#scSeokeyword').val(SubCategoryJSON[r_index].scSeokeyword);
		$('#scSeoDes').val(SubCategoryJSON[r_index].scSeoDes);
	});

	$(document).on('click','#dispimg_namee1',function(){
		$('#img_namee1').hide();
		$('#scImage_url').prop('disabled', false);
		imageoneinserted='';
	});	
	
		$(document).on('change','#md_code',function(){
		var md_code = $('#md_code').val();	
		
			return $.ajax({
			url: base_URL+'ThirdAxisCon/getSubDepartment',
			type:'POST',
			data: {"md_code":md_code},
			success:function(data){
				SubDepatmentJSON = $.parseJSON(data);
					$('#sd_code').html('');
					$('#sd_code').append("<option value=''>Select the Sub Department</option>");	
				for(var i=0;i<SubDepatmentJSON.length;i++)
				{
					$('#sd_code').append("<option value='"+SubDepatmentJSON[i].sd_code+"'>"+SubDepatmentJSON[i].sdName+" ( "+SubDepatmentJSON[i].sd_code+" ) </option>");
				//	$('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
				}
				$('#sd_code').val(subdepartmentid);
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;
	});
	$(document).on('change','#sd_code',function(){
		var md_code = $('#md_code').val();

			if(subdepartmentid=='')
			{
				var sd_code = $('#sd_code').val();				
			}
			else
			{
				var sd_code=subdepartmentid;
			}
		
		
			return $.ajax({
			url: base_URL+'ThirdAxisCon/getMainCategory',
			type:'POST',
			data: {"sd_code":sd_code,"md_code":md_code},
			success:function(data){
				SubCategoryJSONN = $.parseJSON(data);
					$('#mc_code').html('');
					$('#mc_code').append("<option value=''>Select the Main Category</option>");
				for(var i=0;i<SubCategoryJSONN.length;i++)
				{
					$('#mc_code').append("<option value='"+SubCategoryJSONN[i].mc_code+"'>"+SubCategoryJSONN[i].mcName+" ( "+SubCategoryJSONN[i].mc_code+" )</option>");
				//	$('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
				}
				$('#mc_code').val(maincategoryid);
			},		
			error: function() {
				console.log("Error"); 
				//alert('something bad happened'); 
			}
		}) ;
	});
	
	
	$(document).on('click','.BtnDelete',function(){
		mode="delete";
		var r_index = $(this).attr('id');
		sc_code = SubCategoryJSON[r_index].sc_code;	
		var mc_code = SubCategoryJSON[r_index].mc_code;
        var md_code = SubCategoryJSON[r_index].md_code;
        var sd_code = SubCategoryJSON[r_index].sd_code;

		   $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Are you Sure Do you want to Delete this Data',
                type: 'blue',
					buttons: {
						Yes: function() {					
								request = $.ajax({
										type: "POST",
										url: base_URL+'ThirdAxisCon/DeleteSubCategoryData',
										data: {"md_code":md_code,"sd_code":sd_code,"mc_code":mc_code,"sc_code":sc_code},
								});	
								request.done(function (response){
									var js = $.parseJSON(response);
									var status = js.result
									if (status == "success") {
										$.confirm({
											icon: 'icon-close',
											title: 'Info',
											content: 'Deleted Succesfully',
											type: 'green',
												buttons: {
													Ok: function() {},
												}
										});
										refreshDetails();
									}
									else
									{
										$.confirm({
											icon: 'icon-close',
											title: 'Info',
											content: 'Are you Sure Do you want to Delete this Data',
											type: 'blue',
												buttons: {
													No: function() {},
												}
										});
									}
							
								});	
						},
						No: function() {},
					}
            });
		
		
	

	});
	


    $(document).on('click', '.Btnhidden', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        var md_code = SubCategoryJSON[r_index].md_code;
        var sd_code = SubCategoryJSON[r_index].sd_code;
        var mc_code = SubCategoryJSON[r_index].mc_code;
         	sc_code = SubCategoryJSON[r_index].sc_code;
        var flag = 0;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Deactivate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreSubCategoryData(md_code,sd_code,mc_code,sc_code,flag);
                },
                No: function() {},
            }
        });

    });


    $(document).on('click', '.BtnRestore', function() {
        mode = "restore";
        var r_index = $(this).attr('id');
        var md_code = SubCategoryJSON[r_index].md_code;
        var sd_code = SubCategoryJSON[r_index].sd_code;
        var mc_code = SubCategoryJSON[r_index].mc_code;
         	sc_code = SubCategoryJSON[r_index].sc_code;
        var flag = 1;

        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Activate this Data',
            type: 'blue',
            buttons: {
                Yes: function() {
                	RestoreSubCategoryData(md_code,sd_code,mc_code,sc_code,flag);
                },
                No: function() {},
            }
        });

    });


    function RestoreSubCategoryData(md_code,sd_code,mc_code,sc_code,flag)
    {
    	var md_code = md_code;
    	var sd_code = sd_code;    	
    	var mc_code = mc_code;
    	var sc_code = sc_code
    	var flag = flag;

        request = $.ajax({
                type: "POST",
                url: base_URL+'ThirdAxisCon/RestoreSubCategoryData',
                data: {"md_code":md_code,"sd_code":sd_code,"mc_code":mc_code,"sc_code":sc_code,"flag":flag},
        }); 
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Succesfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                });
                refreshDetails();
            } else {
                $.toast({
                    heading: 'Error',
                    text: 'Sorry Something went worng please try again',
                    showHideTransition: 'fade',
                    icon: 'error'
                });
            }
        });
    }


	
	$('#Sub_Category_Button').click(function(){
		$('.error').hide();
		//console.log($('#mcName').val());
		if($('#md_code').val()=="")
		{
			$('.md_code').html("* Please Fill Main Department");
			$('.md_code').show();
		}
		else if($('#sd_code').val()=="")
		{
			$('.sd_code').html("* Please Fill Sub Department");
			$('.sd_code').show();
		}
		else if($('#mc_code').val()=="")
		{
			$('.mc_code').html("* Please Fill Category Name");
			$('.mc_code').show();
		}
		else if($('#scName').val()=="")
		{
			$('.scName').html("* Please Fill SubCategory Name");
			$('.scName').show();
		}		
		else
		{
			
			if(mode=="new")
			{
				saveSubCategory();
			}
			else
			{
				updateSubCategory();
			}			
			
		}		
	});
	
	$('#largeModal').on('show.bs.modal', function () {
	    $(this).find('form').trigger('reset');
		$('#sd_code').val('');
		subdepartmentid='';
		maincategoryid='';
	});	
	
	function saveSubCategory()
	{		
		var form = $('#Sub_Category_Form')[0];
		var data = new FormData(form);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/insertSubCategoryData',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			//console.log(js);
			var status = js.result
			if (status == "success") {
				$.confirm({
								icon: 'icon-close',
								title: 'Info',
								content: 'Inserted Sucessfully',
								type: 'green',
									buttons: {
										Ok: function() {},
									}
							});
				$('#largeModal').modal('hide');
				refreshDetails();
			}
			else
			{
				$.confirm({
							icon: 'icon-close',
							title: 'Info',
							content: 'Sorry Something went worng',
							type: 'red',
								buttons: {
									Ok: function() {},
								}
						});
			}		
		});		
	}
	
	function refreshDetails()
	{
		$.when(getSubCategory()).done(function(){
			var table = $('#Sub_Category').DataTable();
			table.destroy();	
			dispSubCategory(SubCategoryJSON);				
		});		
	}
	
	function updateSubCategory()
	{
		var form = $('#Sub_Category_Form')[0];
		var data = new FormData(form);
		data.append("sc_code",sc_code);
		data.append("imageoneinserted",imageoneinserted);
		request = $.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: base_URL+'ThirdAxisCon/updateSubCategoryData',
				data: data,
				processData: false,
				contentType: false,
				cache: false,
				timeout: 600000,
		});	
		request.done(function (response){
			var js = $.parseJSON(response);
			var status = js.result
			if (status == "success") {
				$.confirm({
							icon: 'icon-close',
							title: 'Info',
							content: 'Updated Sucessfully',
							type: 'green',
								buttons: {
									Ok: function() {},
								}
						});
				$('#largeModal').modal('hide');
				refreshDetails();
			}
			else
			{
				$.confirm({
					icon: 'icon-close',
					title: 'Info',
					content: 'Sorry Something went worng',
					type: 'red',
						buttons: {
							Ok: function() {},
						}
				});
			}		
		});			
	}

        	  $(document)
              .ajaxStart(function () {
                $(".loading").show();
              })
              .ajaxStop(function () {
                $(".loading").hide();
              });

});
