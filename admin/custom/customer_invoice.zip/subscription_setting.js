$(document).ready(function() {

    var subscribed_setting_id, mode;
    $.when(yb_user_subscribed_setting()).done(function() {
        // dispOrderSetting(OrderSettingJSON);
    });

    function yb_user_subscribed_setting() {
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/yb_user_subscribed_setting',
            type: 'POST',
            success: function(data) {
                //console.log(data);
                var OrderSettingJSON = $.parseJSON(data);
                $('#todays_order_time').val(OrderSettingJSON[0].todays_order_time);
                $('#upcoming_order_time').val(OrderSettingJSON[0].upcoming_order_time);
                subscribed_setting_id = OrderSettingJSON[0].subscribed_setting_id;
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }





    $('#subscription_Form_submit').click(function() {
 
        if ($('todays_order_time').val() == "") {
            $('.todays_order_time').html("* Please Select the time");
            $('.todays_order_time').show();
        } 
        else if ($('upcoming_order_time').val() == "") {
            $('.upcoming_order_time').html("* Please Select the time");
            $('.upcoming_order_time').show();
        } 

        else {
            updatesubscriptionsetting();
        }
    });

    function updatesubscriptionsetting() 
    {

        var todays_order_time = $('#todays_order_time').val();
        var upcoming_order_time = $('#upcoming_order_time').val();

        request = $.ajax({
            type: "POST",
            url: base_URL + 'ThirdAxisCon/updatesubscriptionsetting',
            data: {
                "todays_order_time": todays_order_time,"upcoming_order_time": upcoming_order_time,"subscribed_setting_id": subscribed_setting_id
            },
        });
        request.done(function(response) {
            var js = $.parseJSON(response);
            var status = js.result;
            console.log(status);
            if (status == "success") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Updated Sucessfully',
                    type: 'green',
                    buttons: {
                        Ok: function() {},
                    }
                }); 
            } 
            else if (status == "errorrrr") {
                $.confirm({
                    icon: 'icon-close',
                    title: 'Error !!',
                    content: 'The Selected Order Accepting Date has been added already.',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            } 
            else {

                $.confirm({
                    icon: 'icon-close',
                    title: 'Info',
                    content: 'Sorry Something went worng',
                    type: 'red',
                    buttons: {
                        Ok: function() {},
                    }
                });
            }

        });

        // var form = $('#Main_Department_Form')[0];
        // var data = new FormData(form);
        // data.append("order_setting_id", order_setting_id);
        // request = $.ajax({
        //     type: "POST",
        //     enctype: 'multipart/form-data',
        //     url: base_URL + 'ThirdAxisCon/updateOrderSettingData',
        //     data: data,
        //     processData: false,
        //     contentType: false,
        //     cache: false,
        //     timeout: 600000,
        // });
        // request.done(function(response) {
        //     var js = $.parseJSON(response);
        //     var status = js.result;
        //     if (status == "success") {
        //         $.confirm({
        //             icon: 'icon-close',
        //             title: 'Info',
        //             content: 'Updated Sucessfully',
        //             type: 'green',
        //             buttons: {
        //                 Ok: function() {},
        //             }
        //         });
        //         $('#largeModal').modal('hide');
        //         refreshDetails();
        //     }
        //     else if (status == "errorrrr") {
        //         $.confirm({
        //             icon: 'icon-close',
        //             title: 'Error !!',
        //             content: 'The Selected Order Accepting Date has been added already.',
        //             type: 'red',
        //             buttons: {
        //                 Ok: function() {},
        //             }
        //         });
        //     } 
        //     else {
        //         $.confirm({
        //             icon: 'icon-close',
        //             title: 'Info',
        //             content: 'Sorry Something went worng',
        //             type: 'red',
        //             buttons: {
        //                 Ok: function() {},
        //             }
        //         });
        //     }		
        // });
    }

    $('#largeModal').on('show.bs.modal', function() {
        $(".no").hide();
        $('#hide').attr('checked', false);
        $('#show').attr('checked', false);
        $(this).find('form').trigger('reset');
    });


    $(document)
        .ajaxStart(function() {
            $(".loading").show();
        })
        .ajaxStop(function() {
            $(".loading").hide();
        });

});