$(document).ready(function() {

    var banner_id, mode, BannerproductDetailJSON,filtered_prod;

    $.when(getbannerproductsDetails()).done(function() {
        dispBannerproductDetails(BannerproductDetailJSON);
        getbrandlistdata();
    });

    function getbannerproductsDetails() 
    {
        var banner_id = $('#banner_id').val();
        return $.ajax({
            url: base_URL + '/ThirdAxisCon/getbannerproducts',
            type: 'POST',
            data: {
                "banner_id": banner_id
            },
            success: function(data) {
                //console.log(data);
                BannerproductDetailJSON = $.parseJSON(data);
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }

    $(document).on('change', '#md_code', function() {
        var md_code = $('#md_code').val();
        $('#sd_code').val('');
        $('#sd_code').html('');
        $('#sd_code').append("<option value=''>Select the Sub Department</option>");
        $('#mc_code').val('');
        $('#mc_code').html('');
        $('#mc_code').append("<option value=''>Select the Main Category</option>");
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        if(md_code!='')
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getSubDepartment',
                type: 'POST',
                data: {
                    "md_code": md_code
                },
                success: function(data) {
                    SubDepatmentJSON = $.parseJSON(data);
                    for (var i = 0; i < SubDepatmentJSON.length; i++) {
                        $('#sd_code').append("<option value='" + SubDepatmentJSON[i].sd_code + "'>" + SubDepatmentJSON[i].sdName + " ( " + SubDepatmentJSON[i].sd_code + " )</option>");
                        //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                    }
                    getbrandlistdata();
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            getbrandlistdata();
        }
    });


    $(document).on('change', '#sd_code', function() {
        var md_code = $('#md_code').val();
        var sd_code = $('#sd_code').val();
        $('#mc_code').val('');
        $('#mc_code').html('');
        $('#mc_code').append("<option value=''>Select the Main Category</option>");
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        if(md_code!='' && sd_code!='')
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getMainCategory',
                type: 'POST',
                data: {
                    "sd_code": sd_code,
                    "md_code": md_code
                },
                success: function(data) {
                    MainCategoryJSON = $.parseJSON(data);
                   $('#mc_code').html('');
                   $('#mc_code').append("<option value=''>Select the Main Category</option>");
                    for (var i = 0; i < MainCategoryJSON.length; i++) {
                        $('#mc_code').append("<option value='" + MainCategoryJSON[i].mc_code + "'>" + MainCategoryJSON[i].mcName + " ( " + MainCategoryJSON[i].mc_code + " )</option>");
                        //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                    }
                    getbrandlistdata();
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            getbrandlistdata();
        }

    });


    $(document).on('change', '#mc_code', function() {
        var md_code = $('#md_code').val();
        var sd_code = $('#sd_code').val();
        var mc_code = $('#mc_code').val();
        $('#sc_code').val('');
        $('#sc_code').html('');
        $('#sc_code').append("<option value=''>Select the Sub Category</option>");
        if(md_code!='' && sd_code!='' && mc_code!='')
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getSubCategory',
                type: 'POST',
                data: {
                    "sd_code": sd_code,
                    "md_code": md_code,
                    "mc_code": mc_code
                },
                success: function(data) {
                    MainCategoryJSON = $.parseJSON(data);
                   $('#sc_code').html('');
                   $('#sc_code').append("<option value=''>Select the Sub Category</option>");
                    for (var i = 0; i < MainCategoryJSON.length; i++) {
                        $('#sc_code').append("<option value='" + MainCategoryJSON[i].sc_code + "'>" + MainCategoryJSON[i].scName + " ( " + MainCategoryJSON[i].sc_code + " )</option>");
                        //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                    }
                    getbrandlistdata();
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            getbrandlistdata();
        }
    });

    $(document).on('change', '#sc_code', function() {
         getbrandlistdata();

    });

    function getbrandlistdata()
    {
        var md_code = 0;
        var sd_code = 0;
        var mc_code = 0;
        var sc_code = 0;

        if($('#md_code').val()!='')
        {
            md_code = $('#md_code').val();
        }
        if($('#sd_code').val()!='')
        {
            sd_code = $('#sd_code').val();
        }
        if($('#mc_code').val()!='')
        {
            mc_code = $('#mc_code').val();
        }
        if($('#sc_code').val()!='')
        {
            sc_code = $('#sc_code').val();
        }

        return $.ajax({
            url: base_URL + 'ThirdAxisCon/getbrandnamelist',
            type: 'POST',
            data: {
                "sd_code": sd_code,
                "md_code": md_code,
                "mc_code": mc_code,
                "sc_code": sc_code
            },
            success: function(data) {
                BrandJson = $.parseJSON(data);
                $('#brand_name').html('');
                $('#brand_name').append("<option value=''>Select the Brand</option>");
                for (var i = 0; i < BrandJson.length; i++) {
                    $('#brand_name').append("<option value='" + BrandJson[i].brand_name + "'>" + BrandJson[i].brand_name + "</option>");
                    //  $('#state_id').append("<option value='"+JSON[i].state_id+"'>"+JSON[i].name+"</option>");
                }
                // $('#sd_code').val(subdepartmentid);
            },
            error: function() {
                console.log("Error");
                //alert('something bad happened'); 
            }
        });
    }



    function dispBannerproductDetails(JSON) {
        //$('#success_alert').show(1000);
        //console.log(dataJSON);
        var i =1;
        var myoddtbl = $('#offer_product_table').DataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            columnDefs: [{
                orderable: false,
                targets: 0,
            }],
            order: [
                [1, 'asc'],
            ],
            "aoColumns": [

                {
                    "mDataProp": function (data, type, full, meta) 
                    {
                        return '<input type="checkbox" class="select-checkbox" value="'+data.prod_code+'" data-attr-prod_id="'+data.prod_id+'"  name="user_id" >';
                    },
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },

                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.prod_name+"";                    
                    }
                },      
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.prod_code+"";                    
                    }
                },      
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.produ_imgurl !== null)
                        //return "<a href="+data.produ_imgurl+" target='_blank'>Click to view Image</a>";
                        //return "<img src="+data.produ_imgurl+" width=100>";
                            return "<div class='pro-im'>" +
                            "<img src='" + data.produ_imgurl + "' alt='user' width=100>" +
                            "<div class='pro-img-overlay'>" +
                            "<ul class='pro-img-overlay-1'>" +
                            "<li class='el-item'>" +
                            "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href='" + data.produ_imgurl + "'>" +
                            "<i class='fa fa-eye'></i></a>" +
                            "</li>" +
                            "</ul></div></div>";
                        else
                            return '';
                    }
                },
                {
                    "mDataProp": function(data, type, full, meta) {
                            return '<a id="' + meta.row + '" class="btn BtnRestore btndeactivate" style="padding:0px;cursor:pointer" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Deactivate</a>&nbsp;&nbsp;';;

                    }
                }
            ]
        });

        // $('#MyTableCheckAllButtonDeactivate').click(function() {
        //     if (myoddtbl.rows({
        //             selected: true
        //         }).count() > 0) {
        //         myoddtbl.rows().deselect();
        //         return;
        //     }

        //     myoddtbl.rows().select();
        // });

        // myoddtbl.on('select deselect', function(e, dt, type, indexes) {
        //     if (type === 'row') {
        //         // We may use dt instead of myTable to have the freshest data.
        //         if (dt.rows().count() === dt.rows({
        //                 selected: true
        //             }).count()) {
        //             // Deselect all items button.
        //             $('#MyTableCheckAllButtonDeactivate i').attr('class', 'fa fa-check-square');
        //             return;
        //         }

        //         if (dt.rows({
        //                 selected: true
        //             }).count() === 0) {
        //             // Select all items button.
        //             $('#MyTableCheckAllButtonDeactivate i').attr('class', 'fa fa-square');
        //             return;
        //         }

        //         // Deselect some items button.
        //         $('#MyTableCheckAllButtonDeactivate i').attr('class', 'fa fa-minus-square');
        //     }
        // });


        // $('#button_deactivate').click(function () {
        //     var banner_id = $('#banner_id').val();

        //     var ids = $.map(myoddtbl.rows('.selected').data(), function (item) {
        //         return item.prod_code;
        //     });   

        //     var prod_id = $.map(myoddtbl.rows('.selected').data(), function (item) {
        //         return item.prod_id;
        //     });
       
        //     var emp_arr = ids.toString();
        //     var emp_prod_id = prod_id.toString();


        //     if(ids.length<=0)
        //     {
        //         $.confirm({
        //             icon: 'icon-close',
        //             title: 'Info',
        //             content: 'Please Select any product to add under this banner',
        //             type: 'red',
        //             buttons: {
        //                 Ok: function() {},
        //             }
        //         });
        //     }
        //     else
        //     {
        //         return $.ajax({
        //             url: base_URL + 'ThirdAxisCon/removeproductunderbanner',
        //             type: 'POST',
        //             data: {
        //                 "prod_list":emp_arr,
        //                 "emp_prod_id":emp_prod_id,
        //                 "banner_id": banner_id,
        //             },
        //             success: function(data) 
        //             {
        //                 $.confirm({
        //                     icon: 'icon-close',
        //                     title: 'Info',
        //                     content: 'Product Removed successfully',
        //                     type: 'green',
        //                     buttons: {
        //                         Ok: function() {
        //                            refreshDetails();
        //                         },
        //                     }
        //                 });
                        
        //             },
        //             error: function() {
        //                 console.log("Error");
        //                 //alert('something bad happened'); 
        //             }
        //         });
        //     }
        // });



    }

    $('input[name="selectAllcheck"]').click(function()
    {
        var table = $('#offer_product_table').DataTable();
        if($(this).prop("checked") == true)
        {

            table.$('td > input:checkbox').each(function () 
            {
                table.$("input[name='user_id']").prop('checked',true);
            }); 

        }
        else if($(this).prop("checked") == false)
        {
            table.$('td > input:checkbox').each(function () 
            {
                table.$("input[name='user_id']").prop('checked',false);
            }); 
            // $.each($("input[name='user_id']"), function(){
            //     $("input[name='user_id']").prop('checked',false);
            // });
        }
    });


    $(document).on('click','#button_deactivate',function()
    {
        var banner_id = $('#banner_id').val();
        var prod_id = [];
        var prod_code = [];
        var table = $('#offer_product_table').DataTable();
        table.$('td > input:checkbox').each(function () {
            // If checkbox is checked
            if (this.checked) {
                //Your code for example
                prod_code.push($(this).val());
                prod_id.push($(this).attr('data-attr-prod_id'));
            }
        }); 

        // $.each($("input[name='user_id']:checked"), function(){
        //     prod_code.push($(this).val());
        //     prod_id.push($(this).attr('data-attr-prod_id'));
        // });        
        var emp_arr =  prod_code.join(",");
        var emp_prod_id =  prod_id.join(",");


        if(prod_id.length==0)
        {
            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Please Select any product to add under this banner',
                type: 'red',
                buttons: {
                    Ok: function() {},
                }
            });
        }
        else
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/removeproductunderbanner',
                type: 'POST',
                data: {
                    "prod_list":emp_arr,
                    "emp_prod_id":emp_prod_id,
                    "banner_id": banner_id,
                },
                success: function(data) 
                {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Product Removed successfully',
                        type: 'green',
                        buttons: {
                            Ok: function() {
                               refreshDetails();
                            },
                        }
                    });
                    
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }

    }); 





    $('#Product_Button').click(function() 
    {
        if ($('#md_code').val()!="" || $('#sd_code').val()!="" || $('#mc_code').val()!="" || $('#sc_code').val()!="" || $('#brand_name').val()!="" ) 
        {
            var md_code =0;
            var sd_code =0;
            var mc_code =0;
            var sc_code =0;
            var brand_name =0;
             var banner_id = $('#banner_id').val();

            if($('#md_code').val()!='')
            {
                md_code = $('#md_code').val();
            }
            if($('#sd_code').val()!='')
            {
                sd_code = $('#sd_code').val();
            }
            if ($('#mc_code').val()!='')
            {
                mc_code = $('#mc_code').val();
            }
            if ($('#sc_code').val()!='')
            {
                sc_code = $('#sc_code').val();
            }
            if ($('#brand_name').val()!='')
            {
                brand_name = $('#brand_name').val();
            }


            return $.ajax({
                url: base_URL + 'ThirdAxisCon/getbannerproductsfilter',
                type: 'POST',
                data: {
                    "md_code": md_code,
                    "sd_code": sd_code,
                    "mc_code": mc_code,
                    "sc_code":sc_code,
                    "brand_name": brand_name,
                    "banner_id": banner_id,
                },
                success: function(data) {
                    filtered_prod = $.parseJSON(data);
                    // console.log(result);
                    // OfferDetailJSON = $.parseJSON(data);
                    dispOfferDetails(filtered_prod);

                    
                $('.disptbl').show();
                $('.disptbloffer').hide();

                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }
        else
        {
            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Please Select and click filter',
                type: 'red',
                buttons: {
                    Ok: function() {},
                }
            });
        }
    });

    function dispOfferDetails(JSON) {

        $('#offer_table').DataTable().destroy();
        var i =1;

        var myTable  = $('#offer_table').DataTable({
            "aaSorting": [],
            "aaData": JSON,
            responsive: true,
            columnDefs: [{
                orderable: false,
                targets: 0,
            }],
            order: [
                [1, 'asc'],
            ],
            "aoColumns": [

                {
                    "mDataProp": function (data, type, full, meta) 
                    {
                        return '<input type="checkbox" class="select-checkbox" value="'+data.prod_code+'" data-attr-prod_id="'+data.prod_id+'"  name="user_idkes" >';
                    },
                },

                {
                    "mDataProp": function(data, type, full, meta) {
                            return i++;
                    }
                },

                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.prod_name+"";                    
                    }
                },      
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ""+data.prod_code+"";                    
                    }
                },      
                {
                    "mDataProp": function(data, type, full, meta) {
                        if (data.produ_imgurl !== null)
                        //return "<a href="+data.produ_imgurl+" target='_blank'>Click to view Image</a>";
                        //return "<img src="+data.produ_imgurl+" width=100>";
                            return "<div class='pro-im'>" +
                            "<img src='" + data.produ_imgurl + "' alt='user' width=100>" +
                            "<div class='pro-img-overlay'>" +
                            "<ul class='pro-img-overlay-1'>" +
                            "<li class='el-item'>" +
                            "<a class='btn default btn-outline image-popup-vertical-fit el-link' target='blank' href='" + data.produ_imgurl + "'>" +
                            "<i class='fa fa-eye'></i></a>" +
                            "</li>" +
                            "</ul></div></div>";
                        else
                            return '';
                    }
                },
                // {
                //     "mDataProp": function(data, type, full, meta) {
                //         if (data.flag == 1)
                //             return '<a id="' + meta.row + '" class="btn Btnhidden" style="padding:0px;cursor:unset" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  visible</a>&nbsp;&nbsp;';
                //         else
                //             return '<a id="' + meta.row + '" class="btn BtnRestore" style="padding:0px;cursor:unset" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa  fa-times-circle-o " aria-hidden="true"></i>&nbsp;  Hidden</a>&nbsp;&nbsp;';;

                //     }
                // },
                {
                    "mDataProp": function(data, type, full, meta) {
                            return '<a id="' + meta.row + '" class="btn Btnhidden btnactivate" style="padding:0px;cursor:pointer" role="button" data-toggle="tooltip" data-placement="top" title="Click to edit"><i class="fa fa-check-circle-o" aria-hidden="true"></i>&nbsp;  Activate</a>&nbsp;&nbsp;';

                    }
                }
            ]
        });


        // $('#MyTableCheckAllButton').click(function() {
        //     if (myTable.rows({
        //             selected: true
        //         }).count() > 0) {
        //         myTable.rows().deselect();
        //         return;
        //     }

        //     myTable.rows().select();
        // });

        // myTable.on('select deselect', function(e, dt, type, indexes) {
        //     if (type === 'row') {
        //         // We may use dt instead of myTable to have the freshest data.
        //         if (dt.rows().count() === dt.rows({
        //                 selected: true
        //             }).count()) {
        //             // Deselect all items button.
        //             $('#MyTableCheckAllButton i').attr('class', 'fa fa-check-square');
        //             return;
        //         }

        //         if (dt.rows({
        //                 selected: true
        //             }).count() === 0) {
        //             // Select all items button.
        //             $('#MyTableCheckAllButton i').attr('class', 'fa fa-square');
        //             return;
        //         }

        //         // Deselect some items button.
        //         $('#MyTableCheckAllButton i').attr('class', 'fa fa-minus-square');
        //     }
        // });


        // $('#button').click(function () {
        //     var banner_id = $('#banner_id').val();

        //     var ids = $.map(myTable.rows('.selected').data(), function (item) {
        //         return item.prod_code;
        //     });   

        //     var prod_id = $.map(myTable.rows('.selected').data(), function (item) {
        //         return item.prod_id;
        //     });
       
        //     var emp_arr = ids.toString();
        //     var emp_prod_id = prod_id.toString();


        //     if(ids.length<=0)
        //     {
        //         $.confirm({
        //             icon: 'icon-close',
        //             title: 'Info',
        //             content: 'Please Select any product to add under this banner',
        //             type: 'red',
        //             buttons: {
        //                 Ok: function() {},
        //             }
        //         });
        //     }
        //     else
        //     {
        //         return $.ajax({
        //             url: base_URL + 'ThirdAxisCon/addproductunderbanner',
        //             type: 'POST',
        //             data: {
        //                 "prod_list":emp_arr,
        //                 "emp_prod_id":emp_prod_id,
        //                 "banner_id": banner_id,
        //             },
        //             success: function(data) 
        //             {
        //                 $.confirm({
        //                     icon: 'icon-close',
        //                     title: 'Info',
        //                     content: 'Product Added successfully',
        //                     type: 'green',
        //                     buttons: {
        //                         Ok: function() {
        //                             $( "#Product_Button" ).trigger( "click" );
        //                         },
        //                     }
        //                 });
                        
        //             },
        //             error: function() {
        //                 console.log("Error");
        //                 //alert('something bad happened'); 
        //             }
        //         });
        //     }



        // });


    }


    $('input[name="selectAllcheck2"]').click(function()
    {
        var myTable = $('#offer_table').DataTable();
        if($(this).prop("checked") == true)
        {

            myTable.$('td > input:checkbox').each(function () 
            {
                myTable.$("input[name='user_idkes']").prop('checked',true);
            }); 
            // $.each($("input[name='user_idkes']"), function(){
            //     $("input[name='user_idkes']").prop('checked',true);
            // });
        }
        else if($(this).prop("checked") == false)
        {
            myTable.$('td > input:checkbox').each(function () 
            {
                myTable.$("input[name='user_idkes']").prop('checked',false);
            }); 
            // $.each($("input[name='user_idkes']"), function(){
            //     $("input[name='user_idkes']").prop('checked',false);
            // });
        }
    });


    $(document).on('click','#buttonactivatiesde',function()
    {
        var banner_id = $('#banner_id').val();
        var prod_id = [];
        var prod_code = [];
        var myTable = $('#offer_table').DataTable();

        myTable.$('td > input:checkbox').each(function () {
            if (this.checked) {
                prod_code.push($(this).val());
                prod_id.push($(this).attr('data-attr-prod_id'));
            }
        }); 
        // $.each($("input[name='user_idkes']:checked"), function(){
        //     prod_code.push($(this).val());
        //     prod_id.push($(this).attr('data-attr-prod_id'));
        // });        
        var emp_arr =  prod_code.join(",");
        var emp_prod_id =  prod_id.join(",");


        if(prod_id.length<=0)
        {
            $.confirm({
                icon: 'icon-close',
                title: 'Info',
                content: 'Please Select any product to add under this banner',
                type: 'red',
                buttons: {
                    Ok: function() {},
                }
            });
        }
        else
        {
            return $.ajax({
                url: base_URL + 'ThirdAxisCon/addproductunderbanner',
                type: 'POST',
                data: {
                    "prod_list":emp_arr,
                    "emp_prod_id":emp_prod_id,
                    "banner_id": banner_id,
                },
                success: function(data) 
                {
                    $.confirm({
                        icon: 'icon-close',
                        title: 'Info',
                        content: 'Product Added successfully',
                        type: 'green',
                        buttons: {
                            Ok: function() {
                                $( "#Product_Button" ).trigger( "click" );
                            },
                        }
                    });
                    
                },
                error: function() {
                    console.log("Error");
                    //alert('something bad happened'); 
                }
            });
        }

    }); 





    $(document).on('click', '#idrefresh', function() {
            window.location.reload();
    });


    $(document).on('click', '.btnactivate', function() {
        mode = "delete";
        var r_index = $(this).attr('id');
        prod_id = filtered_prod[r_index].prod_id;
        prod_code = filtered_prod[r_index].prod_code;
        var banner_id = $('#banner_id').val();
        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Add this product',
            type: 'blue',
            buttons: {
                Yes: function() {
                    request = $.ajax({
                        url: base_URL + 'ThirdAxisCon/addproductunderbanner',
                        type: 'POST',
                        data: {
                            "prod_list":prod_code,
                            "emp_prod_id":prod_id,
                            "banner_id": banner_id,
                        },
                    });
                    request.done(function(response) {
                        var js = $.parseJSON(response);
                        var status = js.result
                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Added Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {
                                        $( "#Product_Button" ).trigger( "click" );
                                    },
                                }
                            });
                            refreshDetails();
                        } else {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Sorry something went wrong',
                                type: 'blue',
                                buttons: {
                                    No: function() {},
                                }
                            });
                        }

                    });
                },
                No: function() {},
            }
        });
    });


    $(document).on('click', '.btndeactivate', function() {
        mode = "delete";
        var r_index = $(this).attr('id');
        prod_id = BannerproductDetailJSON[r_index].prod_id;
        prod_code = BannerproductDetailJSON[r_index].prod_code;
        var banner_id = $('#banner_id').val();
        $.confirm({
            icon: 'icon-close',
            title: 'Info',
            content: 'Are you Sure Do you want to Remove this product',
            type: 'blue',
            buttons: {
                Yes: function() {
                    request = $.ajax({
                        url: base_URL + 'ThirdAxisCon/removeproductunderbanner',
                        type: 'POST',
                        data: {
                            "prod_list":prod_code,
                            "emp_prod_id":prod_id,
                            "banner_id": banner_id,
                        },
                    });
                    request.done(function(response) {
                        var js = $.parseJSON(response);
                        var status = js.result
                        if (status == "success") {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Removed Succesfully',
                                type: 'green',
                                buttons: {
                                    Ok: function() {
                                        refreshDetails();
                                    },
                                }
                            });
                            refreshDetails();
                        } else {
                            $.confirm({
                                icon: 'icon-close',
                                title: 'Info',
                                content: 'Sorry something went wrong',
                                type: 'blue',
                                buttons: {
                                    No: function() {},
                                }
                            });
                        }

                    });
                },
                No: function() {},
            }
        });
    });


    function refreshDetails() {
        $.when(getbannerproductsDetails()).done(function() {
            var table = $('#offer_product_table').DataTable();
            table.destroy();
            dispBannerproductDetails(BannerproductDetailJSON);
        });
    }




    $(document)
    .ajaxStart(function() {
        $(".loading").show();
    })
    .ajaxStop(function() {
        $(".loading").hide();
    });

});