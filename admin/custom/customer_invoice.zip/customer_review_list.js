$(document).ready(function() {

    var url = window.location.href;
    var parts = url.split('/');
    var lastSegment = parts.pop() || parts.pop();
    if (lastSegment=='one') 
    {
        $('#star_value').val('1');
    }
    if (lastSegment=='two') 
    {
        $('#star_value').val('2');
    }
    if (lastSegment=='three') 
    {
        $('#star_value').val('3');
    }
    if (lastSegment=='four') 
    {
        $('#star_value').val('4');
    }
    if (lastSegment=='five') 
    {
        $('#star_value').val('5');
    }

    var reviewJSON,mode;
    $.when(getreviwebasedonselected()).done(function(){
            dispreviwebasedonselected(reviewJSON);     
            getproductlist();
    });
    
    function getreviwebasedonselected()
    {
        var star_value=$('#star_value').val();
        if (star_value!='') 
        {
            return $.ajax({
                url: base_URL+'ThirdAxisCon/getreviwebasedonselected',
                type:'POST',
                data: {
                    "star_value":star_value
                },
                success:function(data){
                    reviewJSON = $.parseJSON(data);
                },      
                error: function() {
                    console.log("Error"); 
                    //alert('something bad happened'); 
                }
            }) ;
        }
    }   

    $(document).on('change','#star_value',function()
    {
        refreshDetails();
    });

    function refreshDetails()
    {
        $.when(getreviwebasedonselected()).done(function(){
            var table = $('#Sub_Category').DataTable();
            table.destroy();    
            dispreviwebasedonselected(reviewJSON);         
        });     
    }  

    
    function dispreviwebasedonselected(JSON)
    {
        var i = 1;
        $('#Sub_Category').dataTable( {
            "aaSorting":[],
            "aaData": JSON,
            responsive: true,
            "aoColumns": [
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return i++;                 
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.user_unique_id+' ';
                    }
                },                  
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.username+' '+ data.lastname+'';
                    }
                },              
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.orderno+'';
                    }
                },          
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.product_freshness+'';
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.packing+' ';
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.delivery_experience+' ';
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.avg_rating+' ';
                    }
                },
                { 
                    "mDataProp": function ( data, type, full, meta) {
                        return ''+ data.order_review_comments+' ';
                    }
                },
            ]               
        });
    }
    
    
    $('#wastagesort_Button').click(function()
    {
        $('.error').hide();
        var selected_date= $('#basic-datepicker').val();
        var selected_product= $('#product_code').val();
        return $.ajax({
            url: base_URL+'ThirdAxisCon/getallwastagehistory',
            type:'POST',
            data: {
                "selected_date":selected_date,"selected_product":selected_product
            },
            success:function(data)
            {
                wastageJSON = $.parseJSON(data);
                var table = $('#Sub_Category').DataTable();
                table.destroy();  
                dispreviwebasedonselected(wastageJSON); 

            },      
            error: function() {
                console.log("Error"); 
                //alert('something bad happened'); 
            }
        }) ;      
    });    
    


    $(document)
    .ajaxStart(function () {
        $(".loading").show();
    })
    .ajaxStop(function () 
    {
        $(".loading").hide();
    });

});
